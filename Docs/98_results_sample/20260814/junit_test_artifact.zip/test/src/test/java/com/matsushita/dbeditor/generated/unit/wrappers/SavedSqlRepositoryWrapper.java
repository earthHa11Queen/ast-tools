package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class SavedSqlRepositoryWrapper extends BaseWrapper {
    public SavedSqlRepositoryWrapper() { super("com.matsushita.dbeditor.domain.repository.SavedSqlRepository", "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway"); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "deleteById" -> op_deleteById(arguments);
            case "findAllByConnectionId" -> op_findAllByConnectionId(arguments);
            case "findById" -> op_findById(arguments);
            case "save" -> op_save(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_deleteById(Object[] arguments) {
        return invoke("deleteById", new String[] {"Integer"}, arguments, false, false);
    }

    public ExecutionResult op_findAllByConnectionId(Object[] arguments) {
        return invoke("findAllByConnectionId", new String[] {"Integer"}, arguments, false, false);
    }

    public ExecutionResult op_findById(Object[] arguments) {
        return invoke("findById", new String[] {"Integer"}, arguments, false, false);
    }

    public ExecutionResult op_save(Object[] arguments) {
        return invoke("save", new String[] {"SavedSql"}, arguments, false, false);
    }
}

package com.matsushita.dbeditor.generated.support;

public record DataRef(String dataId, String role, String convModel, String referenceType,
                      String targetId, String mirrorX, String mirrorY, String mirrorZ,
                      String nullable, String validationMin, String validationMax) {
    public String rootId() {
        int dot = dataId.indexOf('.');
        int bracket = dataId.indexOf('[');
        int brace = dataId.indexOf('{');
        int end = dataId.length();
        if (dot >= 0) end = Math.min(end, dot);
        if (bracket >= 0) end = Math.min(end, bracket);
        if (brace >= 0) end = Math.min(end, brace);
        return dataId.substring(0, end);
    }
}

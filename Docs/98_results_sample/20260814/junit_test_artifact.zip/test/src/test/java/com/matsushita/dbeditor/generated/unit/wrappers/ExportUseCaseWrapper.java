package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class ExportUseCaseWrapper extends BaseWrapper {
    public ExportUseCaseWrapper() { super("com.matsushita.dbeditor.usecase.file.ExportUseCase", ""); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "exportCsv" -> op_exportCsv(arguments);
            case "exportExcel" -> op_exportExcel(arguments);
            case "exportMarkdown" -> op_exportMarkdown(arguments);
            case "toCsvLine" -> op_toCsvLine(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_exportCsv(Object[] arguments) {
        return invoke("exportCsv", new String[] {"Integer", "String", "String"}, arguments, false, false);
    }

    public ExecutionResult op_exportExcel(Object[] arguments) {
        return invoke("exportExcel", new String[] {"Integer", "String", "String"}, arguments, false, false);
    }

    public ExecutionResult op_exportMarkdown(Object[] arguments) {
        return invoke("exportMarkdown", new String[] {"Integer", "String", "String"}, arguments, false, false);
    }

    public ExecutionResult op_toCsvLine(Object[] arguments) {
        return invoke("toCsvLine", new String[] {"List<String>"}, arguments, false, false);
    }
}

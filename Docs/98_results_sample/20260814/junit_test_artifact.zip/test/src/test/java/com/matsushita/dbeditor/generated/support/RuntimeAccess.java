package com.matsushita.dbeditor.generated.support;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.LinkedHashSet;
import java.util.Set;

public final class RuntimeAccess {
    private static volatile Method getValue;
    private RuntimeAccess() {}

    public static Object getValue(String caseNo, String dataId, Class<?> receivingType) {
        try {
            Method method = method();
            return method.invoke(null, caseNo, dataId, receivingType);
        } catch (InvocationTargetException e) {
            Throwable cause = e.getCause();
            if (cause instanceof RuntimeException runtime) throw runtime;
            throw new IllegalStateException("TestDataRuntime failed for " + caseNo + "/" + dataId, cause);
        } catch (ReflectiveOperationException e) {
            throw new IllegalStateException("TestDataRuntime invocation failed for " + caseNo + "/" + dataId, e);
        }
    }

    private static Method method() {
        Method cached = getValue;
        if (cached != null) return cached;
        synchronized (RuntimeAccess.class) {
            if (getValue != null) return getValue;
            Set<String> candidates = new LinkedHashSet<>();
            String configured = System.getProperty("test.data.runtime.class", "").trim();
            if (!configured.isEmpty()) candidates.add(configured);
            candidates.add("TestDataRuntime");
            candidates.add("com.matsushita.dbeditor.testdata.TestDataRuntime");
            candidates.add("com.matsushita.dbeditor.test.runtime.TestDataRuntime");
            candidates.add("com.matsushita.dbeditor.generated.runtime.TestDataRuntime");
            for (String candidate : candidates) {
                try {
                    Class<?> type = Class.forName(candidate);
                    Method method = type.getMethod("getValue", String.class, String.class, Class.class);
                    if (!Modifier.isStatic(method.getModifiers())) continue;
                    getValue = method;
                    return method;
                } catch (ReflectiveOperationException ignored) {}
            }
            throw new IllegalStateException("TestDataRuntime with getValue(String,String,Class) was not found; set -Dtest.data.runtime.class");
        }
    }
}

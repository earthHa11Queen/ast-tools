package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class TableMemoRepositoryWrapper extends BaseWrapper {
    public TableMemoRepositoryWrapper() { super("com.matsushita.dbeditor.domain.repository.TableMemoRepository", "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway"); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "findByConnectionIdAndTableName" -> op_findByConnectionIdAndTableName(arguments);
            case "upsert" -> op_upsert(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_findByConnectionIdAndTableName(Object[] arguments) {
        return invoke("findByConnectionIdAndTableName", new String[] {"Integer", "String"}, arguments, false, false);
    }

    public ExecutionResult op_upsert(Object[] arguments) {
        return invoke("upsert", new String[] {"TableMemo"}, arguments, false, false);
    }
}

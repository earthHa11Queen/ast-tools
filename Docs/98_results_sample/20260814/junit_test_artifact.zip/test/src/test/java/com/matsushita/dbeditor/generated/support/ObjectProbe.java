package com.matsushita.dbeditor.generated.support;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Collection;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

public final class ObjectProbe {
    private ObjectProbe() {}

    public static Object field(Object object, String name) {
        if (object == null) return null;
        Object unwrapped = unwrapResponse(object);
        if (unwrapped != object) return field(unwrapped, name);
        String getter = (name.equals("conflict") ? "is" : "get") + Character.toUpperCase(name.charAt(0)) + name.substring(1);
        try { return object.getClass().getMethod(getter).invoke(object); } catch (ReflectiveOperationException ignored) {}
        Class<?> cursor = object.getClass();
        while (cursor != null) {
            try { Field f = cursor.getDeclaredField(name); f.setAccessible(true); return f.get(object); }
            catch (ReflectiveOperationException ignored) { cursor = cursor.getSuperclass(); }
        }
        return null;
    }

    public static Object unwrapResponse(Object value) {
        if (value == null) return null;
        if (value.getClass().getName().equals("org.springframework.http.ResponseEntity")) {
            try { return value.getClass().getMethod("getBody").invoke(value); }
            catch (ReflectiveOperationException e) { throw new IllegalStateException(e); }
        }
        return value;
    }

    public static boolean deepContains(Object root, Object expected) {
        return deepContains(root, expected, new IdentityHashMap<>(), 0);
    }

    public static boolean deepFieldEquals(Object root, String fieldName, Object expected) {
        return deepFieldEquals(root, fieldName, expected, new IdentityHashMap<>(), 0);
    }

    private static boolean deepFieldEquals(Object root, String fieldName, Object expected,
                                           IdentityHashMap<Object, Boolean> seen, int depth) {
        if (root == null || depth > 5 || isScalar(root.getClass()) || seen.put(root, Boolean.TRUE) != null) return false;
        Object response = unwrapResponse(root);
        if (response != root) return deepFieldEquals(response, fieldName, expected, seen, depth + 1);
        Class<?> cursor = root.getClass();
        while (cursor != null && !cursor.getName().startsWith("java.")) {
            for (Field field : cursor.getDeclaredFields()) {
                if (Modifier.isStatic(field.getModifiers())) continue;
                try {
                    field.setAccessible(true);
                    Object value = field.get(root);
                    if (field.getName().equals(fieldName) && Objects.deepEquals(value, expected)) return true;
                    if (deepFieldEquals(value, fieldName, expected, seen, depth + 1)) return true;
                } catch (ReflectiveOperationException ignored) {}
            }
            cursor = cursor.getSuperclass();
        }
        if (root instanceof Map<?, ?> map) {
            if (map.containsKey(fieldName) && Objects.deepEquals(map.get(fieldName), expected)) return true;
            for (Object value : map.values()) if (deepFieldEquals(value, fieldName, expected, seen, depth + 1)) return true;
        }
        if (root instanceof Collection<?> values) for (Object value : values)
            if (deepFieldEquals(value, fieldName, expected, seen, depth + 1)) return true;
        if (root.getClass().isArray()) for (int i = 0; i < Array.getLength(root); i++)
            if (deepFieldEquals(Array.get(root, i), fieldName, expected, seen, depth + 1)) return true;
        return false;
    }

    private static boolean deepContains(Object root, Object expected, IdentityHashMap<Object, Boolean> seen, int depth) {
        if (Objects.deepEquals(root, expected)) return true;
        if (root == null || depth > 5 || isScalar(root.getClass()) || seen.put(root, Boolean.TRUE) != null) return false;
        if (root instanceof Optional<?> o) return o.isPresent() && deepContains(o.get(), expected, seen, depth + 1);
        if (root instanceof Map<?, ?> map) for (Map.Entry<?, ?> e : map.entrySet())
            if (deepContains(e.getKey(), expected, seen, depth + 1) || deepContains(e.getValue(), expected, seen, depth + 1)) return true;
        if (root instanceof Collection<?> values) for (Object value : values)
            if (deepContains(value, expected, seen, depth + 1)) return true;
        if (root.getClass().isArray()) for (int i = 0; i < Array.getLength(root); i++)
            if (deepContains(Array.get(root, i), expected, seen, depth + 1)) return true;
        Object response = unwrapResponse(root);
        if (response != root) return deepContains(response, expected, seen, depth + 1);
        Class<?> cursor = root.getClass();
        while (cursor != null && !cursor.getName().startsWith("java.")) {
            for (Field field : cursor.getDeclaredFields()) {
                if (Modifier.isStatic(field.getModifiers())) continue;
                try { field.setAccessible(true); if (deepContains(field.get(root), expected, seen, depth + 1)) return true; }
                catch (ReflectiveOperationException ignored) {}
            }
            cursor = cursor.getSuperclass();
        }
        return false;
    }

    private static boolean isScalar(Class<?> type) {
        return type.isPrimitive() || Number.class.isAssignableFrom(type) || CharSequence.class.isAssignableFrom(type)
                || Boolean.class == type || Character.class == type || type.isEnum() || type.getName().startsWith("java.time.");
    }
}

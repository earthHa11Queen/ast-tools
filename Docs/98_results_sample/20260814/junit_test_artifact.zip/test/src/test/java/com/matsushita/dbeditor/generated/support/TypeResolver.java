package com.matsushita.dbeditor.generated.support;

import java.lang.reflect.Array;
import java.util.HashMap;
import java.util.Map;

public final class TypeResolver {
    private static final Map<String, String> TYPES = new HashMap<>();
    static {
        TYPES.put("AutoMappingResponse", "com.matsushita.dbeditor.dto.outdto.AutoMappingResponse");
        TYPES.put("ConflictCheckRequest", "com.matsushita.dbeditor.dto.indto.ConflictCheckRequest");
        TYPES.put("ConflictCheckResponse", "com.matsushita.dbeditor.dto.outdto.ConflictCheckResponse");
        TYPES.put("ConflictUseCase", "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase");
        TYPES.put("ConnectionController", "com.matsushita.dbeditor.adapter.controller.ConnectionController");
        TYPES.put("ConnectionSetting", "com.matsushita.dbeditor.domain.entity.ConnectionSetting");
        TYPES.put("ConnectionSettingGateway", "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway");
        TYPES.put("ConnectionSettingRepository", "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository");
        TYPES.put("ConnectionSettingRequest", "com.matsushita.dbeditor.dto.indto.ConnectionSettingRequest");
        TYPES.put("ConnectionSettingResponse", "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse");
        TYPES.put("ConnectionTestRequest", "com.matsushita.dbeditor.dto.indto.ConnectionTestRequest");
        TYPES.put("ConnectionTestResponse", "com.matsushita.dbeditor.dto.outdto.ConnectionTestResponse");
        TYPES.put("ConnectionUseCase", "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase");
        TYPES.put("DbEditorApplication", "com.matsushita.dbeditor.DbEditorApplication");
        TYPES.put("ExportController", "com.matsushita.dbeditor.adapter.controller.ExportController");
        TYPES.put("ExportUseCase", "com.matsushita.dbeditor.usecase.file.ExportUseCase");
        TYPES.put("GetTableListUseCase", "com.matsushita.dbeditor.usecase.table.GetTableListUseCase");
        TYPES.put("GlobalExceptionHandler", "com.matsushita.dbeditor.infrastructure.exception.GlobalExceptionHandler");
        TYPES.put("HealthController", "com.matsushita.dbeditor.adapter.controller.HealthController");
        TYPES.put("ImportController", "com.matsushita.dbeditor.adapter.controller.ImportController");
        TYPES.put("ImportGateway", "com.matsushita.dbeditor.adapter.gateway.ImportGateway");
        TYPES.put("ImportRepository", "com.matsushita.dbeditor.domain.repository.ImportRepository");
        TYPES.put("ImportUseCase", "com.matsushita.dbeditor.usecase.file.ImportUseCase");
        TYPES.put("MappingApplyRequest", "com.matsushita.dbeditor.dto.indto.MappingApplyRequest");
        TYPES.put("MemoController", "com.matsushita.dbeditor.adapter.controller.MemoController");
        TYPES.put("MemoResponse", "com.matsushita.dbeditor.dto.outdto.MemoResponse");
        TYPES.put("MemoSaveRequest", "com.matsushita.dbeditor.dto.indto.MemoSaveRequest");
        TYPES.put("MemoTemplate", "com.matsushita.dbeditor.domain.entity.MemoTemplate");
        TYPES.put("MemoTemplateGateway", "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway");
        TYPES.put("MemoTemplateRepository", "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository");
        TYPES.put("MemoUseCase", "com.matsushita.dbeditor.usecase.file.MemoUseCase");
        TYPES.put("NewTableImportRequest", "com.matsushita.dbeditor.dto.indto.NewTableImportRequest");
        TYPES.put("SavedSql", "com.matsushita.dbeditor.domain.entity.SavedSql");
        TYPES.put("SavedSqlGateway", "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway");
        TYPES.put("SavedSqlRepository", "com.matsushita.dbeditor.domain.repository.SavedSqlRepository");
        TYPES.put("SqlController", "com.matsushita.dbeditor.adapter.controller.SqlController");
        TYPES.put("SqlExecuteRequest", "com.matsushita.dbeditor.dto.indto.SqlExecuteRequest");
        TYPES.put("SqlExecuteResponse", "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse");
        TYPES.put("SqlResponse", "com.matsushita.dbeditor.dto.outdto.SqlResponse");
        TYPES.put("SqlSaveRequest", "com.matsushita.dbeditor.dto.indto.SqlSaveRequest");
        TYPES.put("SqlTemplate", "com.matsushita.dbeditor.domain.entity.SqlTemplate");
        TYPES.put("SqlTemplateGateway", "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway");
        TYPES.put("SqlTemplateRepository", "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository");
        TYPES.put("SqlUseCase", "com.matsushita.dbeditor.usecase.sql.SqlUseCase");
        TYPES.put("TableConflictGateway", "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway");
        TYPES.put("TableConflictRepository", "com.matsushita.dbeditor.domain.repository.TableConflictRepository");
        TYPES.put("TableController", "com.matsushita.dbeditor.adapter.controller.TableController");
        TYPES.put("TableHistoryGateway", "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway");
        TYPES.put("TableHistoryRepository", "com.matsushita.dbeditor.domain.repository.TableHistoryRepository");
        TYPES.put("TableHistoryResponse", "com.matsushita.dbeditor.dto.outdto.TableHistoryResponse");
        TYPES.put("TableHistorySaveRequest", "com.matsushita.dbeditor.dto.indto.TableHistorySaveRequest");
        TYPES.put("TableHistoryUseCase", "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase");
        TYPES.put("TableMemo", "com.matsushita.dbeditor.domain.entity.TableMemo");
        TYPES.put("TableMemoGateway", "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway");
        TYPES.put("TableMemoRepository", "com.matsushita.dbeditor.domain.repository.TableMemoRepository");
        TYPES.put("TableMetadata", "com.matsushita.dbeditor.domain.entity.TableMetadata");
        TYPES.put("TableMetadataGateway", "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway");
        TYPES.put("TableMetadataRepository", "com.matsushita.dbeditor.domain.repository.TableMetadataRepository");
        TYPES.put("TableMetadataResponse", "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse");
        TYPES.put("TableNameValidator", "com.matsushita.dbeditor.infrastructure.database.TableNameValidator");
        TYPES.put("TableRecordGateway", "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway");
        TYPES.put("TableRecordRepository", "com.matsushita.dbeditor.domain.repository.TableRecordRepository");
        TYPES.put("TableRecordUpdateRequest", "com.matsushita.dbeditor.dto.indto.TableRecordUpdateRequest");
        TYPES.put("TableRecordUseCase", "com.matsushita.dbeditor.usecase.table.TableRecordUseCase");
        TYPES.put("TargetDatabaseConnector", "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector");
        TYPES.put("TemplateController", "com.matsushita.dbeditor.adapter.controller.TemplateController");
        TYPES.put("TemplateRequest", "com.matsushita.dbeditor.dto.indto.TemplateRequest");
        TYPES.put("TemplateResponse", "com.matsushita.dbeditor.dto.outdto.TemplateResponse");
        TYPES.put("TemplateUseCase", "com.matsushita.dbeditor.usecase.file.TemplateUseCase");
        TYPES.put("WebConfig", "com.matsushita.dbeditor.infrastructure.config.WebConfig");
        TYPES.put("String", "java.lang.String");
        TYPES.put("Integer", "java.lang.Integer");
        TYPES.put("Boolean", "java.lang.Boolean");
        TYPES.put("RuntimeException", "java.lang.RuntimeException");
        TYPES.put("IllegalArgumentException", "java.lang.IllegalArgumentException");
        TYPES.put("LocalDateTime", "java.time.LocalDateTime");
        TYPES.put("List", "java.util.List");
        TYPES.put("Map", "java.util.Map");
        TYPES.put("Optional", "java.util.Optional");
    }

    private TypeResolver() {}

    public static Class<?> resolve(String declared) {
        String name = rawName(declared);
        if (name.endsWith("[]")) {
            return Array.newInstance(resolve(name.substring(0, name.length() - 2)), 0).getClass();
        }
        return switch (name) {
            case "int" -> int.class;
            case "long" -> long.class;
            case "boolean" -> boolean.class;
            case "byte" -> byte.class;
            case "short" -> short.class;
            case "double" -> double.class;
            case "float" -> float.class;
            case "char" -> char.class;
            case "void" -> void.class;
            default -> load(TYPES.getOrDefault(name, name));
        };
    }

    public static String rawName(String declared) {
        String s = declared.replace(" ", "");
        int generic = s.indexOf('<');
        if (generic >= 0) s = s.substring(0, generic);
        return s;
    }

    private static Class<?> load(String name) {
        try {
            return Class.forName(name);
        } catch (ClassNotFoundException first) {
            String[] packages = {"java.lang.", "java.util.", "java.time.", "org.springframework.http.",
                "org.springframework.jdbc.core.", "org.springframework.web.multipart.",
                "org.springframework.web.servlet.config.annotation.", "javax.sql."};
            for (String prefix : packages) {
                try { return Class.forName(prefix + name); } catch (ClassNotFoundException ignored) {}
            }
            throw new IllegalStateException("Unresolvable AST type: " + name, first);
        }
    }
}

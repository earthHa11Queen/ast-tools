package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class TemplateResponseWrapper extends BaseWrapper {
    public TemplateResponseWrapper() { super("com.matsushita.dbeditor.dto.outdto.TemplateResponse", ""); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "fromMemo" -> op_fromMemo(arguments);
            case "fromSql" -> op_fromSql(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_fromMemo(Object[] arguments) {
        return invoke("fromMemo", new String[] {"MemoTemplate"}, arguments, true, false);
    }

    public ExecutionResult op_fromSql(Object[] arguments) {
        return invoke("fromSql", new String[] {"SqlTemplate"}, arguments, true, false);
    }
}

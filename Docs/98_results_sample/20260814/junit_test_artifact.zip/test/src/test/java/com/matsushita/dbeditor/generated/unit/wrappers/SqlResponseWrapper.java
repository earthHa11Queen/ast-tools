package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class SqlResponseWrapper extends BaseWrapper {
    public SqlResponseWrapper() { super("com.matsushita.dbeditor.dto.outdto.SqlResponse", ""); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "fromEntity" -> op_fromEntity(arguments);
            case "summaryFromEntity" -> op_summaryFromEntity(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_fromEntity(Object[] arguments) {
        return invoke("fromEntity", new String[] {"SavedSql"}, arguments, true, false);
    }

    public ExecutionResult op_summaryFromEntity(Object[] arguments) {
        return invoke("summaryFromEntity", new String[] {"SavedSql"}, arguments, true, false);
    }
}

package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class TableNameValidatorWrapper extends BaseWrapper {
    public TableNameValidatorWrapper() { super("com.matsushita.dbeditor.infrastructure.database.TableNameValidator", ""); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "Constructor1" -> op_Constructor1(arguments);
            case "backupTableName" -> op_backupTableName(arguments);
            case "copyTableName" -> op_copyTableName(arguments);
            case "historyTableName" -> op_historyTableName(arguments);
            case "quoted" -> op_quoted(arguments);
            case "quotedBackup" -> op_quotedBackup(arguments);
            case "quotedCopy" -> op_quotedCopy(arguments);
            case "quotedHistory" -> op_quotedHistory(arguments);
            case "quotedReal" -> op_quotedReal(arguments);
            case "validate" -> op_validate(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_Constructor1(Object[] arguments) {
        return invoke("<init>", new String[] {}, arguments, false, true);
    }

    public ExecutionResult op_backupTableName(Object[] arguments) {
        return invoke("backupTableName", new String[] {"String"}, arguments, true, false);
    }

    public ExecutionResult op_copyTableName(Object[] arguments) {
        return invoke("copyTableName", new String[] {"String"}, arguments, true, false);
    }

    public ExecutionResult op_historyTableName(Object[] arguments) {
        return invoke("historyTableName", new String[] {"String", "int"}, arguments, true, false);
    }

    public ExecutionResult op_quoted(Object[] arguments) {
        return invoke("quoted", new String[] {"String", "String"}, arguments, true, false);
    }

    public ExecutionResult op_quotedBackup(Object[] arguments) {
        return invoke("quotedBackup", new String[] {"String", "String"}, arguments, true, false);
    }

    public ExecutionResult op_quotedCopy(Object[] arguments) {
        return invoke("quotedCopy", new String[] {"String", "String"}, arguments, true, false);
    }

    public ExecutionResult op_quotedHistory(Object[] arguments) {
        return invoke("quotedHistory", new String[] {"String", "String", "int"}, arguments, true, false);
    }

    public ExecutionResult op_quotedReal(Object[] arguments) {
        return invoke("quotedReal", new String[] {"String", "String"}, arguments, true, false);
    }

    public ExecutionResult op_validate(Object[] arguments) {
        return invoke("validate", new String[] {"String"}, arguments, true, false);
    }
}

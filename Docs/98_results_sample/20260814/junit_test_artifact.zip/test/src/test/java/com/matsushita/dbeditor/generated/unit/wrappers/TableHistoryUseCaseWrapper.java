package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class TableHistoryUseCaseWrapper extends BaseWrapper {
    public TableHistoryUseCaseWrapper() { super("com.matsushita.dbeditor.usecase.table.TableHistoryUseCase", ""); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "getConnection" -> op_getConnection(arguments);
            case "getHistoryList" -> op_getHistoryList(arguments);
            case "getHistoryRecords" -> op_getHistoryRecords(arguments);
            case "restoreHistory" -> op_restoreHistory(arguments);
            case "saveHistory" -> op_saveHistory(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_getConnection(Object[] arguments) {
        return invoke("getConnection", new String[] {"Integer"}, arguments, false, false);
    }

    public ExecutionResult op_getHistoryList(Object[] arguments) {
        return invoke("getHistoryList", new String[] {"Integer", "String", "String"}, arguments, false, false);
    }

    public ExecutionResult op_getHistoryRecords(Object[] arguments) {
        return invoke("getHistoryRecords", new String[] {"Integer", "String", "String", "int"}, arguments, false, false);
    }

    public ExecutionResult op_restoreHistory(Object[] arguments) {
        return invoke("restoreHistory", new String[] {"Integer", "String", "String", "int"}, arguments, false, false);
    }

    public ExecutionResult op_saveHistory(Object[] arguments) {
        return invoke("saveHistory", new String[] {"Integer", "String", "String", "List<Map<String,Object>>"}, arguments, false, false);
    }
}

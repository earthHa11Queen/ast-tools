package com.matsushita.dbeditor.generated.support;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.mockito.Mockito;

public final class ArgumentBuilder {
    private ArgumentBuilder() {}

    public static ArgumentBundle build(CaseDefinition definition) {
        Map<String, Object> values = new LinkedHashMap<>();
        Object[] args = new Object[definition.parameterNames().length];
        for (int i = 0; i < args.length; i++) {
            String name = definition.parameterNames()[i];
            String declaredType = definition.parameterTypes()[i];
            DataRef root = findRoot(definition.dataRefs(), name, i);
            args[i] = buildValue(definition, root, name, declaredType, values);
        }
        Object target = definition.targetDataId().isEmpty() ? null : values.get(definition.targetDataId());
        if (target == null && !definition.targetDataId().isEmpty()) {
            int dot = definition.targetDataId().indexOf('.');
            if (dot < 0) {
                for (int i = 0; i < definition.parameterNames().length; i++) {
                    if (definition.parameterNames()[i].equals(definition.targetDataId())) target = args[i];
                }
            }
        }
        return new ArgumentBundle(args, target, java.util.Collections.unmodifiableMap(new LinkedHashMap<>(values)));
    }

    private static DataRef findRoot(List<DataRef> refs, String parameterName, int index) {
        for (DataRef ref : refs) if (ref.dataId().equals(parameterName)) return ref;
        for (DataRef ref : refs) if (ref.rootId().equals(parameterName) && !isChild(ref.dataId())) return ref;
        // The AST argument order is authoritative; this is only for source naming aliases such as id/n.
        List<DataRef> roots = refs.stream().filter(r -> !isChild(r.dataId())).toList();
        return index < roots.size() ? roots.get(index) : null;
    }

    private static boolean isChild(String id) {
        return id.contains(".") || id.contains("[]") || id.contains("{");
    }

    private static Object buildValue(CaseDefinition definition, DataRef root, String name, String declaredType,
                                     Map<String, Object> values) {
        Class<?> targetType = TypeResolver.resolve(declaredType);
        if (root == null) return fixture(targetType);
        if (!root.convModel().equals("OBJECT")) {
            Object value = RuntimeAccess.getValue(definition.caseNo(), root.dataId(), targetType);
            values.put(root.dataId(), value);
            return coerce(value, targetType);
        }
        Object object = fixture(targetType);
        values.put(root.dataId(), object);
        String prefix = root.dataId() + ".";
        for (DataRef child : definition.dataRefs()) {
            if (!child.dataId().startsWith(prefix)) continue;
            String tail = child.dataId().substring(prefix.length());
            if (tail.contains(".") || tail.contains("[]") || tail.contains("{") || child.convModel().equals("OBJECT")) continue;
            Class<?> fieldType = fieldType(targetType, tail, child.referenceType());
            Object value = RuntimeAccess.getValue(definition.caseNo(), child.dataId(), fieldType);
            values.put(child.dataId(), value);
            set(object, tail, coerce(value, fieldType));
        }
        return object;
    }

    private static Object fixture(Class<?> type) {
        try {
            if (Throwable.class.isAssignableFrom(type)) {
                Constructor<?> c = type.getDeclaredConstructor(String.class);
                c.setAccessible(true);
                return c.newInstance("generated-case");
            }
            if (type.isInterface() || Modifier.isAbstract(type.getModifiers())) return Mockito.mock(type);
            Constructor<?> c = type.getDeclaredConstructor();
            c.setAccessible(true);
            return c.newInstance();
        } catch (ReflectiveOperationException e) {
            return Mockito.mock(type);
        }
    }

    private static Class<?> fieldType(Class<?> type, String name, String fallback) {
        Class<?> cursor = type;
        while (cursor != null) {
            try { return cursor.getDeclaredField(name).getType(); }
            catch (NoSuchFieldException ignored) { cursor = cursor.getSuperclass(); }
        }
        return TypeResolver.resolve(fallback);
    }

    private static void set(Object object, String name, Object value) {
        if (object == null || Mockito.mockingDetails(object).isMock()) return;
        String setter = "set" + Character.toUpperCase(name.charAt(0)) + name.substring(1);
        for (Method method : object.getClass().getMethods()) {
            if (method.getName().equals(setter) && method.getParameterCount() == 1) {
                try { method.invoke(object, coerce(value, method.getParameterTypes()[0])); return; }
                catch (ReflectiveOperationException e) { throw new IllegalStateException("Cannot set " + name, e); }
            }
        }
        Class<?> cursor = object.getClass();
        while (cursor != null) {
            try {
                Field field = cursor.getDeclaredField(name);
                field.setAccessible(true);
                field.set(object, coerce(value, field.getType()));
                return;
            } catch (NoSuchFieldException ignored) { cursor = cursor.getSuperclass(); }
            catch (ReflectiveOperationException e) { throw new IllegalStateException("Cannot set " + name, e); }
        }
        throw new IllegalStateException("AST field not found at runtime: " + object.getClass().getName() + "." + name);
    }

    static Object coerce(Object value, Class<?> type) {
        if (value == null) return null;
        if (type.isInstance(value)) return value;
        if (value instanceof Number n) {
            if (type == int.class || type == Integer.class) return n.intValue();
            if (type == long.class || type == Long.class) return n.longValue();
            if (type == short.class || type == Short.class) return n.shortValue();
            if (type == byte.class || type == Byte.class) return n.byteValue();
            if (type == double.class || type == Double.class) return n.doubleValue();
            if (type == float.class || type == Float.class) return n.floatValue();
        }
        return value;
    }
}

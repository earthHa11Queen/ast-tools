package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class MemoResponseWrapper extends BaseWrapper {
    public MemoResponseWrapper() { super("com.matsushita.dbeditor.dto.outdto.MemoResponse", ""); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "empty" -> op_empty(arguments);
            case "fromEntity" -> op_fromEntity(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_empty(Object[] arguments) {
        return invoke("empty", new String[] {"Integer", "String"}, arguments, true, false);
    }

    public ExecutionResult op_fromEntity(Object[] arguments) {
        return invoke("fromEntity", new String[] {"TableMemo"}, arguments, true, false);
    }
}

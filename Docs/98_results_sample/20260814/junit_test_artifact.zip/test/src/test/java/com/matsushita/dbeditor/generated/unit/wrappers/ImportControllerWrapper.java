package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class ImportControllerWrapper extends BaseWrapper {
    public ImportControllerWrapper() { super("com.matsushita.dbeditor.adapter.controller.ImportController", ""); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "applyMapping" -> op_applyMapping(arguments);
            case "createTableAndImport" -> op_createTableAndImport(arguments);
            case "csvAutoMapping" -> op_csvAutoMapping(arguments);
            case "excelAutoMapping" -> op_excelAutoMapping(arguments);
            case "getExcelSheets" -> op_getExcelSheets(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_applyMapping(Object[] arguments) {
        return invoke("applyMapping", new String[] {"MappingApplyRequest"}, arguments, false, false);
    }

    public ExecutionResult op_createTableAndImport(Object[] arguments) {
        return invoke("createTableAndImport", new String[] {"NewTableImportRequest"}, arguments, false, false);
    }

    public ExecutionResult op_csvAutoMapping(Object[] arguments) {
        return invoke("csvAutoMapping", new String[] {"MultipartFile", "Integer", "String", "String"}, arguments, false, false);
    }

    public ExecutionResult op_excelAutoMapping(Object[] arguments) {
        return invoke("excelAutoMapping", new String[] {"MultipartFile", "Integer", "String", "int", "String"}, arguments, false, false);
    }

    public ExecutionResult op_getExcelSheets(Object[] arguments) {
        return invoke("getExcelSheets", new String[] {"MultipartFile"}, arguments, false, false);
    }
}

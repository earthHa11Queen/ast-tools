package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class TableMetadataResponseWrapper extends BaseWrapper {
    public TableMetadataResponseWrapper() { super("com.matsushita.dbeditor.dto.outdto.TableMetadataResponse", ""); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "fromEntity" -> op_fromEntity(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_fromEntity(Object[] arguments) {
        return invoke("fromEntity", new String[] {"TableMetadata"}, arguments, true, false);
    }
}

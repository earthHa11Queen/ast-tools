package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class SqlExecuteResponseWrapper extends BaseWrapper {
    public SqlExecuteResponseWrapper() { super("com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse", ""); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "ofDml" -> op_ofDml(arguments);
            case "ofError" -> op_ofError(arguments);
            case "ofSelect" -> op_ofSelect(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_ofDml(Object[] arguments) {
        return invoke("ofDml", new String[] {"int"}, arguments, true, false);
    }

    public ExecutionResult op_ofError(Object[] arguments) {
        return invoke("ofError", new String[] {"String"}, arguments, true, false);
    }

    public ExecutionResult op_ofSelect(Object[] arguments) {
        return invoke("ofSelect", new String[] {"List<Map<String,Object>>"}, arguments, true, false);
    }
}

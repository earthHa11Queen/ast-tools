package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class MemoControllerWrapper extends BaseWrapper {
    public MemoControllerWrapper() { super("com.matsushita.dbeditor.adapter.controller.MemoController", ""); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "downloadMemo" -> op_downloadMemo(arguments);
            case "getMemo" -> op_getMemo(arguments);
            case "saveMemo" -> op_saveMemo(arguments);
            case "uploadMemo" -> op_uploadMemo(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_downloadMemo(Object[] arguments) {
        return invoke("downloadMemo", new String[] {"Integer", "String"}, arguments, false, false);
    }

    public ExecutionResult op_getMemo(Object[] arguments) {
        return invoke("getMemo", new String[] {"Integer", "String"}, arguments, false, false);
    }

    public ExecutionResult op_saveMemo(Object[] arguments) {
        return invoke("saveMemo", new String[] {"Integer", "String", "MemoSaveRequest"}, arguments, false, false);
    }

    public ExecutionResult op_uploadMemo(Object[] arguments) {
        return invoke("uploadMemo", new String[] {"Integer", "String", "MultipartFile"}, arguments, false, false);
    }
}

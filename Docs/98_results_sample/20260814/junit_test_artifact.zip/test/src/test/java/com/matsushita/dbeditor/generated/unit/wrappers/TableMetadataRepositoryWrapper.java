package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class TableMetadataRepositoryWrapper extends BaseWrapper {
    public TableMetadataRepositoryWrapper() { super("com.matsushita.dbeditor.domain.repository.TableMetadataRepository", "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway"); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "findAllTables" -> op_findAllTables(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_findAllTables(Object[] arguments) {
        return invoke("findAllTables", new String[] {"ConnectionSetting"}, arguments, false, false);
    }
}

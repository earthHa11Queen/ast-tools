package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class HealthControllerWrapper extends BaseWrapper {
    public HealthControllerWrapper() { super("com.matsushita.dbeditor.adapter.controller.HealthController", ""); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "health" -> op_health(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_health(Object[] arguments) {
        return invoke("health", new String[] {}, arguments, false, false);
    }
}

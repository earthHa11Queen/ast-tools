package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class ImportUseCaseWrapper extends BaseWrapper {
    public ImportUseCaseWrapper() { super("com.matsushita.dbeditor.usecase.file.ImportUseCase", ""); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "applyMapping" -> op_applyMapping(arguments);
            case "createTableAndImport" -> op_createTableAndImport(arguments);
            case "csvAutoMapping" -> op_csvAutoMapping(arguments);
            case "excelSheetAutoMapping" -> op_excelSheetAutoMapping(arguments);
            case "getConnection" -> op_getConnection(arguments);
            case "getExcelSheetNames" -> op_getExcelSheetNames(arguments);
            case "normalize" -> op_normalize(arguments);
            case "parseCsv" -> op_parseCsv(arguments);
            case "splitCsvLine" -> op_splitCsvLine(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_applyMapping(Object[] arguments) {
        return invoke("applyMapping", new String[] {"Integer", "String", "String", "Map<String,String>", "List<Map<String,String>>"}, arguments, false, false);
    }

    public ExecutionResult op_createTableAndImport(Object[] arguments) {
        return invoke("createTableAndImport", new String[] {"Integer", "String", "String", "List<String>", "List<String>", "List<Map<String,String>>"}, arguments, false, false);
    }

    public ExecutionResult op_csvAutoMapping(Object[] arguments) {
        return invoke("csvAutoMapping", new String[] {"Integer", "String", "String", "MultipartFile"}, arguments, false, false);
    }

    public ExecutionResult op_excelSheetAutoMapping(Object[] arguments) {
        return invoke("excelSheetAutoMapping", new String[] {"Integer", "String", "String", "MultipartFile", "int"}, arguments, false, false);
    }

    public ExecutionResult op_getConnection(Object[] arguments) {
        return invoke("getConnection", new String[] {"Integer"}, arguments, false, false);
    }

    public ExecutionResult op_getExcelSheetNames(Object[] arguments) {
        return invoke("getExcelSheetNames", new String[] {"MultipartFile"}, arguments, false, false);
    }

    public ExecutionResult op_normalize(Object[] arguments) {
        return invoke("normalize", new String[] {"String"}, arguments, false, false);
    }

    public ExecutionResult op_parseCsv(Object[] arguments) {
        return invoke("parseCsv", new String[] {"InputStream"}, arguments, false, false);
    }

    public ExecutionResult op_splitCsvLine(Object[] arguments) {
        return invoke("splitCsvLine", new String[] {"String"}, arguments, false, false);
    }
}

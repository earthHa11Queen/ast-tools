package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class ImportGatewayWrapper extends BaseWrapper {
    public ImportGatewayWrapper() { super("com.matsushita.dbeditor.adapter.gateway.ImportGateway", ""); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "createTableAndInsert" -> op_createTableAndInsert(arguments);
            case "findColumnNames" -> op_findColumnNames(arguments);
            case "insertIntoCopyTable" -> op_insertIntoCopyTable(arguments);
            case "sanitizeType" -> op_sanitizeType(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_createTableAndInsert(Object[] arguments) {
        return invoke("createTableAndInsert", new String[] {"ConnectionSetting", "String", "String", "List<String>", "List<String>", "List<Map<String,Object>>"}, arguments, false, false);
    }

    public ExecutionResult op_findColumnNames(Object[] arguments) {
        return invoke("findColumnNames", new String[] {"ConnectionSetting", "String", "String"}, arguments, false, false);
    }

    public ExecutionResult op_insertIntoCopyTable(Object[] arguments) {
        return invoke("insertIntoCopyTable", new String[] {"ConnectionSetting", "String", "String", "List<String>", "List<Map<String,Object>>"}, arguments, false, false);
    }

    public ExecutionResult op_sanitizeType(Object[] arguments) {
        return invoke("sanitizeType", new String[] {"String"}, arguments, false, false);
    }
}

package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class TargetDatabaseConnectorWrapper extends BaseWrapper {
    public TargetDatabaseConnectorWrapper() { super("com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector", ""); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "buildUrl" -> op_buildUrl(arguments);
            case "createDataSource" -> op_createDataSource(arguments);
            case "createJdbcTemplate" -> op_createJdbcTemplate(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_buildUrl(Object[] arguments) {
        return invoke("buildUrl", new String[] {"ConnectionSetting"}, arguments, false, false);
    }

    public ExecutionResult op_createDataSource(Object[] arguments) {
        return invoke("createDataSource", new String[] {"ConnectionSetting"}, arguments, false, false);
    }

    public ExecutionResult op_createJdbcTemplate(Object[] arguments) {
        return invoke("createJdbcTemplate", new String[] {"ConnectionSetting"}, arguments, false, false);
    }
}

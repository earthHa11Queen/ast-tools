package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class SqlControllerWrapper extends BaseWrapper {
    public SqlControllerWrapper() { super("com.matsushita.dbeditor.adapter.controller.SqlController", ""); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "downloadSql" -> op_downloadSql(arguments);
            case "executeSql" -> op_executeSql(arguments);
            case "getSql" -> op_getSql(arguments);
            case "listSql" -> op_listSql(arguments);
            case "saveSql" -> op_saveSql(arguments);
            case "uploadSql" -> op_uploadSql(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_downloadSql(Object[] arguments) {
        return invoke("downloadSql", new String[] {"Integer"}, arguments, false, false);
    }

    public ExecutionResult op_executeSql(Object[] arguments) {
        return invoke("executeSql", new String[] {"SqlExecuteRequest"}, arguments, false, false);
    }

    public ExecutionResult op_getSql(Object[] arguments) {
        return invoke("getSql", new String[] {"Integer"}, arguments, false, false);
    }

    public ExecutionResult op_listSql(Object[] arguments) {
        return invoke("listSql", new String[] {"Integer"}, arguments, false, false);
    }

    public ExecutionResult op_saveSql(Object[] arguments) {
        return invoke("saveSql", new String[] {"SqlSaveRequest"}, arguments, false, false);
    }

    public ExecutionResult op_uploadSql(Object[] arguments) {
        return invoke("uploadSql", new String[] {"Integer", "MultipartFile"}, arguments, false, false);
    }
}

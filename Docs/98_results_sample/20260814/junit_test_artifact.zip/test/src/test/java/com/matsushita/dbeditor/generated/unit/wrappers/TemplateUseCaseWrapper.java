package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class TemplateUseCaseWrapper extends BaseWrapper {
    public TemplateUseCaseWrapper() { super("com.matsushita.dbeditor.usecase.file.TemplateUseCase", ""); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "deleteMemoTemplate" -> op_deleteMemoTemplate(arguments);
            case "deleteSqlTemplate" -> op_deleteSqlTemplate(arguments);
            case "listMemoTemplates" -> op_listMemoTemplates(arguments);
            case "listSqlTemplates" -> op_listSqlTemplates(arguments);
            case "saveMemoTemplate" -> op_saveMemoTemplate(arguments);
            case "saveSqlTemplate" -> op_saveSqlTemplate(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_deleteMemoTemplate(Object[] arguments) {
        return invoke("deleteMemoTemplate", new String[] {"Integer"}, arguments, false, false);
    }

    public ExecutionResult op_deleteSqlTemplate(Object[] arguments) {
        return invoke("deleteSqlTemplate", new String[] {"Integer"}, arguments, false, false);
    }

    public ExecutionResult op_listMemoTemplates(Object[] arguments) {
        return invoke("listMemoTemplates", new String[] {}, arguments, false, false);
    }

    public ExecutionResult op_listSqlTemplates(Object[] arguments) {
        return invoke("listSqlTemplates", new String[] {}, arguments, false, false);
    }

    public ExecutionResult op_saveMemoTemplate(Object[] arguments) {
        return invoke("saveMemoTemplate", new String[] {"String", "String"}, arguments, false, false);
    }

    public ExecutionResult op_saveSqlTemplate(Object[] arguments) {
        return invoke("saveSqlTemplate", new String[] {"String", "String"}, arguments, false, false);
    }
}

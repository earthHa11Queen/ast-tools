package com.matsushita.dbeditor.generated.support;

public final class CaseExecutor {
    private CaseExecutor() {}

    public static void execute(OperationWrapper wrapper, CaseDefinition definition) {
        ArgumentBundle arguments = ArgumentBuilder.build(definition);
        if (definition.oracleKind().equals("VALIDATION_REJECTION")) {
            OracleEngine.verify(definition, arguments, new ExecutionResult(null, null, java.util.List.of()));
            return;
        }
        ExecutionResult result = wrapper.execute(definition, arguments.arguments());
        OracleEngine.verify(definition, arguments, result);
    }
}

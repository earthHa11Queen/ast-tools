package com.matsushita.dbeditor.generated.support;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

public abstract class BaseWrapper implements OperationWrapper {
    private final String targetClass;
    private final String implementationClass;

    protected BaseWrapper(String targetClass, String implementationClass) {
        this.targetClass = targetClass;
        this.implementationClass = implementationClass;
    }

    protected final ExecutionResult invoke(String methodName, String[] parameterTypes, Object[] arguments,
                                           boolean staticMethod, boolean constructorCall) {
        List<Object> mocks = new ArrayList<>();
        try {
            Class<?> declared = Class.forName(targetClass);
            if (constructorCall) {
                Constructor<?> constructor = declared.getDeclaredConstructor();
                constructor.setAccessible(true);
                return ExecutionResult.success(constructor.newInstance(), mocks);
            }
            Class<?> receiverType = implementationClass.isEmpty() ? declared : Class.forName(implementationClass);
            Object receiver = staticMethod ? null : instantiate(receiverType, mocks);
            Class<?>[] types = Arrays.stream(parameterTypes).map(TypeResolver::resolve).toArray(Class<?>[]::new);
            Method method = findMethod(receiverType, methodName, types);
            method.setAccessible(true);
            return ExecutionResult.success(method.invoke(receiver, arguments), mocks);
        } catch (InvocationTargetException e) {
            return ExecutionResult.failure(e.getCause(), mocks);
        } catch (Throwable e) {
            return ExecutionResult.failure(e, mocks);
        }
    }

    protected final ExecutionResult invokeConnectionProbe(String methodName, String[] parameterTypes, Object[] arguments) {
        String url = "jdbc:postgresql://" + arguments[0] + ":" + arguments[1] + "/" + arguments[2];
        Connection connection = Mockito.mock(Connection.class, invocation ->
                invocation.getMethod().getName().equals("isValid") ? true : null);
        try (MockedStatic<DriverManager> driver = Mockito.mockStatic(DriverManager.class)) {
            driver.when(() -> DriverManager.getConnection(url, (String) arguments[3], (String) arguments[4]))
                    .thenReturn(connection);
            return invoke(methodName, parameterTypes, arguments, false, false);
        }
    }

    private static Method findMethod(Class<?> type, String name, Class<?>[] types) throws NoSuchMethodException {
        Class<?> cursor = type;
        while (cursor != null) {
            try { return cursor.getDeclaredMethod(name, types); }
            catch (NoSuchMethodException ignored) { cursor = cursor.getSuperclass(); }
        }
        return type.getMethod(name, types);
    }

    private static Object instantiate(Class<?> type, List<Object> mocks) throws ReflectiveOperationException {
        if (type.isInterface() || Modifier.isAbstract(type.getModifiers())) return SemanticMocks.mock(type, mocks);
        Constructor<?>[] constructors = type.getDeclaredConstructors();
        Arrays.sort(constructors, Comparator.comparingInt(Constructor::getParameterCount));
        Constructor<?> constructor = constructors[0];
        constructor.setAccessible(true);
        Object[] dependencies = new Object[constructor.getParameterCount()];
        Class<?>[] types = constructor.getParameterTypes();
        for (int i = 0; i < types.length; i++) dependencies[i] = SemanticMocks.mock(types[i], mocks);
        return constructor.newInstance(dependencies);
    }
}

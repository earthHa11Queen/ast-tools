package com.matsushita.dbeditor.generated.support;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

public record CaseDefinition(
        String caseNo, String targetId, String sutClass, String methodName, String methodType,
        String returnType, String[] parameterNames, String[] parameterTypes,
        String mirrorX, String mirrorY, String mirrorZ, String verificationText, String expectedText,
        String targetDataId, String targetName, String nullable, String validationMin, String validationMax,
        String annotations, String oracleKind, String observation, String expected,
        String failureDiscrimination, List<DataRef> dataRefs) {
    private static final String US = "\u001f";
    private static final String RS = "\u001e";
    private static final String GS = "\u001d";
    private static final String FS = "\u001c";

    public static CaseDefinition decode(String encoded) {
        String raw = new String(Base64.getUrlDecoder().decode(encoded), StandardCharsets.UTF_8);
        String[] p = raw.split(US, -1);
        if (p.length != 24) throw new IllegalArgumentException("Invalid case payload fields: " + p.length);
        List<DataRef> refs = new ArrayList<>();
        if (!p[23].isEmpty()) {
            for (String row : p[23].split(GS, -1)) {
                String[] r = row.split(FS, -1);
                refs.add(new DataRef(r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[10]));
            }
        }
        return new CaseDefinition(p[0], p[1], p[2], p[3], p[4], p[5], split(p[6]), split(p[7]),
                p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[16], p[17], p[18],
                p[19], p[20], p[21], p[22], List.copyOf(refs));
    }

    private static String[] split(String value) {
        return value.isEmpty() ? new String[0] : value.split(RS, -1);
    }
}

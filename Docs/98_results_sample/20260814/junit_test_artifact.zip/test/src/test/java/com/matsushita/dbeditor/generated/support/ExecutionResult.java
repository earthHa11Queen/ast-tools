package com.matsushita.dbeditor.generated.support;

import java.util.List;

public record ExecutionResult(Object actual, Throwable thrown, List<Object> dependencyMocks) {
    public static ExecutionResult success(Object actual, List<Object> mocks) {
        return new ExecutionResult(actual, null, List.copyOf(mocks));
    }
    public static ExecutionResult failure(Throwable thrown, List<Object> mocks) {
        return new ExecutionResult(null, thrown, List.copyOf(mocks));
    }
}

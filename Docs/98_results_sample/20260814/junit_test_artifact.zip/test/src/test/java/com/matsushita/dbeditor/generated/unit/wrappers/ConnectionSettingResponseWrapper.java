package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class ConnectionSettingResponseWrapper extends BaseWrapper {
    public ConnectionSettingResponseWrapper() { super("com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse", ""); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "fromEntity" -> op_fromEntity(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_fromEntity(Object[] arguments) {
        return invoke("fromEntity", new String[] {"ConnectionSetting"}, arguments, true, false);
    }
}

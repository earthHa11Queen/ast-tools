package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class TableRecordGatewayWrapper extends BaseWrapper {
    public TableRecordGatewayWrapper() { super("com.matsushita.dbeditor.adapter.gateway.TableRecordGateway", ""); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "createCopyTable" -> op_createCopyTable(arguments);
            case "dropTable" -> op_dropTable(arguments);
            case "findAllCopyRecords" -> op_findAllCopyRecords(arguments);
            case "findAllRecords" -> op_findAllRecords(arguments);
            case "findStaleTables" -> op_findStaleTables(arguments);
            case "updateCopyRecords" -> op_updateCopyRecords(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_createCopyTable(Object[] arguments) {
        return invoke("createCopyTable", new String[] {"ConnectionSetting", "String", "String"}, arguments, false, false);
    }

    public ExecutionResult op_dropTable(Object[] arguments) {
        return invoke("dropTable", new String[] {"ConnectionSetting", "String", "String"}, arguments, false, false);
    }

    public ExecutionResult op_findAllCopyRecords(Object[] arguments) {
        return invoke("findAllCopyRecords", new String[] {"ConnectionSetting", "String", "String"}, arguments, false, false);
    }

    public ExecutionResult op_findAllRecords(Object[] arguments) {
        return invoke("findAllRecords", new String[] {"ConnectionSetting", "String", "String"}, arguments, false, false);
    }

    public ExecutionResult op_findStaleTables(Object[] arguments) {
        return invoke("findStaleTables", new String[] {"ConnectionSetting", "String"}, arguments, false, false);
    }

    public ExecutionResult op_updateCopyRecords(Object[] arguments) {
        return invoke("updateCopyRecords", new String[] {"ConnectionSetting", "String", "String", "List<Map<String,Object>>"}, arguments, false, false);
    }
}

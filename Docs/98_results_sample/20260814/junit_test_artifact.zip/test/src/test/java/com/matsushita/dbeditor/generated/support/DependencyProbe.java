package com.matsushita.dbeditor.generated.support;

import java.util.List;
import org.mockito.Mockito;
import org.mockito.invocation.Invocation;

public final class DependencyProbe {
    private DependencyProbe() {}

    public static int invocationCount(List<Object> mocks) {
        int count = 0;
        for (Object mock : mocks) if (mock != null && Mockito.mockingDetails(mock).isMock())
            count += Mockito.mockingDetails(mock).getInvocations().size();
        return count;
    }

    public static boolean containsTarget(List<Object> mocks, Object target, String targetName) {
        for (Object mock : mocks) {
            if (mock == null || !Mockito.mockingDetails(mock).isMock()) continue;
            for (Invocation invocation : Mockito.mockingDetails(mock).getInvocations()) {
                for (Object arg : invocation.getArguments()) {
                    if (target == null) {
                        if (arg == null || ObjectProbe.deepFieldEquals(arg, targetName, null)) return true;
                    } else if (ObjectProbe.deepContains(arg, target)) return true;
                }
            }
        }
        return false;
    }
}

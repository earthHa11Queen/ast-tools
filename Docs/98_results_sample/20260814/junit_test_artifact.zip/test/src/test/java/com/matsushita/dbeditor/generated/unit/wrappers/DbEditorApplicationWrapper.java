package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class DbEditorApplicationWrapper extends BaseWrapper {
    public DbEditorApplicationWrapper() { super("com.matsushita.dbeditor.DbEditorApplication", ""); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "main" -> op_main(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_main(Object[] arguments) {
        return invoke("main", new String[] {"String[]"}, arguments, true, false);
    }
}

package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class GlobalExceptionHandlerWrapper extends BaseWrapper {
    public GlobalExceptionHandlerWrapper() { super("com.matsushita.dbeditor.infrastructure.exception.GlobalExceptionHandler", ""); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "handleIllegalArgument" -> op_handleIllegalArgument(arguments);
            case "handleRuntime" -> op_handleRuntime(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_handleIllegalArgument(Object[] arguments) {
        return invoke("handleIllegalArgument", new String[] {"IllegalArgumentException"}, arguments, false, false);
    }

    public ExecutionResult op_handleRuntime(Object[] arguments) {
        return invoke("handleRuntime", new String[] {"RuntimeException"}, arguments, false, false);
    }
}

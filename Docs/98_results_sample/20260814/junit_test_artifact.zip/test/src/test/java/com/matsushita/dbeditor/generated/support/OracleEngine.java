package com.matsushita.dbeditor.generated.support;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public final class OracleEngine {
    private OracleEngine() {}

    public static void verify(CaseDefinition d, ArgumentBundle b, ExecutionResult r) {
        String message = d.caseNo() + " | observation=" + d.observation() + " | expected=" + d.expected()
                + " | failure=" + d.failureDiscrimination();
        switch (d.oracleKind()) {
            case "VALIDATION_REJECTION" -> { assertTrue(ValidationProbe.hasViolation(b.arguments()), message); return; }
            case "IDENTIFIER_VALIDATE" -> { verifyIdentifier(b.targetValue(), r, message); return; }
            case "CONSTRUCTOR_CREATED" -> { noError(r, message); assertNotNull(r.actual(), message); return; }
            case "PREFIX_COPY", "PREFIX_BACKUP", "PREFIX_HISTORY", "QUOTED_REAL", "QUOTED_COPY", "QUOTED_BACKUP", "QUOTED_HISTORY" -> {
                verifyIdentifierTransform(d, b, r, message); return;
            }
            default -> noError(r, message);
        }
        switch (d.oracleKind()) {
            case "RETURN_MAPPING" -> verifyReturnMapping(d, b, r.actual(), message);
            case "MEMO_EMPTY" -> verifyMemoEmpty(b, r.actual(), message);
            case "SQL_EXECUTE_FACTORY" -> verifySqlFactory(d, b, r.actual(), message);
            case "HEALTH_UP" -> verifyHealth(r.actual(), message);
            case "EXCEPTION_RESPONSE" -> verifyExceptionResponse(b, r.actual(), message);
            case "DATABASE_URL" -> verifyDatabaseUrl(b, r.actual(), message);
            case "DATA_SOURCE_CONFIGURATION" -> verifyDataSource(b, r.actual(), message);
            case "JDBC_TEMPLATE_CONFIGURATION" -> verifyJdbcTemplate(b, r.actual(), message);
            case "CONNECTION_PROBE" -> assertEquals(Boolean.TRUE, r.actual(), message);
            case "DEPENDENCY_EFFECT" -> assertTrue(DependencyProbe.invocationCount(r.dependencyMocks()) > 0
                    && DependencyProbe.containsTarget(r.dependencyMocks(), b.targetValue(), d.targetName()), message);
            case "NO_ARGUMENT_RESULT" -> verifyNoArgumentResult(r, message);
            case "NORMALIZATION" -> verifyNormalization(d, b, r.actual(), message);
            case "SQL_TYPE_SANITIZATION" -> verifySqlType(r.actual(), message);
            case "CSV_PARSE" -> verifyCsvParse(r.actual(), message);
            case "CSV_SERIALIZE" -> verifyCsvSerialize(b, r.actual(), message);
            case "MAIN_ENTRYPOINT" -> assertNull(r.actual(), message);
            case "OUTPUT_OR_DEPENDENCY_RELATION" -> assertTrue(
                    outputContainsTarget(d, r.actual(), b.targetValue())
                            || DependencyProbe.containsTarget(r.dependencyMocks(), b.targetValue(), d.targetName()), message);
            default -> fail("Unknown Oracle kind: " + d.oracleKind());
        }
    }

    private static void noError(ExecutionResult r, String message) {
        if (r.thrown() != null) fail(message, r.thrown());
    }

    private static Object arg(ArgumentBundle b, String name) {
        for (Map.Entry<String, Object> e : b.values().entrySet()) if (e.getKey().equals(name) || e.getKey().endsWith("." + name)) return e.getValue();
        return null;
    }

    private static String quote(Object value) { return "\"" + value + "\""; }

    private static void verifyIdentifier(Object target, ExecutionResult r, String message) {
        boolean valid = validIdentifier(target);
        if (valid) { noError(r, message); assertEquals(target, r.actual(), message); }
        else assertInstanceOf(IllegalArgumentException.class, r.thrown(), message);
    }

    private static boolean validIdentifier(Object value) {
        return value instanceof String s && s.matches("[A-Za-z_][A-Za-z0-9_]*");
    }

    private static void verifyIdentifierTransform(CaseDefinition d, ArgumentBundle b, ExecutionResult r, String message) {
        Object schema = arg(b, "schemaName");
        Object table = arg(b, "tableName");
        boolean needsSchema = d.oracleKind().startsWith("QUOTED");
        boolean valid = (!needsSchema || validIdentifier(schema)) && validIdentifier(table);
        if (!valid) { assertInstanceOf(IllegalArgumentException.class, r.thrown(), message); return; }
        noError(r, message);
        Object expected = switch (d.oracleKind()) {
            case "PREFIX_COPY" -> "copy_" + table;
            case "PREFIX_BACKUP" -> "backup_" + table;
            case "PREFIX_HISTORY" -> "history_" + table + "_" + arg(b, "seq");
            case "QUOTED_REAL" -> quote(schema) + "." + quote(table);
            case "QUOTED_COPY" -> quote(schema) + "." + quote("copy_" + table);
            case "QUOTED_BACKUP" -> quote(schema) + "." + quote("backup_" + table);
            case "QUOTED_HISTORY" -> quote(schema) + "." + quote("history_" + table + "_" + arg(b, "seq"));
            default -> throw new IllegalStateException(d.oracleKind());
        };
        assertEquals(expected, r.actual(), message);
    }

    private static void verifyMemoEmpty(ArgumentBundle b, Object actual, String message) {
        assertEquals(arg(b, "connectionId"), ObjectProbe.field(actual, "connectionId"), message);
        assertEquals(arg(b, "tableName"), ObjectProbe.field(actual, "tableName"), message);
        Object content = ObjectProbe.field(actual, "content");
        assertTrue(content == null || Objects.equals(content, ""), message);
    }

    private static void verifySqlFactory(CaseDefinition d, ArgumentBundle b, Object actual, String message) {
        String field = switch (d.methodName()) { case "ofSelect" -> "rows"; case "ofDml" -> "affectedRows"; default -> "errorMessage"; };
        assertEquals(b.targetValue(), ObjectProbe.field(actual, field), message);
    }

    private static void verifyReturnMapping(CaseDefinition d, ArgumentBundle b, Object actual, String message) {
        String source = d.targetName();
        String simple = d.sutClass().substring(d.sutClass().lastIndexOf('.') + 1);
        String output = source;
        boolean excluded = false;
        if (source.equals("dbConnectionId")) output = "connectionId";
        else if (source.equals("dbTableName")) output = "tableName";
        else if (source.equals("titleSql") || source.equals("titleMemo")) output = "title";
        else if (source.equals("contentSql") || source.equals("contentMemo")) output = "content";
        if (simple.equals("ConnectionSettingResponse") && source.equals("dbPassword")) excluded = true;
        if (simple.equals("SqlResponse") && (source.equals("createdTimestamp") || source.equals("updatedTimestamp")
                || (d.methodName().equals("summaryFromEntity") && source.equals("contentSql")))) excluded = true;
        if (simple.equals("MemoResponse") && (source.equals("n") || source.equals("createdTimestamp") || source.equals("updatedTimestamp"))) excluded = true;
        if (simple.equals("TemplateResponse") && source.equals("createdTimestamp")) excluded = true;
        if (excluded && simple.equals("SqlResponse") && d.methodName().equals("summaryFromEntity") && source.equals("contentSql"))
            assertNull(ObjectProbe.field(actual, "content"), message);
        else if (excluded && b.targetValue() != null) assertFalse(ObjectProbe.deepContains(actual, b.targetValue()), message);
        else if (excluded) assertNull(ObjectProbe.field(actual, source), message);
        else assertEquals(b.targetValue(), ObjectProbe.field(actual, output), message);
    }

    private static boolean outputContainsTarget(CaseDefinition d, Object actual, Object target) {
        return target == null ? ObjectProbe.deepFieldEquals(actual, d.targetName(), null) : ObjectProbe.deepContains(actual, target);
    }

    private static void verifyHealth(Object response, String message) {
        Object body = ObjectProbe.unwrapResponse(response);
        assertTrue(body instanceof Map<?, ?> map && Objects.equals(map.get("status"), "UP"), message);
    }

    private static void verifyExceptionResponse(ArgumentBundle b, Object response, String message) {
        Object body = ObjectProbe.unwrapResponse(response);
        Object ex = b.arguments().length == 0 ? null : b.arguments()[0];
        String expectedMessage = ex instanceof Throwable t ? t.getMessage() : null;
        assertTrue(body instanceof Map<?, ?> map && map.values().stream().anyMatch(v -> Objects.equals(v, expectedMessage)), message);
        try {
            Object status = response.getClass().getMethod("getStatusCode").invoke(response);
            boolean error = (boolean) status.getClass().getMethod("isError").invoke(status);
            assertTrue(error, message);
        } catch (ReflectiveOperationException e) { fail(message, e); }
    }

    private static Object setting(ArgumentBundle b) { return b.arguments().length == 0 ? null : b.arguments()[0]; }
    private static String expectedUrl(Object s) {
        return "jdbc:postgresql://" + ObjectProbe.field(s, "dbHost") + ":" + ObjectProbe.field(s, "dbPort") + "/" + ObjectProbe.field(s, "databaseName");
    }
    private static void verifyDatabaseUrl(ArgumentBundle b, Object actual, String message) { assertEquals(expectedUrl(setting(b)), actual, message); }
    private static void verifyDataSource(ArgumentBundle b, Object actual, String message) {
        Object s = setting(b);
        assertEquals(expectedUrl(s), invokeGetter(actual, "getUrl"), message);
        assertEquals(ObjectProbe.field(s, "dbUsername"), invokeGetter(actual, "getUsername"), message);
        assertEquals(ObjectProbe.field(s, "dbPassword"), invokeGetter(actual, "getPassword"), message);
    }
    private static void verifyJdbcTemplate(ArgumentBundle b, Object actual, String message) {
        assertNotNull(actual, message);
        Object dataSource = invokeGetter(actual, "getDataSource");
        assertNotNull(dataSource, message);
        verifyDataSource(b, dataSource, message);
    }
    private static Object invokeGetter(Object target, String name) {
        try { return target.getClass().getMethod(name).invoke(target); }
        catch (ReflectiveOperationException e) { throw new AssertionError("Cannot observe " + name, e); }
    }

    private static void verifyNoArgumentResult(ExecutionResult r, String message) {
        Object actual = ObjectProbe.unwrapResponse(r.actual());
        assertNotNull(actual, message);
        assertTrue(actual instanceof Collection<?> || actual instanceof Map<?, ?> || DependencyProbe.invocationCount(r.dependencyMocks()) > 0, message);
    }

    private static void verifyNormalization(CaseDefinition d, ArgumentBundle b, Object actual, String message) {
        Object input = b.targetValue();
        if (input == null) assertNull(actual, message); else assertNotNull(actual, message);
        // Stability is checked from the observable result shape; the exact normalization alphabet is not invented.
        if (actual instanceof String s) assertEquals(s, s.trim().toLowerCase(), message);
    }
    private static void verifySqlType(Object actual, String message) {
        assertInstanceOf(String.class, actual, message);
        assertTrue(((String) actual).matches("[A-Z]+(?:\\([0-9,]+\\))?"), message);
    }
    private static void verifyCsvParse(Object actual, String message) {
        assertNotNull(actual, message);
        assertTrue(actual instanceof List<?> || actual.getClass().isArray(), message);
    }
    private static void verifyCsvSerialize(ArgumentBundle b, Object actual, String message) {
        assertInstanceOf(String.class, actual, message);
        Object fields = b.arguments().length == 0 ? null : b.arguments()[0];
        if (fields instanceof List<?> list) {
            String expected = list.stream().map(OracleEngine::csvField).collect(java.util.stream.Collectors.joining(","));
            assertEquals(expected, actual, message);
        }
    }
    private static String csvField(Object field) {
        String value = String.valueOf(field);
        if (value.contains(",") || value.contains("\"") || value.contains("\n") || value.contains("\r"))
            return "\"" + value.replace("\"", "\"\"") + "\"";
        return value;
    }
}

package com.matsushita.dbeditor.generated.support;

import java.util.Map;

public record ArgumentBundle(Object[] arguments, Object targetValue, Map<String, Object> values) {}

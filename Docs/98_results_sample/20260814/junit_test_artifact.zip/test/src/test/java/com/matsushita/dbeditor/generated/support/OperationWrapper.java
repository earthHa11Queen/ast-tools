package com.matsushita.dbeditor.generated.support;

public interface OperationWrapper {
    ExecutionResult execute(CaseDefinition definition, Object[] arguments);
}

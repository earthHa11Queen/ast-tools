package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class TableConflictGatewayWrapper extends BaseWrapper {
    public TableConflictGatewayWrapper() { super("com.matsushita.dbeditor.adapter.gateway.TableConflictGateway", ""); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "applyToReal" -> op_applyToReal(arguments);
            case "calcDiff" -> op_calcDiff(arguments);
            case "createBackup" -> op_createBackup(arguments);
            case "hasConflict" -> op_hasConflict(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_applyToReal(Object[] arguments) {
        return invoke("applyToReal", new String[] {"ConnectionSetting", "String", "String"}, arguments, false, false);
    }

    public ExecutionResult op_calcDiff(Object[] arguments) {
        return invoke("calcDiff", new String[] {"ConnectionSetting", "String", "String"}, arguments, false, false);
    }

    public ExecutionResult op_createBackup(Object[] arguments) {
        return invoke("createBackup", new String[] {"ConnectionSetting", "String", "String"}, arguments, false, false);
    }

    public ExecutionResult op_hasConflict(Object[] arguments) {
        return invoke("hasConflict", new String[] {"ConnectionSetting", "String", "String"}, arguments, false, false);
    }
}

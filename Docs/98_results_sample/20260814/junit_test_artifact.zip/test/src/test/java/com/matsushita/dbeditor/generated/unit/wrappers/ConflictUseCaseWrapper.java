package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class ConflictUseCaseWrapper extends BaseWrapper {
    public ConflictUseCaseWrapper() { super("com.matsushita.dbeditor.usecase.conflict.ConflictUseCase", ""); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "applyToReal" -> op_applyToReal(arguments);
            case "calcDiff" -> op_calcDiff(arguments);
            case "createBackup" -> op_createBackup(arguments);
            case "getConnection" -> op_getConnection(arguments);
            case "hasConflict" -> op_hasConflict(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_applyToReal(Object[] arguments) {
        return invoke("applyToReal", new String[] {"Integer", "String", "String"}, arguments, false, false);
    }

    public ExecutionResult op_calcDiff(Object[] arguments) {
        return invoke("calcDiff", new String[] {"Integer", "String", "String"}, arguments, false, false);
    }

    public ExecutionResult op_createBackup(Object[] arguments) {
        return invoke("createBackup", new String[] {"Integer", "String", "String"}, arguments, false, false);
    }

    public ExecutionResult op_getConnection(Object[] arguments) {
        return invoke("getConnection", new String[] {"Integer"}, arguments, false, false);
    }

    public ExecutionResult op_hasConflict(Object[] arguments) {
        return invoke("hasConflict", new String[] {"Integer", "String", "String"}, arguments, false, false);
    }
}

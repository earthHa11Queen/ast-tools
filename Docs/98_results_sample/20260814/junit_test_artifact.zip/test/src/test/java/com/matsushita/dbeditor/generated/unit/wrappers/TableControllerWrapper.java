package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class TableControllerWrapper extends BaseWrapper {
    public TableControllerWrapper() { super("com.matsushita.dbeditor.adapter.controller.TableController", ""); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "applyToReal" -> op_applyToReal(arguments);
            case "conflictCheck" -> op_conflictCheck(arguments);
            case "conflictDiff" -> op_conflictDiff(arguments);
            case "createBackup" -> op_createBackup(arguments);
            case "createCopy" -> op_createCopy(arguments);
            case "dropStaleTable" -> op_dropStaleTable(arguments);
            case "getHistoryList" -> op_getHistoryList(arguments);
            case "getRecords" -> op_getRecords(arguments);
            case "getStaleTables" -> op_getStaleTables(arguments);
            case "getTables" -> op_getTables(arguments);
            case "restoreHistory" -> op_restoreHistory(arguments);
            case "saveHistory" -> op_saveHistory(arguments);
            case "updateCopyRecords" -> op_updateCopyRecords(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_applyToReal(Object[] arguments) {
        return invoke("applyToReal", new String[] {"String", "ConflictCheckRequest"}, arguments, false, false);
    }

    public ExecutionResult op_conflictCheck(Object[] arguments) {
        return invoke("conflictCheck", new String[] {"String", "ConflictCheckRequest"}, arguments, false, false);
    }

    public ExecutionResult op_conflictDiff(Object[] arguments) {
        return invoke("conflictDiff", new String[] {"String", "ConflictCheckRequest"}, arguments, false, false);
    }

    public ExecutionResult op_createBackup(Object[] arguments) {
        return invoke("createBackup", new String[] {"String", "ConflictCheckRequest"}, arguments, false, false);
    }

    public ExecutionResult op_createCopy(Object[] arguments) {
        return invoke("createCopy", new String[] {"String", "Integer", "String"}, arguments, false, false);
    }

    public ExecutionResult op_dropStaleTable(Object[] arguments) {
        return invoke("dropStaleTable", new String[] {"Integer", "String", "String"}, arguments, false, false);
    }

    public ExecutionResult op_getHistoryList(Object[] arguments) {
        return invoke("getHistoryList", new String[] {"String", "Integer", "String"}, arguments, false, false);
    }

    public ExecutionResult op_getRecords(Object[] arguments) {
        return invoke("getRecords", new String[] {"String", "Integer", "String"}, arguments, false, false);
    }

    public ExecutionResult op_getStaleTables(Object[] arguments) {
        return invoke("getStaleTables", new String[] {"Integer", "String"}, arguments, false, false);
    }

    public ExecutionResult op_getTables(Object[] arguments) {
        return invoke("getTables", new String[] {"Integer"}, arguments, false, false);
    }

    public ExecutionResult op_restoreHistory(Object[] arguments) {
        return invoke("restoreHistory", new String[] {"String", "int", "Integer", "String"}, arguments, false, false);
    }

    public ExecutionResult op_saveHistory(Object[] arguments) {
        return invoke("saveHistory", new String[] {"String", "TableHistorySaveRequest"}, arguments, false, false);
    }

    public ExecutionResult op_updateCopyRecords(Object[] arguments) {
        return invoke("updateCopyRecords", new String[] {"String", "TableRecordUpdateRequest"}, arguments, false, false);
    }
}

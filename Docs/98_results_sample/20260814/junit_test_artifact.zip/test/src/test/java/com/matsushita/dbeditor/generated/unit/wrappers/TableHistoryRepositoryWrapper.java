package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class TableHistoryRepositoryWrapper extends BaseWrapper {
    public TableHistoryRepositoryWrapper() { super("com.matsushita.dbeditor.domain.repository.TableHistoryRepository", "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway"); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "findHistoryList" -> op_findHistoryList(arguments);
            case "findHistoryRecords" -> op_findHistoryRecords(arguments);
            case "restoreHistory" -> op_restoreHistory(arguments);
            case "saveHistory" -> op_saveHistory(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_findHistoryList(Object[] arguments) {
        return invoke("findHistoryList", new String[] {"ConnectionSetting", "String", "String"}, arguments, false, false);
    }

    public ExecutionResult op_findHistoryRecords(Object[] arguments) {
        return invoke("findHistoryRecords", new String[] {"ConnectionSetting", "String", "String", "int"}, arguments, false, false);
    }

    public ExecutionResult op_restoreHistory(Object[] arguments) {
        return invoke("restoreHistory", new String[] {"ConnectionSetting", "String", "String", "int"}, arguments, false, false);
    }

    public ExecutionResult op_saveHistory(Object[] arguments) {
        return invoke("saveHistory", new String[] {"ConnectionSetting", "String", "String", "List<Map<String,Object>>"}, arguments, false, false);
    }
}

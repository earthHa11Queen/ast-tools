package com.matsushita.dbeditor.generated.support;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

public final class SemanticMocks {
    private SemanticMocks() {}

    public static Object mock(Class<?> type, List<Object> registry) {
        Answer<Object> answer = invocation -> answer(invocation, registry);
        Object value = Mockito.mock(type, answer);
        registry.add(value);
        return value;
    }

    private static Object answer(InvocationOnMock invocation, List<Object> registry) {
        Class<?> returnType = invocation.getMethod().getReturnType();
        Object[] args = invocation.getArguments();
        String name = invocation.getMethod().getName();
        if ((name.startsWith("save") || name.startsWith("update") || name.equals("upsert")) && args.length > 0
                && args[0] != null && returnType.isInstance(args[0])) return args[0];
        if (name.equals("queryForObject")) {
            for (Object arg : args) if (arg instanceof Class<?> requested) return scalarDefault(requested);
        }
        if (returnType == void.class) return null;
        if (returnType == boolean.class || returnType == Boolean.class) return true;
        if (returnType == int.class || returnType == Integer.class) return 1;
        if (returnType == long.class || returnType == Long.class) return 1L;
        if (returnType == double.class || returnType == Double.class) return 1.0d;
        if (returnType == float.class || returnType == Float.class) return 1.0f;
        if (returnType == String.class) return "runtime-stub";
        if (returnType == byte[].class) return new byte[0];
        if (Optional.class.isAssignableFrom(returnType)) {
            Class<?> item = genericClass(invocation.getMethod().getGenericReturnType());
            return item == null ? Optional.empty() : Optional.of(mock(item, registry));
        }
        if (List.class.isAssignableFrom(returnType) || Collection.class.isAssignableFrom(returnType)) return new ArrayList<>();
        if (Map.class.isAssignableFrom(returnType)) return Collections.emptyMap();
        if (returnType.isPrimitive()) return scalarDefault(returnType);
        return mock(returnType, registry);
    }

    private static Object scalarDefault(Class<?> type) {
        if (type == int.class || type == Integer.class) return 1;
        if (type == long.class || type == Long.class) return 1L;
        if (type == boolean.class || type == Boolean.class) return true;
        if (type == double.class || type == Double.class) return 1.0d;
        if (type == float.class || type == Float.class) return 1.0f;
        if (type == short.class || type == Short.class) return (short) 1;
        if (type == byte.class || type == Byte.class) return (byte) 1;
        if (type == char.class || type == Character.class) return 'a';
        return null;
    }

    private static Class<?> genericClass(Type type) {
        if (!(type instanceof ParameterizedType p)) return null;
        Type arg = p.getActualTypeArguments()[0];
        return arg instanceof Class<?> c ? c : null;
    }
}

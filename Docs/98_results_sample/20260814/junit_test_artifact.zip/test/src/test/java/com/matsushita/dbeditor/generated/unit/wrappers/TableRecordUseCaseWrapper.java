package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class TableRecordUseCaseWrapper extends BaseWrapper {
    public TableRecordUseCaseWrapper() { super("com.matsushita.dbeditor.usecase.table.TableRecordUseCase", ""); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "createCopy" -> op_createCopy(arguments);
            case "dropStaleTable" -> op_dropStaleTable(arguments);
            case "getAllRecords" -> op_getAllRecords(arguments);
            case "getConnection" -> op_getConnection(arguments);
            case "getCopyRecords" -> op_getCopyRecords(arguments);
            case "getStaleTables" -> op_getStaleTables(arguments);
            case "updateCopyRecords" -> op_updateCopyRecords(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_createCopy(Object[] arguments) {
        return invoke("createCopy", new String[] {"Integer", "String", "String"}, arguments, false, false);
    }

    public ExecutionResult op_dropStaleTable(Object[] arguments) {
        return invoke("dropStaleTable", new String[] {"Integer", "String", "String"}, arguments, false, false);
    }

    public ExecutionResult op_getAllRecords(Object[] arguments) {
        return invoke("getAllRecords", new String[] {"Integer", "String", "String"}, arguments, false, false);
    }

    public ExecutionResult op_getConnection(Object[] arguments) {
        return invoke("getConnection", new String[] {"Integer"}, arguments, false, false);
    }

    public ExecutionResult op_getCopyRecords(Object[] arguments) {
        return invoke("getCopyRecords", new String[] {"Integer", "String", "String"}, arguments, false, false);
    }

    public ExecutionResult op_getStaleTables(Object[] arguments) {
        return invoke("getStaleTables", new String[] {"Integer", "String"}, arguments, false, false);
    }

    public ExecutionResult op_updateCopyRecords(Object[] arguments) {
        return invoke("updateCopyRecords", new String[] {"Integer", "String", "String", "List<Map<String,Object>>"}, arguments, false, false);
    }
}

package com.matsushita.dbeditor.generated.support;

import java.lang.reflect.Method;
import java.util.Set;

public final class ValidationProbe {
    private ValidationProbe() {}

    public static boolean hasViolation(Object[] arguments) {
        try {
            Class<?> validation = Class.forName("jakarta.validation.Validation");
            Object factory = validation.getMethod("buildDefaultValidatorFactory").invoke(null);
            Object validator = factory.getClass().getMethod("getValidator").invoke(factory);
            Method validate = validator.getClass().getMethod("validate", Object.class, Class[].class);
            for (Object argument : arguments) {
                if (argument == null) continue;
                Object result = validate.invoke(validator, argument, new Class<?>[0]);
                if (result instanceof Set<?> set && !set.isEmpty()) return true;
            }
            return false;
        } catch (ReflectiveOperationException e) {
            throw new IllegalStateException("Jakarta Validation is required for a validation-rejection CaseNo", e);
        }
    }
}

package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class WebConfigWrapper extends BaseWrapper {
    public WebConfigWrapper() { super("com.matsushita.dbeditor.infrastructure.config.WebConfig", ""); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "addCorsMappings" -> op_addCorsMappings(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_addCorsMappings(Object[] arguments) {
        return invoke("addCorsMappings", new String[] {"CorsRegistry"}, arguments, false, false);
    }
}

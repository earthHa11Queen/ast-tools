package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class GetTableListUseCaseWrapper extends BaseWrapper {
    public GetTableListUseCaseWrapper() { super("com.matsushita.dbeditor.usecase.table.GetTableListUseCase", ""); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "execute" -> op_execute(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_execute(Object[] arguments) {
        return invoke("execute", new String[] {"Integer"}, arguments, false, false);
    }
}

package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class ExportControllerWrapper extends BaseWrapper {
    public ExportControllerWrapper() { super("com.matsushita.dbeditor.adapter.controller.ExportController", ""); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "downloadHeaders" -> op_downloadHeaders(arguments);
            case "export" -> op_export(arguments);
            case "markdown" -> op_markdown(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_downloadHeaders(Object[] arguments) {
        return invoke("downloadHeaders", new String[] {"String", "String"}, arguments, false, false);
    }

    public ExecutionResult op_export(Object[] arguments) {
        return invoke("export", new String[] {"String", "Integer", "String", "String"}, arguments, false, false);
    }

    public ExecutionResult op_markdown(Object[] arguments) {
        return invoke("markdown", new String[] {"String", "Integer", "String"}, arguments, false, false);
    }
}

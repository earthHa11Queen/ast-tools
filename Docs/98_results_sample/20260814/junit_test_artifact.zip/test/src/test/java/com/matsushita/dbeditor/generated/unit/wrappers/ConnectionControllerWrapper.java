package com.matsushita.dbeditor.generated.unit.wrappers;

import com.matsushita.dbeditor.generated.support.BaseWrapper;
import com.matsushita.dbeditor.generated.support.CaseDefinition;
import com.matsushita.dbeditor.generated.support.ExecutionResult;

public final class ConnectionControllerWrapper extends BaseWrapper {
    public ConnectionControllerWrapper() { super("com.matsushita.dbeditor.adapter.controller.ConnectionController", ""); }

    @Override
    public ExecutionResult execute(CaseDefinition definition, Object[] arguments) {
        return switch (definition.methodName()) {
            case "create" -> op_create(arguments);
            case "delete" -> op_delete(arguments);
            case "getAll" -> op_getAll(arguments);
            case "getById" -> op_getById(arguments);
            case "testConnection" -> op_testConnection(arguments);
            case "update" -> op_update(arguments);
            default -> throw new IllegalArgumentException("No AST operation for " + definition.methodName());
        };
    }

    public ExecutionResult op_create(Object[] arguments) {
        return invoke("create", new String[] {"ConnectionSettingRequest"}, arguments, false, false);
    }

    public ExecutionResult op_delete(Object[] arguments) {
        return invoke("delete", new String[] {"Integer"}, arguments, false, false);
    }

    public ExecutionResult op_getAll(Object[] arguments) {
        return invoke("getAll", new String[] {}, arguments, false, false);
    }

    public ExecutionResult op_getById(Object[] arguments) {
        return invoke("getById", new String[] {"Integer"}, arguments, false, false);
    }

    public ExecutionResult op_testConnection(Object[] arguments) {
        return invoke("testConnection", new String[] {"ConnectionTestRequest"}, arguments, false, false);
    }

    public ExecutionResult op_update(Object[] arguments) {
        return invoke("update", new String[] {"Integer", "ConnectionSettingRequest"}, arguments, false, false);
    }
}

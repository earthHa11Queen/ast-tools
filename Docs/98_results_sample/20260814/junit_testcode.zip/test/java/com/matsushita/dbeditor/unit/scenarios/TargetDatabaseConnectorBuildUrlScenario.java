package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TargetDatabaseConnectorWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TargetDatabaseConnector#buildUrl.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TargetDatabaseConnectorBuildUrlScenario {

    @Test
    @DisplayName("UTAPI-011069")
    void case_UTAPI_011069() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011069",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011069", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011069", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011069", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011069", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011069", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011069", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011069", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011069", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011069", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011069", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011069")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on createdTimestamp", "setting", "createdTimestamp", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011070")
    void case_UTAPI_011070() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011070",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011070", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011070", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011070", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011070", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011070", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011070", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011070", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011070", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011070", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011070", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011070")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on createdTimestamp", "setting", "createdTimestamp", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011071")
    void case_UTAPI_011071() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011071",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011071", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011071", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011071", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011071", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011071", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011071", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011071", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011071", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011071", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011071", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011071")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on createdTimestamp", "setting", "createdTimestamp", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011072")
    void case_UTAPI_011072() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011072",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011072", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011072", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011072", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011072", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011072", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011072", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011072", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011072", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011072", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011072", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011072")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on createdTimestamp", "setting", "createdTimestamp", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011073")
    void case_UTAPI_011073() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011073",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011073", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011073", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011073", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011073", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011073", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011073", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011073", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011073", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011073", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011073", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011073")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on createdTimestamp", "setting", "createdTimestamp", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011074")
    void case_UTAPI_011074() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011074",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011074", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011074", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011074", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011074", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011074", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011074", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011074", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011074", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011074", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011074", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011074")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on createdTimestamp", "setting", "createdTimestamp", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011075")
    void case_UTAPI_011075() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011075",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011075", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011075", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011075", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011075", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011075", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011075", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011075", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011075", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011075", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011075", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011075")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on createdTimestamp", "setting", "createdTimestamp", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011076")
    void case_UTAPI_011076() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011076",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011076", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011076", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011076", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011076", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011076", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011076", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011076", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011076", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011076", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011076", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011076")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on createdTimestamp", "setting", "createdTimestamp", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011077")
    void case_UTAPI_011077() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011077",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011077", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011077", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011077", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011077", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011077", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011077", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011077", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011077", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011077", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011077", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011077")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011078")
    void case_UTAPI_011078() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011078",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011078", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011078", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011078", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011078", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011078", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011078", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011078", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011078", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011078", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011078", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011078")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011079")
    void case_UTAPI_011079() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011079",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011079", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011079", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011079", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011079", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011079", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011079", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011079", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011079", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011079", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011079", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011079")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011080")
    void case_UTAPI_011080() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011080",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011080", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011080", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011080", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011080", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011080", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011080", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011080", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011080", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011080", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011080", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011080")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011081")
    void case_UTAPI_011081() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011081",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011081", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011081", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011081", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011081", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011081", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011081", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011081", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011081", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011081", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011081", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011081")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011082")
    void case_UTAPI_011082() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011082",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011082", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011082", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011082", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011082", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011082", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011082", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011082", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011082", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011082", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011082", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011082")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011083")
    void case_UTAPI_011083() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011083",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011083", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011083", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011083", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011083", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011083", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011083", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011083", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011083", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011083", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011083", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011083")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011084")
    void case_UTAPI_011084() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011084",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011084", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011084", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011084", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011084", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011084", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011084", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011084", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011084", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011084", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011084", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011084")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011085")
    void case_UTAPI_011085() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011085",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011085", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011085", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011085", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011085", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011085", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011085", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011085", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011085", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011085", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011085", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011085")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011086")
    void case_UTAPI_011086() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011086",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011086", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011086", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011086", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011086", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011086", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011086", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011086", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011086", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011086", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011086", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011086")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011087")
    void case_UTAPI_011087() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011087",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011087", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011087", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011087", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011087", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011087", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011087", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011087", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011087", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011087", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011087", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011087")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011088")
    void case_UTAPI_011088() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011088",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011088", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011088", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011088", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011088", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011088", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011088", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011088", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011088", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011088", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011088", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011088")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011089")
    void case_UTAPI_011089() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011089",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011089", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011089", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011089", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011089", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011089", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011089", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011089", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011089", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011089", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011089", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011089")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011090")
    void case_UTAPI_011090() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011090",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011090", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011090", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011090", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011090", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011090", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011090", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011090", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011090", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011090", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011090", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011090")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011091")
    void case_UTAPI_011091() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011091",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011091", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011091", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011091", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011091", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011091", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011091", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011091", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011091", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011091", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011091", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011091")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011092")
    void case_UTAPI_011092() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011092",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011092", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011092", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011092", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011092", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011092", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011092", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011092", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011092", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011092", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011092", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011092")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011093")
    void case_UTAPI_011093() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011093",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011093", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011093", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011093", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011093", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011093", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011093", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011093", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011093", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011093", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011093", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011093")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011094")
    void case_UTAPI_011094() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011094",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011094", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011094", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011094", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011094", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011094", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011094", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011094", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011094", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011094", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011094", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011094")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011095")
    void case_UTAPI_011095() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011095",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011095", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011095", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011095", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011095", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011095", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011095", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011095", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011095", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011095", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011095", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011095")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011096")
    void case_UTAPI_011096() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011096",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011096", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011096", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011096", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011096", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011096", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011096", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011096", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011096", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011096", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011096", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011096")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011097")
    void case_UTAPI_011097() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011097",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011097", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011097", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011097", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011097", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011097", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011097", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011097", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011097", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011097", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011097", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011097")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011098")
    void case_UTAPI_011098() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011098",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011098", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011098", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011098", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011098", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011098", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011098", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011098", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011098", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011098", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011098", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011098")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011099")
    void case_UTAPI_011099() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011099",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011099", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011099", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011099", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011099", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011099", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011099", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011099", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011099", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011099", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011099", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011099")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011100")
    void case_UTAPI_011100() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011100",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011100", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011100", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011100", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011100", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011100", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011100", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011100", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011100", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011100", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011100", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011100")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011101")
    void case_UTAPI_011101() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011101",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011101", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011101", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011101", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011101", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011101", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011101", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011101", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011101", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011101", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011101", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011101")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011102")
    void case_UTAPI_011102() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011102",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011102", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011102", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011102", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011102", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011102", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011102", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011102", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011102", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011102", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011102", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011102")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011103")
    void case_UTAPI_011103() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011103",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011103", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011103", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011103", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011103", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011103", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011103", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011103", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011103", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011103", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011103", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011103")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011104")
    void case_UTAPI_011104() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011104",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011104", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011104", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011104", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011104", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011104", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011104", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011104", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011104", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011104", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011104", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011104")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011105")
    void case_UTAPI_011105() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011105",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011105", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011105", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011105", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011105", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011105", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011105", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011105", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011105", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011105", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011105", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011105")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011106")
    void case_UTAPI_011106() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011106",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011106", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011106", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011106", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011106", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011106", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011106", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011106", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011106", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011106", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011106", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011106")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011107")
    void case_UTAPI_011107() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011107",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011107", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011107", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011107", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011107", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011107", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011107", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011107", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011107", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011107", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011107", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011107")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011108")
    void case_UTAPI_011108() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011108",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011108", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011108", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011108", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011108", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011108", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011108", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011108", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011108", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011108", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011108", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011108")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011109")
    void case_UTAPI_011109() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011109",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011109", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011109", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011109", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011109", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011109", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011109", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011109", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011109", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011109", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011109", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011109")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011110")
    void case_UTAPI_011110() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011110",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011110", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011110", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011110", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011110", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011110", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011110", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011110", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011110", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011110", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011110", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011110")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011111")
    void case_UTAPI_011111() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011111",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011111", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011111", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011111", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011111", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011111", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011111", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011111", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011111", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011111", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011111", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011111")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011112")
    void case_UTAPI_011112() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011112",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011112", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011112", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011112", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011112", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011112", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011112", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011112", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011112", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011112", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011112", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011112")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011113")
    void case_UTAPI_011113() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011113",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011113", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011113", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011113", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011113", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011113", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011113", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011113", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011113", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011113", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011113", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011113")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011114")
    void case_UTAPI_011114() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011114",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011114", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011114", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011114", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011114", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011114", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011114", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011114", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011114", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011114", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011114", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011114")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011115")
    void case_UTAPI_011115() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011115",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011115", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011115", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011115", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011115", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011115", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011115", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011115", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011115", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011115", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011115", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011115")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011116")
    void case_UTAPI_011116() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011116",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011116", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011116", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011116", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011116", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011116", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011116", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011116", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011116", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011116", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011116", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011116")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011117")
    void case_UTAPI_011117() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011117",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011117", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011117", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011117", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011117", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011117", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011117", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011117", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011117", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011117", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011117", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011117")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011118")
    void case_UTAPI_011118() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011118",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011118", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011118", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011118", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011118", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011118", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011118", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011118", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011118", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011118", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011118", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011118")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011119")
    void case_UTAPI_011119() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011119",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011119", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011119", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011119", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011119", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011119", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011119", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011119", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011119", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011119", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011119", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011119")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011120")
    void case_UTAPI_011120() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011120",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011120", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011120", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011120", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011120", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011120", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011120", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011120", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011120", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011120", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011120", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011120")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011121")
    void case_UTAPI_011121() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011121",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011121", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011121", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011121", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011121", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011121", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011121", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011121", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011121", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011121", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011121", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011121")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011122")
    void case_UTAPI_011122() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011122",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011122", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011122", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011122", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011122", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011122", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011122", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011122", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011122", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011122", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011122", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011122")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011123")
    void case_UTAPI_011123() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011123",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011123", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011123", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011123", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011123", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011123", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011123", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011123", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011123", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011123", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011123", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011123")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011124")
    void case_UTAPI_011124() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011124",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011124", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011124", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011124", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011124", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011124", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011124", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011124", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011124", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011124", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011124", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011124")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011125")
    void case_UTAPI_011125() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011125",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011125", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011125", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011125", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011125", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011125", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011125", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011125", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011125", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011125", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011125", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011125")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011126")
    void case_UTAPI_011126() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011126",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011126", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011126", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011126", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011126", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011126", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011126", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011126", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011126", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011126", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011126", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011126")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011127")
    void case_UTAPI_011127() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011127",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011127", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011127", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011127", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011127", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011127", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011127", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011127", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011127", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011127", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011127", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011127")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011128")
    void case_UTAPI_011128() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011128",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011128", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011128", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011128", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011128", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011128", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011128", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011128", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011128", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011128", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011128", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011128")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011129")
    void case_UTAPI_011129() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011129",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011129", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011129", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011129", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011129", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011129", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011129", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011129", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011129", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011129", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011129", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011129")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011130")
    void case_UTAPI_011130() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011130",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011130", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011130", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011130", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011130", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011130", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011130", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011130", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011130", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011130", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011130", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011130")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011131")
    void case_UTAPI_011131() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011131",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011131", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011131", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011131", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011131", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011131", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011131", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011131", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011131", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011131", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011131", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011131")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011132")
    void case_UTAPI_011132() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011132",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011132", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011132", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011132", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011132", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011132", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011132", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011132", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011132", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011132", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011132", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011132")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011133")
    void case_UTAPI_011133() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011133",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011133", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011133", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011133", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011133", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011133", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011133", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011133", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011133", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011133", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011133", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011133")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011134")
    void case_UTAPI_011134() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011134",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011134", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011134", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011134", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011134", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011134", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011134", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011134", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011134", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011134", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011134", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011134")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011135")
    void case_UTAPI_011135() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011135",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011135", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011135", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011135", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011135", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011135", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011135", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011135", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011135", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011135", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011135", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011135")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011136")
    void case_UTAPI_011136() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011136",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011136", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011136", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011136", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011136", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011136", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011136", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011136", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011136", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011136", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011136", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011136")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011137")
    void case_UTAPI_011137() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011137",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011137", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011137", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011137", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011137", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011137", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011137", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011137", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011137", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011137", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011137", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011137")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011138")
    void case_UTAPI_011138() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011138",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011138", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011138", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011138", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011138", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011138", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011138", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011138", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011138", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011138", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011138", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011138")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011139")
    void case_UTAPI_011139() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011139",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011139", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011139", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011139", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011139", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011139", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011139", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011139", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011139", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011139", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011139", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011139")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011140")
    void case_UTAPI_011140() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011140",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011140", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011140", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011140", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011140", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011140", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011140", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011140", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011140", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011140", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011140", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011140")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011141")
    void case_UTAPI_011141() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011141",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011141", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011141", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011141", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011141", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011141", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011141", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011141", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011141", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011141", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011141", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011141")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011142")
    void case_UTAPI_011142() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011142",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011142", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011142", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011142", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011142", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011142", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011142", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011142", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011142", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011142", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011142", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011142")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011143")
    void case_UTAPI_011143() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011143",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011143", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011143", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011143", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011143", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011143", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011143", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011143", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011143", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011143", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011143", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011143")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011144")
    void case_UTAPI_011144() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011144",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011144", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011144", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011144", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011144", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011144", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011144", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011144", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011144", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011144", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011144", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011144")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011145")
    void case_UTAPI_011145() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011145",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011145", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011145", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011145", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011145", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011145", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011145", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011145", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011145", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011145", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011145", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011145")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011146")
    void case_UTAPI_011146() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011146",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011146", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011146", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011146", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011146", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011146", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011146", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011146", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011146", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011146", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011146", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011146")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011147")
    void case_UTAPI_011147() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011147",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011147", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011147", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011147", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011147", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011147", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011147", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011147", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011147", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011147", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011147", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011147")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011148")
    void case_UTAPI_011148() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011148",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011148", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011148", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011148", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011148", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011148", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011148", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011148", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011148", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011148", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011148", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011148")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011149")
    void case_UTAPI_011149() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011149",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011149", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011149", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011149", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011149", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011149", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011149", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011149", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011149", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011149", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011149", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011149")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011150")
    void case_UTAPI_011150() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011150",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011150", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011150", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011150", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011150", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011150", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011150", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011150", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011150", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011150", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011150", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011150")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011151")
    void case_UTAPI_011151() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011151",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011151", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011151", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011151", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011151", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011151", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011151", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011151", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011151", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011151", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011151", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011151")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011152")
    void case_UTAPI_011152() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011152",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011152", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011152", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011152", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011152", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011152", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011152", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011152", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011152", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011152", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011152", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011152")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011153")
    void case_UTAPI_011153() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011153",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011153", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011153", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011153", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011153", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011153", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011153", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011153", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011153", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011153", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011153", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011153")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011154")
    void case_UTAPI_011154() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011154",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011154", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011154", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011154", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011154", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011154", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011154", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011154", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011154", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011154", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011154", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011154")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011155")
    void case_UTAPI_011155() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011155",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011155", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011155", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011155", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011155", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011155", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011155", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011155", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011155", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011155", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011155", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011155")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011156")
    void case_UTAPI_011156() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011156",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011156", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011156", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011156", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011156", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011156", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011156", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011156", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011156", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011156", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011156", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011156")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011157")
    void case_UTAPI_011157() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011157",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011157", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011157", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011157", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011157", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011157", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011157", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011157", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011157", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011157", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011157", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011157")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011158")
    void case_UTAPI_011158() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011158",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011158", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011158", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011158", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011158", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011158", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011158", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011158", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011158", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011158", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011158", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011158")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011159")
    void case_UTAPI_011159() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011159",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011159", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011159", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011159", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011159", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011159", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011159", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011159", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011159", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011159", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011159", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011159")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011160")
    void case_UTAPI_011160() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011160",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011160", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011160", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011160", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011160", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011160", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011160", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011160", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011160", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011160", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011160", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011160")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011161")
    void case_UTAPI_011161() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011161",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011161", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011161", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011161", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011161", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011161", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011161", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011161", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011161", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011161", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011161", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011161")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011162")
    void case_UTAPI_011162() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011162",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011162", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011162", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011162", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011162", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011162", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011162", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011162", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011162", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011162", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011162", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011162")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011163")
    void case_UTAPI_011163() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011163",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011163", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011163", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011163", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011163", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011163", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011163", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011163", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011163", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011163", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011163", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011163")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011164")
    void case_UTAPI_011164() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011164",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011164", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011164", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011164", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011164", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011164", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011164", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011164", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011164", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011164", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011164", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011164")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011165")
    void case_UTAPI_011165() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011165",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011165", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011165", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011165", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011165", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011165", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011165", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011165", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011165", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011165", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011165", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011165")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011166")
    void case_UTAPI_011166() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011166",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011166", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011166", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011166", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011166", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011166", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011166", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011166", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011166", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011166", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011166", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011166")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011167")
    void case_UTAPI_011167() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011167",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011167", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011167", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011167", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011167", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011167", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011167", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011167", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011167", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011167", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011167", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011167")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011168")
    void case_UTAPI_011168() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011168",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011168", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011168", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011168", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011168", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011168", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011168", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011168", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011168", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011168", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011168", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011168")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011169")
    void case_UTAPI_011169() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011169",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011169", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011169", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011169", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011169", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011169", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011169", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011169", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011169", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011169", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011169", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011169")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011170")
    void case_UTAPI_011170() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011170",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011170", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011170", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011170", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011170", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011170", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011170", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011170", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011170", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011170", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011170", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011170")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbUsername", "setting", "dbUsername", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011171")
    void case_UTAPI_011171() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011171",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011171", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011171", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011171", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011171", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011171", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011171", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011171", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011171", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011171", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011171", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011171")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbUsername", "setting", "dbUsername", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011172")
    void case_UTAPI_011172() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011172",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011172", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011172", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011172", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011172", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011172", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011172", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011172", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011172", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011172", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011172", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011172")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbUsername", "setting", "dbUsername", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011173")
    void case_UTAPI_011173() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011173",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011173", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011173", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011173", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011173", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011173", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011173", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011173", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011173", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011173", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011173", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011173")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbUsername", "setting", "dbUsername", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011174")
    void case_UTAPI_011174() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011174",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011174", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011174", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011174", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011174", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011174", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011174", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011174", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011174", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011174", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011174", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011174")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbUsername", "setting", "dbUsername", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011175")
    void case_UTAPI_011175() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011175",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011175", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011175", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011175", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011175", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011175", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011175", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011175", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011175", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011175", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011175", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011175")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbUsername", "setting", "dbUsername", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011176")
    void case_UTAPI_011176() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011176",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011176", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011176", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011176", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011176", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011176", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011176", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011176", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011176", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011176", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011176", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011176")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbUsername", "setting", "dbUsername", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011177")
    void case_UTAPI_011177() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011177",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011177", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011177", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011177", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011177", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011177", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011177", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011177", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011177", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011177", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011177", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011177")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbUsername", "setting", "dbUsername", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011178")
    void case_UTAPI_011178() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011178",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011178", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011178", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011178", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011178", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011178", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011178", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011178", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011178", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011178", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011178", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011178")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbUsername", "setting", "dbUsername", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011179")
    void case_UTAPI_011179() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011179",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011179", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011179", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011179", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011179", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011179", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011179", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011179", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011179", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011179", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011179", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011179")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbUsername", "setting", "dbUsername", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011180")
    void case_UTAPI_011180() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011180",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011180", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011180", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011180", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011180", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011180", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011180", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011180", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011180", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011180", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011180", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011180")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbUsername", "setting", "dbUsername", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011181")
    void case_UTAPI_011181() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011181",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011181", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011181", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011181", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011181", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011181", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011181", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011181", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011181", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011181", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011181", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011181")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbUsername", "setting", "dbUsername", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011182")
    void case_UTAPI_011182() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011182",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011182", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011182", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011182", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011182", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011182", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011182", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011182", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011182", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011182", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011182", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011182")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbUsername", "setting", "dbUsername", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011183")
    void case_UTAPI_011183() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011183",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011183", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011183", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011183", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011183", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011183", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011183", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011183", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011183", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011183", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011183", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011183")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbUsername", "setting", "dbUsername", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011184")
    void case_UTAPI_011184() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011184",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011184", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011184", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011184", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011184", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011184", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011184", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011184", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011184", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011184", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011184", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011184")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbUsername", "setting", "dbUsername", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011185")
    void case_UTAPI_011185() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011185",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011185", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011185", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011185", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011185", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011185", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011185", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011185", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011185", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011185", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011185", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011185")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbUsername", "setting", "dbUsername", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011186")
    void case_UTAPI_011186() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011186",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011186", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011186", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011186", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011186", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011186", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011186", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011186", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011186", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011186", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011186", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011186")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbUsername", "setting", "dbUsername", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011187")
    void case_UTAPI_011187() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011187",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011187", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011187", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011187", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011187", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011187", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011187", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011187", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011187", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011187", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011187", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011187")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbUsername", "setting", "dbUsername", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011188")
    void case_UTAPI_011188() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011188",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011188", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011188", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011188", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011188", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011188", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011188", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011188", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011188", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011188", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011188", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011188")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbUsername", "setting", "dbUsername", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011189")
    void case_UTAPI_011189() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011189",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011189", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011189", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011189", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011189", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011189", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011189", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011189", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011189", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011189", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011189", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011189")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbUsername", "setting", "dbUsername", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011190")
    void case_UTAPI_011190() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011190",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011190", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011190", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011190", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011190", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011190", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011190", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011190", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011190", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011190", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011190", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011190")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbUsername", "setting", "dbUsername", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011191")
    void case_UTAPI_011191() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011191",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011191", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011191", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011191", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011191", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011191", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011191", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011191", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011191", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011191", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011191", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011191")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011192")
    void case_UTAPI_011192() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011192",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011192", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011192", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011192", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011192", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011192", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011192", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011192", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011192", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011192", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011192", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011192")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011193")
    void case_UTAPI_011193() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011193",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011193", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011193", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011193", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011193", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011193", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011193", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011193", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011193", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011193", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011193", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011193")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011194")
    void case_UTAPI_011194() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011194",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011194", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011194", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011194", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011194", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011194", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011194", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011194", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011194", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011194", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011194", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011194")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011195")
    void case_UTAPI_011195() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011195",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011195", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011195", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011195", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011195", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011195", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011195", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011195", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011195", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011195", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011195", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011195")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011196")
    void case_UTAPI_011196() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011196",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011196", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011196", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011196", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011196", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011196", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011196", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011196", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011196", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011196", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011196", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011196")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011197")
    void case_UTAPI_011197() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011197",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011197", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011197", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011197", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011197", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011197", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011197", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011197", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011197", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011197", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011197", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011197")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011198")
    void case_UTAPI_011198() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011198",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011198", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011198", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011198", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011198", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011198", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011198", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011198", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011198", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011198", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011198", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011198")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011199")
    void case_UTAPI_011199() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011199",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011199", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011199", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011199", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011199", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011199", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011199", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011199", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011199", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011199", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011199", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011199")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011200")
    void case_UTAPI_011200() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011200",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011200", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011200", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011200", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011200", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011200", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011200", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011200", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011200", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011200", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011200", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011200")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011201")
    void case_UTAPI_011201() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011201",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011201", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011201", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011201", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011201", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011201", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011201", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011201", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011201", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011201", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011201", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011201")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011202")
    void case_UTAPI_011202() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011202",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011202", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011202", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011202", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011202", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011202", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011202", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011202", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011202", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011202", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011202", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011202")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on updatedTimestamp", "setting", "updatedTimestamp", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011203")
    void case_UTAPI_011203() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011203",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011203", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011203", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011203", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011203", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011203", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011203", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011203", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011203", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011203", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011203", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011203")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on updatedTimestamp", "setting", "updatedTimestamp", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011204")
    void case_UTAPI_011204() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011204",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011204", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011204", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011204", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011204", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011204", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011204", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011204", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011204", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011204", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011204", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011204")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on updatedTimestamp", "setting", "updatedTimestamp", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011205")
    void case_UTAPI_011205() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011205",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011205", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011205", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011205", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011205", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011205", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011205", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011205", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011205", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011205", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011205", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011205")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on updatedTimestamp", "setting", "updatedTimestamp", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011206")
    void case_UTAPI_011206() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011206",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011206", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011206", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011206", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011206", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011206", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011206", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011206", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011206", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011206", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011206", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011206")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on updatedTimestamp", "setting", "updatedTimestamp", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011207")
    void case_UTAPI_011207() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011207",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011207", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011207", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011207", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011207", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011207", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011207", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011207", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011207", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011207", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011207", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011207")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on updatedTimestamp", "setting", "updatedTimestamp", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011208")
    void case_UTAPI_011208() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011208",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011208", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011208", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011208", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011208", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011208", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011208", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011208", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011208", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011208", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011208", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011208")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on updatedTimestamp", "setting", "updatedTimestamp", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011209")
    void case_UTAPI_011209() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011209",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "buildUrl",
                "String",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011209", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011209", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011209", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011209", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011209", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011209", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011209", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011209", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011209", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011209", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011209")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::buildUrl::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbHost", "data:setting.dbHost")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain dbPort", "data:setting.dbPort")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the JDBC url must contain databaseName", "data:setting.databaseName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed url must be a JDBC url", "text:jdbc:")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on updatedTimestamp", "setting", "updatedTimestamp", "")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

}

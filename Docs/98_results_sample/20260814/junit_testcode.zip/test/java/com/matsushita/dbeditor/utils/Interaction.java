package com.matsushita.dbeditor.utils;

import java.util.Arrays;

/**
 * One recorded interaction between the SUT and a collaborator.
 */
public final class Interaction {

    private final String mockField;
    private final String methodName;
    private final Object[] arguments;

    public Interaction(String mockField, String methodName, Object[] arguments) {
        this.mockField = mockField;
        this.methodName = methodName;
        this.arguments = arguments == null ? new Object[0] : arguments;
    }

    public String mockField() {
        return mockField;
    }

    public String methodName() {
        return methodName;
    }

    public Object[] arguments() {
        return arguments;
    }

    public Object argument(int index) {
        if (index >= 0 && index < arguments.length) {
            return arguments[index];
        } else {
            return null;
        }
    }

    @Override
    public String toString() {
        return mockField + "." + methodName + Arrays.toString(arguments);
    }
}

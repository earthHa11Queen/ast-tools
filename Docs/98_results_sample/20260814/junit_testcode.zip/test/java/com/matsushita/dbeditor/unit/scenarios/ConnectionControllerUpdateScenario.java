package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ConnectionControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ConnectionController#update.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ConnectionControllerUpdateScenario {

    @Test
    @DisplayName("UTAPI-000264")
    void case_UTAPI_000264() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000264",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000264", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000264", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000264", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000264", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000264", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000264", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000264", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000264", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000264")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::ARG::1::-::id")
                    .mirror("-", "1:length_null", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000265")
    void case_UTAPI_000265() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000265",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000265", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000265", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000265", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000265", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000265", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000265", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000265", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000265", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000265")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::ARG::1::-::id")
                    .mirror("-", "2:length_empty", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000266")
    void case_UTAPI_000266() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000266",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000266", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000266", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000266", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000266", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000266", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000266", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000266", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000266", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000266")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::ARG::1::-::id")
                    .mirror("-", "3:length_min", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000267")
    void case_UTAPI_000267() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000267",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000267", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000267", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000267", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000267", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000267", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000267", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000267", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000267", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000267")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::ARG::1::-::id")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000268")
    void case_UTAPI_000268() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000268",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000268", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000268", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000268", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000268", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000268", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000268", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000268", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000268", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000268")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::ARG::1::-::id")
                    .mirror("-", "5:length_max", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000269")
    void case_UTAPI_000269() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000269",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000269", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000269", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000269", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000269", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000269", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000269", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000269", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000269", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000269")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::ARG::1::-::id")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000270")
    void case_UTAPI_000270() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000270",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000270", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000270", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000270", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000270", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000270", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000270", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000270", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000270", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000270")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::ARG::1::-::id")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000271")
    void case_UTAPI_000271() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000271",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000271", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000271", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000271", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000271", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000271", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000271", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000271", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000271", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000271")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::ARG::1::-::id")
                    .mirror("46:hw_integer", "-", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000272")
    void case_UTAPI_000272() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000272",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000272", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000272", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000272", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000272", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000272", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000272", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000272", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000272", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000272")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::ARG::1::-::id")
                    .mirror("-", "-", "12:integer_positive")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000273")
    void case_UTAPI_000273() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000273",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000273", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000273", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000273", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000273", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000273", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000273", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000273", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000273", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000273")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::ARG::1::-::id")
                    .mirror("-", "-", "13:integer_negative")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000274")
    void case_UTAPI_000274() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000274",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000274", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000274", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000274", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000274", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000274", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000274", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000274", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000274", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000274")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::ARG::1::-::id")
                    .mirror("-", "-", "14:integer_zero")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000275")
    void case_UTAPI_000275() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000275",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000275", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000275", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000275", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000275", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000275", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000275", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000275", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000275", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000275")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared NotBlank contract of ConnectionSettingRequest.databaseName classifies this input condition", "ConnectionSettingRequest", "databaseName", "NotBlank", "data:request.databaseName")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000276")
    void case_UTAPI_000276() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000276",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000276", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000276", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000276", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000276", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000276", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000276", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000276", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000276", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000276")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000277")
    void case_UTAPI_000277() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000277",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000277", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000277", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000277", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000277", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000277", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000277", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000277", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000277", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000277")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000278")
    void case_UTAPI_000278() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000278",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000278", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000278", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000278", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000278", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000278", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000278", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000278", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000278", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000278")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000279")
    void case_UTAPI_000279() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000279",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000279", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000279", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000279", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000279", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000279", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000279", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000279", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000279", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000279")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000280")
    void case_UTAPI_000280() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000280",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000280", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000280", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000280", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000280", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000280", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000280", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000280", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000280", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000280")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000281")
    void case_UTAPI_000281() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000281",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000281", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000281", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000281", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000281", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000281", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000281", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000281", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000281", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000281")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000282")
    void case_UTAPI_000282() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000282",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000282", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000282", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000282", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000282", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000282", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000282", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000282", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000282", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000282")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000283")
    void case_UTAPI_000283() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000283",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000283", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000283", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000283", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000283", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000283", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000283", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000283", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000283", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000283")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000284")
    void case_UTAPI_000284() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000284",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000284", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000284", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000284", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000284", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000284", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000284", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000284", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000284", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000284")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000285")
    void case_UTAPI_000285() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000285",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000285", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000285", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000285", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000285", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000285", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000285", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000285", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000285", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000285")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000286")
    void case_UTAPI_000286() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000286",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000286", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000286", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000286", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000286", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000286", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000286", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000286", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000286", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000286")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000287")
    void case_UTAPI_000287() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000287",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000287", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000287", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000287", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000287", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000287", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000287", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000287", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000287", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000287")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000288")
    void case_UTAPI_000288() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000288",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000288", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000288", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000288", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000288", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000288", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000288", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000288", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000288", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000288")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000289")
    void case_UTAPI_000289() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000289",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000289", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000289", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000289", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000289", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000289", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000289", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000289", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000289", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000289")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000290")
    void case_UTAPI_000290() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000290",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000290", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000290", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000290", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000290", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000290", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000290", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000290", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000290", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000290")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000291")
    void case_UTAPI_000291() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000291",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000291", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000291", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000291", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000291", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000291", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000291", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000291", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000291", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000291")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000292")
    void case_UTAPI_000292() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000292",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000292", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000292", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000292", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000292", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000292", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000292", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000292", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000292", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000292")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000293")
    void case_UTAPI_000293() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000293",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000293", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000293", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000293", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000293", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000293", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000293", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000293", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000293", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000293")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000294")
    void case_UTAPI_000294() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000294",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000294", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000294", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000294", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000294", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000294", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000294", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000294", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000294", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000294")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000295")
    void case_UTAPI_000295() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000295",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000295", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000295", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000295", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000295", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000295", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000295", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000295", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000295", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000295")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared NotBlank contract of ConnectionSettingRequest.dbHost classifies this input condition", "ConnectionSettingRequest", "dbHost", "NotBlank", "data:request.dbHost")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000296")
    void case_UTAPI_000296() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000296",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000296", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000296", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000296", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000296", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000296", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000296", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000296", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000296", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000296")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000297")
    void case_UTAPI_000297() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000297",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000297", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000297", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000297", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000297", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000297", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000297", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000297", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000297", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000297")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000298")
    void case_UTAPI_000298() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000298",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000298", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000298", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000298", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000298", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000298", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000298", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000298", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000298", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000298")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000299")
    void case_UTAPI_000299() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000299",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000299", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000299", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000299", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000299", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000299", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000299", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000299", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000299", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000299")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000300")
    void case_UTAPI_000300() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000300",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000300", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000300", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000300", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000300", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000300", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000300", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000300", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000300", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000300")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000301")
    void case_UTAPI_000301() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000301",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000301", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000301", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000301", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000301", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000301", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000301", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000301", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000301", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000301")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000302")
    void case_UTAPI_000302() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000302",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000302", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000302", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000302", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000302", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000302", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000302", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000302", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000302", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000302")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000303")
    void case_UTAPI_000303() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000303",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000303", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000303", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000303", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000303", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000303", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000303", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000303", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000303", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000303")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000304")
    void case_UTAPI_000304() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000304",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000304", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000304", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000304", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000304", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000304", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000304", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000304", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000304", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000304")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000305")
    void case_UTAPI_000305() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000305",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000305", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000305", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000305", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000305", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000305", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000305", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000305", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000305", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000305")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000306")
    void case_UTAPI_000306() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000306",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000306", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000306", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000306", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000306", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000306", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000306", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000306", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000306", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000306")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000307")
    void case_UTAPI_000307() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000307",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000307", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000307", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000307", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000307", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000307", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000307", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000307", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000307", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000307")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000308")
    void case_UTAPI_000308() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000308",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000308", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000308", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000308", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000308", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000308", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000308", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000308", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000308", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000308")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000309")
    void case_UTAPI_000309() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000309",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000309", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000309", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000309", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000309", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000309", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000309", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000309", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000309", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000309")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000310")
    void case_UTAPI_000310() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000310",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000310", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000310", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000310", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000310", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000310", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000310", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000310", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000310", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000310")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000311")
    void case_UTAPI_000311() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000311",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000311", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000311", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000311", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000311", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000311", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000311", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000311", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000311", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000311")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000312")
    void case_UTAPI_000312() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000312",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000312", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000312", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000312", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000312", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000312", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000312", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000312", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000312", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000312")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000313")
    void case_UTAPI_000313() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000313",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000313", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000313", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000313", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000313", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000313", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000313", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000313", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000313", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000313")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000314")
    void case_UTAPI_000314() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000314",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000314", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000314", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000314", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000314", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000314", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000314", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000314", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000314", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000314")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared NotBlank contract of ConnectionSettingRequest.dbName classifies this input condition", "ConnectionSettingRequest", "dbName", "NotBlank", "data:request.dbName")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000315")
    void case_UTAPI_000315() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000315",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000315", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000315", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000315", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000315", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000315", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000315", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000315", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000315", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000315")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000316")
    void case_UTAPI_000316() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000316",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000316", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000316", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000316", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000316", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000316", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000316", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000316", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000316", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000316")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000317")
    void case_UTAPI_000317() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000317",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000317", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000317", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000317", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000317", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000317", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000317", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000317", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000317", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000317")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000318")
    void case_UTAPI_000318() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000318",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000318", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000318", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000318", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000318", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000318", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000318", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000318", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000318", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000318")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000319")
    void case_UTAPI_000319() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000319",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000319", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000319", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000319", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000319", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000319", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000319", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000319", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000319", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000319")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000320")
    void case_UTAPI_000320() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000320",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000320", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000320", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000320", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000320", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000320", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000320", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000320", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000320", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000320")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000321")
    void case_UTAPI_000321() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000321",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000321", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000321", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000321", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000321", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000321", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000321", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000321", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000321", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000321")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000322")
    void case_UTAPI_000322() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000322",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000322", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000322", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000322", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000322", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000322", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000322", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000322", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000322", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000322")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000323")
    void case_UTAPI_000323() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000323",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000323", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000323", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000323", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000323", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000323", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000323", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000323", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000323", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000323")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000324")
    void case_UTAPI_000324() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000324",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000324", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000324", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000324", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000324", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000324", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000324", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000324", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000324", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000324")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000325")
    void case_UTAPI_000325() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000325",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000325", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000325", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000325", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000325", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000325", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000325", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000325", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000325", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000325")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000326")
    void case_UTAPI_000326() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000326",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000326", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000326", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000326", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000326", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000326", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000326", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000326", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000326", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000326")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "56:space")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000327")
    void case_UTAPI_000327() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000327",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000327", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000327", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000327", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000327", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000327", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000327", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000327", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000327", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000327")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000328")
    void case_UTAPI_000328() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000328",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000328", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000328", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000328", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000328", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000328", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000328", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000328", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000328", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000328")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000329")
    void case_UTAPI_000329() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000329",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000329", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000329", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000329", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000329", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000329", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000329", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000329", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000329", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000329")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000330")
    void case_UTAPI_000330() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000330",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000330", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000330", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000330", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000330", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000330", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000330", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000330", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000330", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000330")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000331")
    void case_UTAPI_000331() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000331",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000331", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000331", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000331", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000331", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000331", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000331", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000331", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000331", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000331")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000332")
    void case_UTAPI_000332() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000332",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000332", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000332", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000332", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000332", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000332", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000332", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000332", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000332", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000332")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000333")
    void case_UTAPI_000333() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000333",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000333", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000333", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000333", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000333", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000333", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000333", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000333", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000333", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000333")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000334")
    void case_UTAPI_000334() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000334",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000334", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000334", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000334", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000334", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000334", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000334", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000334", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000334", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000334")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared NotBlank contract of ConnectionSettingRequest.dbPassword classifies this input condition", "ConnectionSettingRequest", "dbPassword", "NotBlank", "data:request.dbPassword")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000335")
    void case_UTAPI_000335() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000335",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000335", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000335", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000335", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000335", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000335", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000335", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000335", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000335", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000335")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000336")
    void case_UTAPI_000336() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000336",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000336", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000336", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000336", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000336", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000336", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000336", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000336", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000336", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000336")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000337")
    void case_UTAPI_000337() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000337",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000337", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000337", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000337", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000337", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000337", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000337", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000337", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000337", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000337")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000338")
    void case_UTAPI_000338() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000338",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000338", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000338", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000338", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000338", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000338", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000338", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000338", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000338", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000338")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000339")
    void case_UTAPI_000339() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000339",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000339", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000339", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000339", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000339", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000339", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000339", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000339", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000339", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000339")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000340")
    void case_UTAPI_000340() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000340",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000340", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000340", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000340", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000340", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000340", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000340", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000340", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000340", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000340")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000341")
    void case_UTAPI_000341() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000341",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000341", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000341", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000341", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000341", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000341", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000341", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000341", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000341", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000341")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000342")
    void case_UTAPI_000342() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000342",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000342", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000342", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000342", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000342", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000342", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000342", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000342", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000342", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000342")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000343")
    void case_UTAPI_000343() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000343",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000343", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000343", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000343", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000343", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000343", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000343", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000343", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000343", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000343")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000344")
    void case_UTAPI_000344() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000344",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000344", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000344", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000344", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000344", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000344", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000344", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000344", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000344", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000344")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000345")
    void case_UTAPI_000345() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000345",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000345", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000345", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000345", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000345", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000345", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000345", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000345", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000345", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000345")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000346")
    void case_UTAPI_000346() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000346",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000346", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000346", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000346", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000346", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000346", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000346", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000346", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000346", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000346")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000347")
    void case_UTAPI_000347() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000347",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000347", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000347", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000347", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000347", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000347", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000347", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000347", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000347", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000347")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000348")
    void case_UTAPI_000348() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000348",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000348", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000348", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000348", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000348", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000348", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000348", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000348", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000348", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000348")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000349")
    void case_UTAPI_000349() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000349",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000349", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000349", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000349", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000349", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000349", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000349", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000349", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000349", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000349")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000350")
    void case_UTAPI_000350() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000350",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000350", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000350", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000350", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000350", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000350", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000350", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000350", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000350", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000350")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000351")
    void case_UTAPI_000351() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000351",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000351", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000351", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000351", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000351", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000351", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000351", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000351", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000351", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000351")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000352")
    void case_UTAPI_000352() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000352",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000352", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000352", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000352", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000352", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000352", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000352", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000352", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000352", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000352")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000353")
    void case_UTAPI_000353() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000353",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000353", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000353", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000353", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000353", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000353", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000353", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000353", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000353", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000353")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "NotNull", "data:request.dbPort")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000354")
    void case_UTAPI_000354() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000354",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000354", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000354", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000354", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000354", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000354", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000354", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000354", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000354", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000354")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "NotNull", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared Min contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Min", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared Max contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Max", "data:request.dbPort")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000355")
    void case_UTAPI_000355() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000355",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000355", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000355", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000355", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000355", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000355", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000355", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000355", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000355", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000355")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "NotNull", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared Min contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Min", "data:request.dbPort")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000356")
    void case_UTAPI_000356() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000356",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000356", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000356", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000356", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000356", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000356", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000356", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000356", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000356", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000356")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "NotNull", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared Min contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Min", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared Max contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Max", "data:request.dbPort")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000357")
    void case_UTAPI_000357() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000357",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000357", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000357", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000357", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000357", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000357", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000357", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000357", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000357", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000357")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "NotNull", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared Max contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Max", "data:request.dbPort")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000358")
    void case_UTAPI_000358() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000358",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000358", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000358", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000358", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000358", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000358", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000358", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000358", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000358", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000358")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "NotNull", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared Min contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Min", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared Max contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Max", "data:request.dbPort")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000359")
    void case_UTAPI_000359() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000359",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000359", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000359", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000359", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000359", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000359", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000359", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000359", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000359", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000359")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000360")
    void case_UTAPI_000360() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000360",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000360", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000360", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000360", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000360", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000360", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000360", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000360", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000360", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000360")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000361")
    void case_UTAPI_000361() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000361",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000361", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000361", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000361", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000361", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000361", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000361", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000361", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000361", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000361")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000362")
    void case_UTAPI_000362() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000362",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000362", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000362", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000362", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000362", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000362", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000362", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000362", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000362", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000362")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000363")
    void case_UTAPI_000363() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000363",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000363", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000363", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000363", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000363", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000363", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000363", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000363", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000363", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000363")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared NotBlank contract of ConnectionSettingRequest.dbUsername classifies this input condition", "ConnectionSettingRequest", "dbUsername", "NotBlank", "data:request.dbUsername")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000364")
    void case_UTAPI_000364() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000364",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000364", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000364", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000364", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000364", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000364", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000364", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000364", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000364", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000364")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000365")
    void case_UTAPI_000365() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000365",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000365", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000365", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000365", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000365", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000365", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000365", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000365", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000365", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000365")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000366")
    void case_UTAPI_000366() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000366",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000366", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000366", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000366", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000366", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000366", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000366", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000366", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000366", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000366")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000367")
    void case_UTAPI_000367() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000367",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000367", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000367", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000367", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000367", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000367", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000367", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000367", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000367", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000367")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000368")
    void case_UTAPI_000368() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000368",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000368", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000368", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000368", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000368", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000368", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000368", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000368", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000368", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000368")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000369")
    void case_UTAPI_000369() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000369",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000369", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000369", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000369", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000369", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000369", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000369", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000369", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000369", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000369")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000370")
    void case_UTAPI_000370() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000370",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000370", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000370", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000370", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000370", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000370", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000370", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000370", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000370", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000370")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000371")
    void case_UTAPI_000371() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000371",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000371", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000371", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000371", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000371", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000371", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000371", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000371", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000371", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000371")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000372")
    void case_UTAPI_000372() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000372",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000372", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000372", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000372", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000372", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000372", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000372", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000372", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000372", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000372")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000373")
    void case_UTAPI_000373() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000373",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000373", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000373", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000373", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000373", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000373", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000373", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000373", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000373", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000373")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000374")
    void case_UTAPI_000374() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000374",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000374", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000374", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000374", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000374", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000374", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000374", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000374", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000374", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000374")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000375")
    void case_UTAPI_000375() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000375",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000375", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000375", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000375", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000375", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000375", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000375", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000375", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000375", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000375")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000376")
    void case_UTAPI_000376() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000376",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000376", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000376", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000376", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000376", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000376", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000376", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000376", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000376", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000376")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000377")
    void case_UTAPI_000377() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000377",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000377", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000377", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000377", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000377", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000377", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000377", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000377", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000377", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000377")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000378")
    void case_UTAPI_000378() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000378",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000378", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000378", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000378", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000378", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000378", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000378", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000378", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000378", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000378")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000379")
    void case_UTAPI_000379() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000379",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000379", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000379", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000379", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000379", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000379", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000379", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000379", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000379", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000379")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000380")
    void case_UTAPI_000380() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000380",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000380", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000380", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000380", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000380", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000380", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000380", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000380", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000380", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000380")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000381")
    void case_UTAPI_000381() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000381",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000381", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000381", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000381", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000381", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000381", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000381", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000381", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000381", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000381")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000382")
    void case_UTAPI_000382() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000382",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "update",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000382", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000382", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000382", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000382", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000382", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000382", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000382", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000382", "id", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000382")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.update", "connectionUseCase", "update")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.update must carry the value generated for id", "connectionUseCase", "update", "0", "data:id")
                    .check(CheckType.ARG_EQUALS, "argument 1 of connectionUseCase.update must carry the value generated for request", "connectionUseCase", "update", "1", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

}

package com.matsushita.dbeditor.utils;

/**
 * Raised when the harness itself cannot run (runtime lookup, reflection, object assembly).
 * A HarnessException is never treated as an observation of the SUT.
 */
public class HarnessException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public HarnessException(String message) {
        super(message);
    }

    public HarnessException(String message, Throwable cause) {
        super(message, cause);
    }
}

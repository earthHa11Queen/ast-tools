package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SqlControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SqlController#getSql.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SqlControllerGetSqlScenario {

    @Test
    @DisplayName("UTAPI-001024")
    void case_UTAPI_001024() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001024",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "getSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001024", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001024")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::getSql::2::ARG::1::-::id")
                    .mirror("-", "1:length_null", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.getSql")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.getSql", "sqlUseCase", "getSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.getSql must carry the value generated for id", "sqlUseCase", "getSql", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001025")
    void case_UTAPI_001025() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001025",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "getSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001025", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001025")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::getSql::2::ARG::1::-::id")
                    .mirror("-", "2:length_empty", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.getSql")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.getSql", "sqlUseCase", "getSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.getSql must carry the value generated for id", "sqlUseCase", "getSql", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001026")
    void case_UTAPI_001026() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001026",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "getSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001026", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001026")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::getSql::2::ARG::1::-::id")
                    .mirror("-", "3:length_min", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.getSql")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.getSql", "sqlUseCase", "getSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.getSql must carry the value generated for id", "sqlUseCase", "getSql", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001027")
    void case_UTAPI_001027() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001027",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "getSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001027", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001027")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::getSql::2::ARG::1::-::id")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.getSql")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.getSql", "sqlUseCase", "getSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.getSql must carry the value generated for id", "sqlUseCase", "getSql", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001028")
    void case_UTAPI_001028() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001028",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "getSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001028", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001028")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::getSql::2::ARG::1::-::id")
                    .mirror("-", "5:length_max", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.getSql")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.getSql", "sqlUseCase", "getSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.getSql must carry the value generated for id", "sqlUseCase", "getSql", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001029")
    void case_UTAPI_001029() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001029",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "getSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001029", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001029")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::getSql::2::ARG::1::-::id")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.getSql")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.getSql", "sqlUseCase", "getSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.getSql must carry the value generated for id", "sqlUseCase", "getSql", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001030")
    void case_UTAPI_001030() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001030",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "getSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001030", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001030")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::getSql::2::ARG::1::-::id")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.getSql")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.getSql", "sqlUseCase", "getSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.getSql must carry the value generated for id", "sqlUseCase", "getSql", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001031")
    void case_UTAPI_001031() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001031",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "getSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001031", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001031")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::getSql::2::ARG::1::-::id")
                    .mirror("46:hw_integer", "-", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.getSql")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.getSql", "sqlUseCase", "getSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.getSql must carry the value generated for id", "sqlUseCase", "getSql", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001032")
    void case_UTAPI_001032() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001032",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "getSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001032", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001032")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::getSql::2::ARG::1::-::id")
                    .mirror("-", "-", "12:integer_positive")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.getSql")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.getSql", "sqlUseCase", "getSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.getSql must carry the value generated for id", "sqlUseCase", "getSql", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001033")
    void case_UTAPI_001033() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001033",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "getSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001033", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001033")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::getSql::2::ARG::1::-::id")
                    .mirror("-", "-", "13:integer_negative")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.getSql")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.getSql", "sqlUseCase", "getSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.getSql must carry the value generated for id", "sqlUseCase", "getSql", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001034")
    void case_UTAPI_001034() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001034",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "getSql",
                "ResponseEntity<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001034", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001034")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::getSql::2::ARG::1::-::id")
                    .mirror("-", "-", "14:integer_zero")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.getSql")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.getSql", "sqlUseCase", "getSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.getSql must carry the value generated for id", "sqlUseCase", "getSql", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

}

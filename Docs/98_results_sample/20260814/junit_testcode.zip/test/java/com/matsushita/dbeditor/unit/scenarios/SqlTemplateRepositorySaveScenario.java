package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SqlTemplateRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SqlTemplateRepository#save.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SqlTemplateRepositorySaveScenario {

    @Test
    @DisplayName("UTAPI-007223")
    void case_UTAPI_007223() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007223",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007223", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007223", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007223", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007223", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007223", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007223")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "1:length_null", "-")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007224")
    void case_UTAPI_007224() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007224",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007224", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007224", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007224", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007224", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007224", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007224")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "2:length_empty", "-")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007225")
    void case_UTAPI_007225() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007225",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007225", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007225", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007225", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007225", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007225", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007225")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "3:length_min", "-")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007226")
    void case_UTAPI_007226() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007226",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007226", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007226", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007226", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007226", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007226", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007226")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007227")
    void case_UTAPI_007227() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007227",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007227", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007227", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007227", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007227", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007227", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007227")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "5:length_max", "-")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007228")
    void case_UTAPI_007228() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007228",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007228", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007228", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007228", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007228", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007228", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007228")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007229")
    void case_UTAPI_007229() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007229",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007229", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007229", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007229", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007229", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007229", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007229")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007230")
    void case_UTAPI_007230() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007230",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007230", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007230", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007230", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007230", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007230", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007230")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007231")
    void case_UTAPI_007231() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007231",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007231", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007231", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007231", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007231", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007231", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007231")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007232")
    void case_UTAPI_007232() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007232",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007232", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007232", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007232", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007232", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007232", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007232")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007233")
    void case_UTAPI_007233() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007233",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007233", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007233", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007233", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007233", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007233", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007233")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007234")
    void case_UTAPI_007234() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007234",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007234", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007234", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007234", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007234", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007234", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007234")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007235")
    void case_UTAPI_007235() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007235",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007235", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007235", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007235", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007235", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007235", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007235")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "56:space")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007236")
    void case_UTAPI_007236() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007236",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007236", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007236", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007236", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007236", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007236", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007236")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007237")
    void case_UTAPI_007237() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007237",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007237", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007237", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007237", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007237", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007237", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007237")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007238")
    void case_UTAPI_007238() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007238",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007238", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007238", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007238", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007238", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007238", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007238")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "59:tab")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007239")
    void case_UTAPI_007239() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007239",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007239", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007239", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007239", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007239", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007239", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007239")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "60:control_character_null")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007240")
    void case_UTAPI_007240() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007240",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007240", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007240", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007240", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007240", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007240", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007240")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007241")
    void case_UTAPI_007241() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007241",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007241", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007241", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007241", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007241", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007241", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007241")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007242")
    void case_UTAPI_007242() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007242",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007242", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007242", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007242", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007242", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007242", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007242")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007243")
    void case_UTAPI_007243() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007243",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007243", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007243", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007243", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007243", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007243", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007243")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("template.createdTimestamp", "SqlTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007244")
    void case_UTAPI_007244() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007244",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007244", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007244", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007244", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007244", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007244", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007244")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("template.createdTimestamp", "SqlTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007245")
    void case_UTAPI_007245() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007245",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007245", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007245", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007245", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007245", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007245", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007245")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("template.createdTimestamp", "SqlTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007246")
    void case_UTAPI_007246() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007246",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007246", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007246", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007246", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007246", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007246", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007246")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("template.createdTimestamp", "SqlTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007247")
    void case_UTAPI_007247() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007247",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007247", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007247", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007247", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007247", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007247", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007247")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("template.createdTimestamp", "SqlTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007248")
    void case_UTAPI_007248() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007248",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007248", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007248", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007248", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007248", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007248", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007248")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("template.createdTimestamp", "SqlTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007249")
    void case_UTAPI_007249() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007249",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007249", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007249", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007249", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007249", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007249", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007249")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("template.createdTimestamp", "SqlTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007250")
    void case_UTAPI_007250() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007250",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007250", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007250", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007250", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007250", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007250", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007250")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("template.createdTimestamp", "SqlTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007251")
    void case_UTAPI_007251() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007251",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007251", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007251", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007251", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007251", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007251", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007251")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::n")
                    .mirror("-", "1:length_null", "-")
                    .target("template.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007252")
    void case_UTAPI_007252() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007252",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007252", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007252", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007252", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007252", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007252", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007252")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("template.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007253")
    void case_UTAPI_007253() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007253",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007253", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007253", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007253", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007253", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007253", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007253")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::n")
                    .mirror("-", "3:length_min", "-")
                    .target("template.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007254")
    void case_UTAPI_007254() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007254",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007254", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007254", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007254", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007254", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007254", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007254")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("template.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007255")
    void case_UTAPI_007255() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007255",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007255", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007255", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007255", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007255", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007255", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007255")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::n")
                    .mirror("-", "5:length_max", "-")
                    .target("template.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007256")
    void case_UTAPI_007256() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007256",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007256", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007256", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007256", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007256", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007256", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007256")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("template.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007257")
    void case_UTAPI_007257() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007257",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007257", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007257", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007257", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007257", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007257", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007257")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("template.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007258")
    void case_UTAPI_007258() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007258",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007258", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007258", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007258", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007258", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007258", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007258")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("template.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007259")
    void case_UTAPI_007259() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007259",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007259", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007259", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007259", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007259", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007259", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007259")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("template.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007260")
    void case_UTAPI_007260() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007260",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007260", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007260", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007260", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007260", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007260", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007260")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("template.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007261")
    void case_UTAPI_007261() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007261",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007261", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007261", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007261", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007261", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007261", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007261")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("template.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007262")
    void case_UTAPI_007262() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007262",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007262", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007262", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007262", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007262", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007262", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007262")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "1:length_null", "-")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007263")
    void case_UTAPI_007263() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007263",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007263", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007263", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007263", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007263", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007263", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007263")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "2:length_empty", "-")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007264")
    void case_UTAPI_007264() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007264",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007264", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007264", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007264", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007264", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007264", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007264")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "3:length_min", "-")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007265")
    void case_UTAPI_007265() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007265",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007265", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007265", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007265", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007265", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007265", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007265")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007266")
    void case_UTAPI_007266() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007266",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007266", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007266", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007266", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007266", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007266", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007266")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "5:length_max", "-")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007267")
    void case_UTAPI_007267() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007267",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007267", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007267", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007267", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007267", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007267", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007267")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007268")
    void case_UTAPI_007268() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007268",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007268", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007268", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007268", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007268", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007268", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007268")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007269")
    void case_UTAPI_007269() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007269",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007269", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007269", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007269", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007269", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007269", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007269")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007270")
    void case_UTAPI_007270() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007270",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007270", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007270", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007270", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007270", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007270", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007270")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007271")
    void case_UTAPI_007271() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007271",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007271", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007271", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007271", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007271", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007271", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007271")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007272")
    void case_UTAPI_007272() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007272",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007272", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007272", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007272", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007272", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007272", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007272")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007273")
    void case_UTAPI_007273() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007273",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007273", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007273", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007273", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007273", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007273", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007273")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007274")
    void case_UTAPI_007274() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007274",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007274", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007274", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007274", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007274", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007274", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007274")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007275")
    void case_UTAPI_007275() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007275",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007275", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007275", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007275", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007275", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007275", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007275")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "56:space")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007276")
    void case_UTAPI_007276() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007276",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007276", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007276", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007276", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007276", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007276", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007276")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007277")
    void case_UTAPI_007277() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007277",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007277", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007277", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007277", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007277", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007277", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007277")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007278")
    void case_UTAPI_007278() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007278",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007278", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007278", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007278", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007278", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007278", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007278")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "59:tab")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007279")
    void case_UTAPI_007279() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007279",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007279", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007279", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007279", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007279", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007279", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007279")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "60:control_character_null")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007280")
    void case_UTAPI_007280() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007280",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007280", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007280", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007280", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007280", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007280", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007280")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007281")
    void case_UTAPI_007281() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007281",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007281", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007281", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007281", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007281", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007281", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007281")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007282")
    void case_UTAPI_007282() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007282",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007282", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-007282", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007282", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007282", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007282", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007282")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

}

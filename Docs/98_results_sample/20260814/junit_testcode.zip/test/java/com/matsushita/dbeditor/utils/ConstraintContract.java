package com.matsushita.dbeditor.utils;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.Collection;
import java.util.Map;

/**
 * Evaluates the validation contract that the target project declares on a DTO field.
 *
 * <p>The declared annotation itself is the specification for the field, so a Case whose
 * Mirror condition violates the declared constraint must be a Case the boundary rejects,
 * and a Case whose Mirror condition satisfies it must be accepted. The evaluation reads the
 * real annotations of the production DTO, therefore removing or weakening a constraint makes
 * the affected Cases fail.</p>
 */
public final class ConstraintContract {

    private ConstraintContract() {
    }

    public static Annotation find(Class<?> dtoType, String fieldName, String constraintSimpleName) {
        Field field = fieldOf(dtoType, fieldName);
        if (field == null) {
            return null;
        }
        Annotation[] annotations = field.getAnnotations();
        for (int i = 0; i < annotations.length; i++) {
            if (annotations[i].annotationType().getSimpleName().equals(constraintSimpleName)) {
                return annotations[i];
            }
        }
        return null;
    }

    public static boolean declares(Class<?> dtoType, String fieldName, String constraintSimpleName) {
        return find(dtoType, fieldName, constraintSimpleName) != null;
    }

    private static Field fieldOf(Class<?> type, String name) {
        Class<?> current = type;
        while (current != null && current != Object.class) {
            try {
                return current.getDeclaredField(name);
            } catch (NoSuchFieldException e) {
                current = current.getSuperclass();
            }
        }
        return null;
    }

    /** True when the value violates the semantics of the declared constraint. */
    public static boolean violates(Object value, String constraintSimpleName, Annotation annotation) {
        if ("NotNull".equals(constraintSimpleName)) {
            return value == null;
        }
        if ("NotBlank".equals(constraintSimpleName)) {
            if (value == null) {
                return true;
            }
            return String.valueOf(value).trim().isEmpty();
        }
        if ("NotEmpty".equals(constraintSimpleName)) {
            if (value == null) {
                return true;
            }
            return sizeOf(value) == 0;
        }
        if ("Min".equals(constraintSimpleName)) {
            if (!(value instanceof Number)) {
                return false;
            }
            return ((Number) value).longValue() < longAttribute(annotation, "value", Long.MIN_VALUE);
        }
        if ("Max".equals(constraintSimpleName)) {
            if (!(value instanceof Number)) {
                return false;
            }
            return ((Number) value).longValue() > longAttribute(annotation, "value", Long.MAX_VALUE);
        }
        if ("Size".equals(constraintSimpleName)) {
            if (value == null) {
                return false;
            }
            int size = sizeOf(value);
            if (size < 0) {
                return false;
            }
            long min = longAttribute(annotation, "min", 0L);
            long max = longAttribute(annotation, "max", Integer.MAX_VALUE);
            return size < min || size > max;
        }
        return false;
    }

    private static int sizeOf(Object value) {
        if (value instanceof CharSequence) {
            return ((CharSequence) value).length();
        }
        if (value instanceof Collection) {
            return ((Collection<?>) value).size();
        }
        if (value instanceof Map) {
            return ((Map<?, ?>) value).size();
        }
        if (value != null && value.getClass().isArray()) {
            return java.lang.reflect.Array.getLength(value);
        }
        return -1;
    }

    private static long longAttribute(Annotation annotation, String name, long fallback) {
        if (annotation == null) {
            return fallback;
        }
        try {
            Object v = annotation.annotationType().getMethod(name).invoke(annotation);
            if (v instanceof Number) {
                return ((Number) v).longValue();
            }
            return fallback;
        } catch (Exception e) {
            return fallback;
        }
    }
}

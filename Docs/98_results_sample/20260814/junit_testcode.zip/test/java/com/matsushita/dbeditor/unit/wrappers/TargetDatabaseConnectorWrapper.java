package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for TargetDatabaseConnector.
 */
public final class TargetDatabaseConnectorWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector";
    private static final String[] DEP_NAMES = new String[] {};
    private static final String[] DEP_TYPES = new String[] {};
    private static final String[] TYPES_buildUrl = new String[] {"ConnectionSetting"};
    private static final String[] TYPES_createDataSource = new String[] {"ConnectionSetting"};
    private static final String[] TYPES_createJdbcTemplate = new String[] {"ConnectionSetting"};

    public TargetDatabaseConnectorWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, false);
    }

    /** String buildUrl(setting) */
    public ExecutionResult buildUrl(Object[] args) {
        return invoke("buildUrl", TYPES_buildUrl, args);
    }

    /** DataSource createDataSource(setting) */
    public ExecutionResult createDataSource(Object[] args) {
        return invoke("createDataSource", TYPES_createDataSource, args);
    }

    /** JdbcTemplate createJdbcTemplate(setting) */
    public ExecutionResult createJdbcTemplate(Object[] args) {
        return invoke("createJdbcTemplate", TYPES_createJdbcTemplate, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("buildUrl".equals(operation)) {
            return buildUrl(args);
        } else if ("createDataSource".equals(operation)) {
            return createDataSource(args);
        } else if ("createJdbcTemplate".equals(operation)) {
            return createJdbcTemplate(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

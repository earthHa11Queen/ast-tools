package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SavedSqlRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SavedSqlRepository#save.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SavedSqlRepositorySaveScenario {

    @Test
    @DisplayName("UTAPI-007121")
    void case_UTAPI_007121() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007121",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007121", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007121", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007121", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007121", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007121", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007121", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007121", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007121")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "1:length_null", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007122")
    void case_UTAPI_007122() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007122",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007122", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007122", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007122", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007122", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007122", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007122", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007122", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007122")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "2:length_empty", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007123")
    void case_UTAPI_007123() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007123",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007123", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007123", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007123", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007123", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007123", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007123", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007123", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007123")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "3:length_min", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007124")
    void case_UTAPI_007124() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007124",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007124", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007124", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007124", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007124", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007124", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007124", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007124", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007124")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007125")
    void case_UTAPI_007125() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007125",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007125", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007125", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007125", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007125", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007125", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007125", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007125", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007125")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "5:length_max", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007126")
    void case_UTAPI_007126() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007126",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007126", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007126", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007126", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007126", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007126", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007126", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007126", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007126")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007127")
    void case_UTAPI_007127() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007127",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007127", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007127", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007127", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007127", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007127", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007127", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007127", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007127")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007128")
    void case_UTAPI_007128() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007128",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007128", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007128", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007128", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007128", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007128", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007128", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007128", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007128")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007129")
    void case_UTAPI_007129() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007129",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007129", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007129", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007129", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007129", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007129", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007129", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007129", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007129")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007130")
    void case_UTAPI_007130() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007130",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007130", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007130", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007130", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007130", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007130", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007130", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007130", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007130")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007131")
    void case_UTAPI_007131() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007131",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007131", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007131", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007131", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007131", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007131", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007131", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007131", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007131")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007132")
    void case_UTAPI_007132() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007132",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007132", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007132", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007132", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007132", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007132", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007132", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007132", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007132")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007133")
    void case_UTAPI_007133() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007133",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007133", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007133", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007133", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007133", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007133", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007133", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007133", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007133")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "56:space")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007134")
    void case_UTAPI_007134() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007134",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007134", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007134", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007134", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007134", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007134", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007134", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007134", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007134")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007135")
    void case_UTAPI_007135() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007135",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007135", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007135", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007135", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007135", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007135", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007135", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007135", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007135")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007136")
    void case_UTAPI_007136() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007136",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007136", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007136", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007136", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007136", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007136", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007136", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007136", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007136")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "59:tab")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007137")
    void case_UTAPI_007137() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007137",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007137", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007137", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007137", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007137", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007137", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007137", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007137", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007137")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "60:control_character_null")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007138")
    void case_UTAPI_007138() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007138",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007138", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007138", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007138", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007138", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007138", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007138", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007138", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007138")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007139")
    void case_UTAPI_007139() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007139",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007139", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007139", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007139", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007139", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007139", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007139", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007139", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007139")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007140")
    void case_UTAPI_007140() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007140",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007140", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007140", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007140", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007140", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007140", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007140", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007140", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007140")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007141")
    void case_UTAPI_007141() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007141",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007141", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007141", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007141", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007141", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007141", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007141", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007141", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007141")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007142")
    void case_UTAPI_007142() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007142",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007142", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007142", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007142", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007142", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007142", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007142", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007142", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007142")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007143")
    void case_UTAPI_007143() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007143",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007143", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007143", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007143", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007143", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007143", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007143", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007143", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007143")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007144")
    void case_UTAPI_007144() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007144",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007144", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007144", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007144", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007144", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007144", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007144", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007144", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007144")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007145")
    void case_UTAPI_007145() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007145",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007145", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007145", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007145", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007145", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007145", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007145", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007145", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007145")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007146")
    void case_UTAPI_007146() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007146",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007146", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007146", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007146", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007146", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007146", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007146", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007146", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007146")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007147")
    void case_UTAPI_007147() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007147",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007147", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007147", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007147", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007147", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007147", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007147", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007147", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007147")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007148")
    void case_UTAPI_007148() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007148",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007148", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007148", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007148", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007148", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007148", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007148", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007148", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007148")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007149")
    void case_UTAPI_007149() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007149",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007149", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007149", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007149", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007149", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007149", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007149", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007149", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007149")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007150")
    void case_UTAPI_007150() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007150",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007150", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007150", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007150", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007150", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007150", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007150", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007150", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007150")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007151")
    void case_UTAPI_007151() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007151",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007151", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007151", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007151", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007151", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007151", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007151", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007151", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007151")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007152")
    void case_UTAPI_007152() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007152",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007152", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007152", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007152", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007152", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007152", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007152", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007152", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007152")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007153")
    void case_UTAPI_007153() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007153",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007153", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007153", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007153", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007153", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007153", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007153", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007153", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007153")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007154")
    void case_UTAPI_007154() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007154",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007154", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007154", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007154", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007154", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007154", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007154", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007154", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007154")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007155")
    void case_UTAPI_007155() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007155",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007155", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007155", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007155", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007155", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007155", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007155", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007155", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007155")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007156")
    void case_UTAPI_007156() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007156",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007156", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007156", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007156", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007156", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007156", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007156", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007156", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007156")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007157")
    void case_UTAPI_007157() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007157",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007157", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007157", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007157", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007157", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007157", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007157", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007157", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007157")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007158")
    void case_UTAPI_007158() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007158",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007158", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007158", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007158", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007158", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007158", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007158", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007158", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007158")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007159")
    void case_UTAPI_007159() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007159",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007159", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007159", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007159", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007159", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007159", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007159", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007159", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007159")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007160")
    void case_UTAPI_007160() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007160",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007160", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007160", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007160", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007160", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007160", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007160", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007160", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007160")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::n")
                    .mirror("-", "1:length_null", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007161")
    void case_UTAPI_007161() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007161",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007161", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007161", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007161", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007161", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007161", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007161", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007161", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007161")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007162")
    void case_UTAPI_007162() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007162",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007162", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007162", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007162", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007162", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007162", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007162", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007162", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007162")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::n")
                    .mirror("-", "3:length_min", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007163")
    void case_UTAPI_007163() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007163",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007163", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007163", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007163", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007163", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007163", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007163", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007163", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007163")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007164")
    void case_UTAPI_007164() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007164",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007164", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007164", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007164", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007164", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007164", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007164", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007164", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007164")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::n")
                    .mirror("-", "5:length_max", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007165")
    void case_UTAPI_007165() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007165",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007165", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007165", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007165", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007165", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007165", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007165", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007165", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007165")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007166")
    void case_UTAPI_007166() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007166",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007166", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007166", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007166", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007166", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007166", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007166", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007166", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007166")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007167")
    void case_UTAPI_007167() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007167",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007167", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007167", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007167", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007167", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007167", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007167", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007167", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007167")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007168")
    void case_UTAPI_007168() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007168",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007168", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007168", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007168", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007168", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007168", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007168", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007168", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007168")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007169")
    void case_UTAPI_007169() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007169",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007169", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007169", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007169", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007169", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007169", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007169", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007169", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007169")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007170")
    void case_UTAPI_007170() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007170",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007170", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007170", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007170", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007170", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007170", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007170", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007170", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007170")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007171")
    void case_UTAPI_007171() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007171",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007171", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007171", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007171", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007171", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007171", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007171", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007171", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007171")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "1:length_null", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007172")
    void case_UTAPI_007172() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007172",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007172", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007172", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007172", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007172", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007172", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007172", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007172", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007172")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "2:length_empty", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007173")
    void case_UTAPI_007173() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007173",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007173", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007173", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007173", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007173", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007173", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007173", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007173", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007173")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "3:length_min", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007174")
    void case_UTAPI_007174() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007174",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007174", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007174", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007174", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007174", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007174", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007174", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007174", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007174")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007175")
    void case_UTAPI_007175() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007175",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007175", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007175", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007175", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007175", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007175", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007175", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007175", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007175")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "5:length_max", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007176")
    void case_UTAPI_007176() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007176",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007176", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007176", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007176", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007176", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007176", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007176", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007176", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007176")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007177")
    void case_UTAPI_007177() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007177",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007177", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007177", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007177", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007177", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007177", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007177", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007177", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007177")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007178")
    void case_UTAPI_007178() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007178",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007178", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007178", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007178", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007178", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007178", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007178", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007178", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007178")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007179")
    void case_UTAPI_007179() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007179",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007179", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007179", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007179", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007179", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007179", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007179", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007179", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007179")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007180")
    void case_UTAPI_007180() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007180",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007180", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007180", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007180", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007180", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007180", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007180", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007180", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007180")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007181")
    void case_UTAPI_007181() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007181",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007181", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007181", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007181", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007181", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007181", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007181", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007181", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007181")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007182")
    void case_UTAPI_007182() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007182",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007182", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007182", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007182", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007182", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007182", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007182", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007182", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007182")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007183")
    void case_UTAPI_007183() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007183",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007183", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007183", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007183", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007183", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007183", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007183", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007183", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007183")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007184")
    void case_UTAPI_007184() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007184",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007184", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007184", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007184", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007184", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007184", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007184", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007184", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007184")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "56:space")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007185")
    void case_UTAPI_007185() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007185",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007185", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007185", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007185", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007185", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007185", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007185", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007185", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007185")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007186")
    void case_UTAPI_007186() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007186",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007186", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007186", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007186", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007186", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007186", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007186", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007186", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007186")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007187")
    void case_UTAPI_007187() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007187",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007187", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007187", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007187", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007187", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007187", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007187", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007187", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007187")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "59:tab")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007188")
    void case_UTAPI_007188() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007188",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007188", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007188", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007188", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007188", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007188", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007188", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007188", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007188")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "60:control_character_null")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007189")
    void case_UTAPI_007189() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007189",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007189", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007189", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007189", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007189", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007189", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007189", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007189", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007189")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007190")
    void case_UTAPI_007190() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007190",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007190", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007190", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007190", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007190", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007190", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007190", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007190", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007190")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007191")
    void case_UTAPI_007191() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007191",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007191", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007191", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007191", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007191", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007191", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007191", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007191", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007191")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007192")
    void case_UTAPI_007192() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007192",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007192", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007192", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007192", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007192", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007192", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007192", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007192", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007192")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007193")
    void case_UTAPI_007193() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007193",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007193", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007193", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007193", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007193", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007193", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007193", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007193", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007193")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007194")
    void case_UTAPI_007194() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007194",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007194", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007194", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007194", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007194", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007194", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007194", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007194", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007194")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007195")
    void case_UTAPI_007195() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007195",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007195", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007195", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007195", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007195", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007195", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007195", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007195", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007195")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007196")
    void case_UTAPI_007196() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007196",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007196", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007196", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007196", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007196", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007196", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007196", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007196", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007196")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007197")
    void case_UTAPI_007197() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007197",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007197", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007197", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007197", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007197", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007197", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007197", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007197", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007197")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007198")
    void case_UTAPI_007198() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007198",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007198", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007198", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007198", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007198", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007198", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007198", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007198", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007198")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007199")
    void case_UTAPI_007199() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007199",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007199", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-007199", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007199", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007199", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007199", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007199", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007199", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-007199")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::save::3::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

}

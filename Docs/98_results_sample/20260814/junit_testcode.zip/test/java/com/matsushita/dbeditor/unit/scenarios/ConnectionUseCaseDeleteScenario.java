package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ConnectionUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ConnectionUseCase#delete.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ConnectionUseCaseDeleteScenario {

    @Test
    @DisplayName("UTAPI-011827")
    void case_UTAPI_011827() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011827",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "delete",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011827", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011827")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::delete::5::ARG::1::-::n")
                    .mirror("-", "1:length_null", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.deleteById", "connectionSettingRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.deleteById must carry the value generated for n", "connectionSettingRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011828")
    void case_UTAPI_011828() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011828",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "delete",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011828", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011828")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::delete::5::ARG::1::-::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.deleteById", "connectionSettingRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.deleteById must carry the value generated for n", "connectionSettingRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011829")
    void case_UTAPI_011829() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011829",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "delete",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011829", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011829")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::delete::5::ARG::1::-::n")
                    .mirror("-", "3:length_min", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.deleteById", "connectionSettingRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.deleteById must carry the value generated for n", "connectionSettingRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011830")
    void case_UTAPI_011830() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011830",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "delete",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011830", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011830")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::delete::5::ARG::1::-::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.deleteById", "connectionSettingRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.deleteById must carry the value generated for n", "connectionSettingRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011831")
    void case_UTAPI_011831() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011831",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "delete",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011831", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011831")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::delete::5::ARG::1::-::n")
                    .mirror("-", "5:length_max", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.deleteById", "connectionSettingRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.deleteById must carry the value generated for n", "connectionSettingRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011832")
    void case_UTAPI_011832() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011832",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "delete",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011832", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011832")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::delete::5::ARG::1::-::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.deleteById", "connectionSettingRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.deleteById must carry the value generated for n", "connectionSettingRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011833")
    void case_UTAPI_011833() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011833",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "delete",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011833", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011833")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::delete::5::ARG::1::-::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.deleteById", "connectionSettingRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.deleteById must carry the value generated for n", "connectionSettingRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011834")
    void case_UTAPI_011834() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011834",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "delete",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011834", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011834")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::delete::5::ARG::1::-::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.deleteById", "connectionSettingRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.deleteById must carry the value generated for n", "connectionSettingRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011835")
    void case_UTAPI_011835() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011835",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "delete",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011835", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011835")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::delete::5::ARG::1::-::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.deleteById", "connectionSettingRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.deleteById must carry the value generated for n", "connectionSettingRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011836")
    void case_UTAPI_011836() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011836",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "delete",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011836", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011836")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::delete::5::ARG::1::-::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.deleteById", "connectionSettingRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.deleteById must carry the value generated for n", "connectionSettingRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011837")
    void case_UTAPI_011837() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011837",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "delete",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011837", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011837")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::delete::5::ARG::1::-::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.deleteById", "connectionSettingRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.deleteById must carry the value generated for n", "connectionSettingRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

}

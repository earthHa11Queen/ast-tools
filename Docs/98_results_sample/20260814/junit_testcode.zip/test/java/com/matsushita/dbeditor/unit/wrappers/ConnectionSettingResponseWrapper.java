package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for ConnectionSettingResponse.
 */
public final class ConnectionSettingResponseWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse";
    private static final String[] DEP_NAMES = new String[] {"n", "dbName", "dbHost", "dbPort", "databaseName", "dbUsername", "createdTimestamp", "updatedTimestamp"};
    private static final String[] DEP_TYPES = new String[] {"Integer", "String", "String", "Integer", "String", "String", "LocalDateTime", "LocalDateTime"};
    private static final String[] TYPES_fromEntity = new String[] {"ConnectionSetting"};

    public ConnectionSettingResponseWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, true);
    }

    /** ConnectionSettingResponse fromEntity(entity) */
    public ExecutionResult fromEntity(Object[] args) {
        return invoke("fromEntity", TYPES_fromEntity, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("fromEntity".equals(operation)) {
            return fromEntity(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ImportGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ImportGateway#sanitizeType.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ImportGatewaySanitizeTypeScenario {

    @Test
    @DisplayName("UTAPI-002829")
    void case_UTAPI_002829() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002829",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "sanitizeType",
                "String",
                new ParamSpec[] {
                    new ParamSpec("type", "String", "type")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002829", "type", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002829")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::sanitizeType::4::ARG::1::-::type")
                    .mirror("-", "1:length_null", "-")
                    .target("type", "type")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the sanitised column type and the result of sanitising it once more")
                    .expected("the sanitisation is total and stable for this input condition")
                    .failure("the type text is rejected, lost, or keeps changing on repeated sanitisation")
                    .assertion("assertNotNull and assertEquals(result, sanitizeType(result))")
                    .check(CheckType.NO_EXCEPTION, "the type text must be accepted for this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "a column type must be produced")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "sanitising an already sanitised type must not change it again", "0", "data:type")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002830")
    void case_UTAPI_002830() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002830",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "sanitizeType",
                "String",
                new ParamSpec[] {
                    new ParamSpec("type", "String", "type")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002830", "type", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002830")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::sanitizeType::4::ARG::1::-::type")
                    .mirror("-", "2:length_empty", "-")
                    .target("type", "type")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the sanitised column type and the result of sanitising it once more")
                    .expected("the sanitisation is total and stable for this input condition")
                    .failure("the type text is rejected, lost, or keeps changing on repeated sanitisation")
                    .assertion("assertNotNull and assertEquals(result, sanitizeType(result))")
                    .check(CheckType.NO_EXCEPTION, "the type text must be accepted for this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "a column type must be produced")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "sanitising an already sanitised type must not change it again", "0", "data:type")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002831")
    void case_UTAPI_002831() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002831",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "sanitizeType",
                "String",
                new ParamSpec[] {
                    new ParamSpec("type", "String", "type")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002831", "type", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002831")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::sanitizeType::4::ARG::1::-::type")
                    .mirror("-", "3:length_min", "-")
                    .target("type", "type")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the sanitised column type and the result of sanitising it once more")
                    .expected("the sanitisation is total and stable for this input condition")
                    .failure("the type text is rejected, lost, or keeps changing on repeated sanitisation")
                    .assertion("assertNotNull and assertEquals(result, sanitizeType(result))")
                    .check(CheckType.NO_EXCEPTION, "the type text must be accepted for this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "a column type must be produced")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "sanitising an already sanitised type must not change it again", "0", "data:type")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002832")
    void case_UTAPI_002832() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002832",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "sanitizeType",
                "String",
                new ParamSpec[] {
                    new ParamSpec("type", "String", "type")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002832", "type", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002832")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::sanitizeType::4::ARG::1::-::type")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("type", "type")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the sanitised column type and the result of sanitising it once more")
                    .expected("the sanitisation is total and stable for this input condition")
                    .failure("the type text is rejected, lost, or keeps changing on repeated sanitisation")
                    .assertion("assertNotNull and assertEquals(result, sanitizeType(result))")
                    .check(CheckType.NO_EXCEPTION, "the type text must be accepted for this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "a column type must be produced")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "sanitising an already sanitised type must not change it again", "0", "data:type")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002833")
    void case_UTAPI_002833() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002833",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "sanitizeType",
                "String",
                new ParamSpec[] {
                    new ParamSpec("type", "String", "type")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002833", "type", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002833")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::sanitizeType::4::ARG::1::-::type")
                    .mirror("-", "5:length_max", "-")
                    .target("type", "type")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the sanitised column type and the result of sanitising it once more")
                    .expected("the sanitisation is total and stable for this input condition")
                    .failure("the type text is rejected, lost, or keeps changing on repeated sanitisation")
                    .assertion("assertNotNull and assertEquals(result, sanitizeType(result))")
                    .check(CheckType.NO_EXCEPTION, "the type text must be accepted for this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "a column type must be produced")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "sanitising an already sanitised type must not change it again", "0", "data:type")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002834")
    void case_UTAPI_002834() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002834",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "sanitizeType",
                "String",
                new ParamSpec[] {
                    new ParamSpec("type", "String", "type")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002834", "type", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002834")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::sanitizeType::4::ARG::1::-::type")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("type", "type")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the sanitised column type and the result of sanitising it once more")
                    .expected("the sanitisation is total and stable for this input condition")
                    .failure("the type text is rejected, lost, or keeps changing on repeated sanitisation")
                    .assertion("assertNotNull and assertEquals(result, sanitizeType(result))")
                    .check(CheckType.NO_EXCEPTION, "the type text must be accepted for this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "a column type must be produced")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "sanitising an already sanitised type must not change it again", "0", "data:type")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002835")
    void case_UTAPI_002835() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002835",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "sanitizeType",
                "String",
                new ParamSpec[] {
                    new ParamSpec("type", "String", "type")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002835", "type", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002835")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::sanitizeType::4::ARG::1::-::type")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("type", "type")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the sanitised column type and the result of sanitising it once more")
                    .expected("the sanitisation is total and stable for this input condition")
                    .failure("the type text is rejected, lost, or keeps changing on repeated sanitisation")
                    .assertion("assertNotNull and assertEquals(result, sanitizeType(result))")
                    .check(CheckType.NO_EXCEPTION, "the type text must be accepted for this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "a column type must be produced")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "sanitising an already sanitised type must not change it again", "0", "data:type")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002836")
    void case_UTAPI_002836() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002836",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "sanitizeType",
                "String",
                new ParamSpec[] {
                    new ParamSpec("type", "String", "type")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002836", "type", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002836")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::sanitizeType::4::ARG::1::-::type")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("type", "type")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the sanitised column type and the result of sanitising it once more")
                    .expected("the sanitisation is total and stable for this input condition")
                    .failure("the type text is rejected, lost, or keeps changing on repeated sanitisation")
                    .assertion("assertNotNull and assertEquals(result, sanitizeType(result))")
                    .check(CheckType.NO_EXCEPTION, "the type text must be accepted for this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "a column type must be produced")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "sanitising an already sanitised type must not change it again", "0", "data:type")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002837")
    void case_UTAPI_002837() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002837",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "sanitizeType",
                "String",
                new ParamSpec[] {
                    new ParamSpec("type", "String", "type")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002837", "type", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002837")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::sanitizeType::4::ARG::1::-::type")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("type", "type")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the sanitised column type and the result of sanitising it once more")
                    .expected("the sanitisation is total and stable for this input condition")
                    .failure("the type text is rejected, lost, or keeps changing on repeated sanitisation")
                    .assertion("assertNotNull and assertEquals(result, sanitizeType(result))")
                    .check(CheckType.NO_EXCEPTION, "the type text must be accepted for this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "a column type must be produced")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "sanitising an already sanitised type must not change it again", "0", "data:type")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002838")
    void case_UTAPI_002838() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002838",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "sanitizeType",
                "String",
                new ParamSpec[] {
                    new ParamSpec("type", "String", "type")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002838", "type", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002838")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::sanitizeType::4::ARG::1::-::type")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("type", "type")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the sanitised column type and the result of sanitising it once more")
                    .expected("the sanitisation is total and stable for this input condition")
                    .failure("the type text is rejected, lost, or keeps changing on repeated sanitisation")
                    .assertion("assertNotNull and assertEquals(result, sanitizeType(result))")
                    .check(CheckType.NO_EXCEPTION, "the type text must be accepted for this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "a column type must be produced")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "sanitising an already sanitised type must not change it again", "0", "data:type")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002839")
    void case_UTAPI_002839() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002839",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "sanitizeType",
                "String",
                new ParamSpec[] {
                    new ParamSpec("type", "String", "type")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002839", "type", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002839")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::sanitizeType::4::ARG::1::-::type")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("type", "type")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the sanitised column type and the result of sanitising it once more")
                    .expected("the sanitisation is total and stable for this input condition")
                    .failure("the type text is rejected, lost, or keeps changing on repeated sanitisation")
                    .assertion("assertNotNull and assertEquals(result, sanitizeType(result))")
                    .check(CheckType.NO_EXCEPTION, "the type text must be accepted for this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "a column type must be produced")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "sanitising an already sanitised type must not change it again", "0", "data:type")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002840")
    void case_UTAPI_002840() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002840",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "sanitizeType",
                "String",
                new ParamSpec[] {
                    new ParamSpec("type", "String", "type")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002840", "type", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002840")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::sanitizeType::4::ARG::1::-::type")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("type", "type")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the sanitised column type and the result of sanitising it once more")
                    .expected("the sanitisation is total and stable for this input condition")
                    .failure("the type text is rejected, lost, or keeps changing on repeated sanitisation")
                    .assertion("assertNotNull and assertEquals(result, sanitizeType(result))")
                    .check(CheckType.NO_EXCEPTION, "the type text must be accepted for this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "a column type must be produced")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "sanitising an already sanitised type must not change it again", "0", "data:type")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002841")
    void case_UTAPI_002841() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002841",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "sanitizeType",
                "String",
                new ParamSpec[] {
                    new ParamSpec("type", "String", "type")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002841", "type", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002841")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::sanitizeType::4::ARG::1::-::type")
                    .mirror("-", "-", "56:space")
                    .target("type", "type")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the sanitised column type and the result of sanitising it once more")
                    .expected("the sanitisation is total and stable for this input condition")
                    .failure("the type text is rejected, lost, or keeps changing on repeated sanitisation")
                    .assertion("assertNotNull and assertEquals(result, sanitizeType(result))")
                    .check(CheckType.NO_EXCEPTION, "the type text must be accepted for this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "a column type must be produced")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "sanitising an already sanitised type must not change it again", "0", "data:type")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002842")
    void case_UTAPI_002842() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002842",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "sanitizeType",
                "String",
                new ParamSpec[] {
                    new ParamSpec("type", "String", "type")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002842", "type", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002842")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::sanitizeType::4::ARG::1::-::type")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("type", "type")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the sanitised column type and the result of sanitising it once more")
                    .expected("the sanitisation is total and stable for this input condition")
                    .failure("the type text is rejected, lost, or keeps changing on repeated sanitisation")
                    .assertion("assertNotNull and assertEquals(result, sanitizeType(result))")
                    .check(CheckType.NO_EXCEPTION, "the type text must be accepted for this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "a column type must be produced")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "sanitising an already sanitised type must not change it again", "0", "data:type")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002843")
    void case_UTAPI_002843() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002843",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "sanitizeType",
                "String",
                new ParamSpec[] {
                    new ParamSpec("type", "String", "type")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002843", "type", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002843")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::sanitizeType::4::ARG::1::-::type")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("type", "type")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the sanitised column type and the result of sanitising it once more")
                    .expected("the sanitisation is total and stable for this input condition")
                    .failure("the type text is rejected, lost, or keeps changing on repeated sanitisation")
                    .assertion("assertNotNull and assertEquals(result, sanitizeType(result))")
                    .check(CheckType.NO_EXCEPTION, "the type text must be accepted for this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "a column type must be produced")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "sanitising an already sanitised type must not change it again", "0", "data:type")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002844")
    void case_UTAPI_002844() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002844",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "sanitizeType",
                "String",
                new ParamSpec[] {
                    new ParamSpec("type", "String", "type")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002844", "type", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002844")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::sanitizeType::4::ARG::1::-::type")
                    .mirror("-", "-", "59:tab")
                    .target("type", "type")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the sanitised column type and the result of sanitising it once more")
                    .expected("the sanitisation is total and stable for this input condition")
                    .failure("the type text is rejected, lost, or keeps changing on repeated sanitisation")
                    .assertion("assertNotNull and assertEquals(result, sanitizeType(result))")
                    .check(CheckType.NO_EXCEPTION, "the type text must be accepted for this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "a column type must be produced")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "sanitising an already sanitised type must not change it again", "0", "data:type")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002845")
    void case_UTAPI_002845() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002845",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "sanitizeType",
                "String",
                new ParamSpec[] {
                    new ParamSpec("type", "String", "type")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002845", "type", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002845")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::sanitizeType::4::ARG::1::-::type")
                    .mirror("-", "-", "60:control_character_null")
                    .target("type", "type")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the sanitised column type and the result of sanitising it once more")
                    .expected("the sanitisation is total and stable for this input condition")
                    .failure("the type text is rejected, lost, or keeps changing on repeated sanitisation")
                    .assertion("assertNotNull and assertEquals(result, sanitizeType(result))")
                    .check(CheckType.NO_EXCEPTION, "the type text must be accepted for this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "a column type must be produced")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "sanitising an already sanitised type must not change it again", "0", "data:type")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002846")
    void case_UTAPI_002846() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002846",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "sanitizeType",
                "String",
                new ParamSpec[] {
                    new ParamSpec("type", "String", "type")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002846", "type", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002846")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::sanitizeType::4::ARG::1::-::type")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("type", "type")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the sanitised column type and the result of sanitising it once more")
                    .expected("the sanitisation is total and stable for this input condition")
                    .failure("the type text is rejected, lost, or keeps changing on repeated sanitisation")
                    .assertion("assertNotNull and assertEquals(result, sanitizeType(result))")
                    .check(CheckType.NO_EXCEPTION, "the type text must be accepted for this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "a column type must be produced")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "sanitising an already sanitised type must not change it again", "0", "data:type")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002847")
    void case_UTAPI_002847() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002847",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "sanitizeType",
                "String",
                new ParamSpec[] {
                    new ParamSpec("type", "String", "type")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002847", "type", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002847")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::sanitizeType::4::ARG::1::-::type")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("type", "type")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the sanitised column type and the result of sanitising it once more")
                    .expected("the sanitisation is total and stable for this input condition")
                    .failure("the type text is rejected, lost, or keeps changing on repeated sanitisation")
                    .assertion("assertNotNull and assertEquals(result, sanitizeType(result))")
                    .check(CheckType.NO_EXCEPTION, "the type text must be accepted for this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "a column type must be produced")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "sanitising an already sanitised type must not change it again", "0", "data:type")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002848")
    void case_UTAPI_002848() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002848",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "sanitizeType",
                "String",
                new ParamSpec[] {
                    new ParamSpec("type", "String", "type")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002848", "type", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002848")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::sanitizeType::4::ARG::1::-::type")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("type", "type")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the sanitised column type and the result of sanitising it once more")
                    .expected("the sanitisation is total and stable for this input condition")
                    .failure("the type text is rejected, lost, or keeps changing on repeated sanitisation")
                    .assertion("assertNotNull and assertEquals(result, sanitizeType(result))")
                    .check(CheckType.NO_EXCEPTION, "the type text must be accepted for this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "a column type must be produced")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "sanitising an already sanitised type must not change it again", "0", "data:type")
                    .build()),
            new ImportGatewayWrapper());
    }

}

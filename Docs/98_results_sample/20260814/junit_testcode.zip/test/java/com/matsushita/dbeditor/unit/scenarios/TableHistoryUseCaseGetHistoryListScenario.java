package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableHistoryUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableHistoryUseCase#getHistoryList.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableHistoryUseCaseGetHistoryListScenario {

    @Test
    @DisplayName("UTAPI-013028")
    void case_UTAPI_013028() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013028",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013028", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013028", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013028", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013028")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013029")
    void case_UTAPI_013029() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013029",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013029", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013029", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013029", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013029")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013030")
    void case_UTAPI_013030() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013030",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013030", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013030", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013030", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013030")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013031")
    void case_UTAPI_013031() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013031",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013031", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013031", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013031", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013031")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013032")
    void case_UTAPI_013032() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013032",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013032", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013032", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013032", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013032")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013033")
    void case_UTAPI_013033() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013033",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013033", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013033", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013033", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013033")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013034")
    void case_UTAPI_013034() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013034",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013034", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013034", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013034", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013034")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013035")
    void case_UTAPI_013035() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013035",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013035", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013035", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013035", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013035")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013036")
    void case_UTAPI_013036() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013036",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013036", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013036", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013036", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013036")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013037")
    void case_UTAPI_013037() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013037",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013037", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013037", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013037", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013037")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013038")
    void case_UTAPI_013038() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013038",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013038", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013038", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013038", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013038")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013039")
    void case_UTAPI_013039() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013039",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013039", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013039", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013039", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013039")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013040")
    void case_UTAPI_013040() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013040",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013040", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013040", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013040", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013040")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013041")
    void case_UTAPI_013041() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013041",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013041", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013041", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013041", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013041")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013042")
    void case_UTAPI_013042() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013042",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013042", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013042", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013042", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013042")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013043")
    void case_UTAPI_013043() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013043",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013043", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013043", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013043", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013043")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013044")
    void case_UTAPI_013044() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013044",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013044", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013044", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013044", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013044")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013045")
    void case_UTAPI_013045() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013045",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013045", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013045", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013045", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013045")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013046")
    void case_UTAPI_013046() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013046",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013046", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013046", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013046", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013046")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013047")
    void case_UTAPI_013047() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013047",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013047", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013047", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013047", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013047")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013048")
    void case_UTAPI_013048() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013048",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013048", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013048", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013048", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013048")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013049")
    void case_UTAPI_013049() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013049",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013049", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013049", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013049", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013049")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013050")
    void case_UTAPI_013050() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013050",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013050", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013050", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013050", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013050")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013051")
    void case_UTAPI_013051() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013051",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013051", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013051", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013051", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013051")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013052")
    void case_UTAPI_013052() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013052",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013052", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013052", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013052", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013052")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013053")
    void case_UTAPI_013053() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013053",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013053", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013053", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013053", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013053")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013054")
    void case_UTAPI_013054() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013054",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013054", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013054", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013054", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013054")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013055")
    void case_UTAPI_013055() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013055",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013055", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013055", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013055", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013055")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013056")
    void case_UTAPI_013056() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013056",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013056", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013056", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013056", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013056")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013057")
    void case_UTAPI_013057() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013057",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013057", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013057", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013057", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013057")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013058")
    void case_UTAPI_013058() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013058",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013058", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013058", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013058", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013058")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013059")
    void case_UTAPI_013059() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013059",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013059", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013059", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013059", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013059")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013060")
    void case_UTAPI_013060() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013060",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013060", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013060", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013060", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013060")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013061")
    void case_UTAPI_013061() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013061",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013061", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013061", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013061", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013061")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013062")
    void case_UTAPI_013062() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013062",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013062", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013062", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013062", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013062")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013063")
    void case_UTAPI_013063() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013063",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013063", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013063", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013063", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013063")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013064")
    void case_UTAPI_013064() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013064",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013064", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013064", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013064", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013064")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013065")
    void case_UTAPI_013065() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013065",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013065", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013065", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013065", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013065")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013066")
    void case_UTAPI_013066() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013066",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013066", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013066", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013066", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013066")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013067")
    void case_UTAPI_013067() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013067",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013067", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013067", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013067", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013067")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013068")
    void case_UTAPI_013068() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013068",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013068", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013068", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013068", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013068")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013069")
    void case_UTAPI_013069() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013069",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013069", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013069", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013069", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013069")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013070")
    void case_UTAPI_013070() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013070",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013070", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013070", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013070", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013070")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013071")
    void case_UTAPI_013071() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013071",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013071", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013071", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013071", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013071")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013072")
    void case_UTAPI_013072() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013072",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013072", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013072", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013072", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013072")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013073")
    void case_UTAPI_013073() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013073",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013073", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013073", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013073", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013073")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013074")
    void case_UTAPI_013074() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013074",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013074", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013074", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013074", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013074")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013075")
    void case_UTAPI_013075() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013075",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013075", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013075", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013075", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013075")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013076")
    void case_UTAPI_013076() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013076",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013076", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013076", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013076", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013076")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013077")
    void case_UTAPI_013077() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013077",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013077", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013077", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013077", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013077")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013078")
    void case_UTAPI_013078() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013078",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013078", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013078", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013078", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013078")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013079")
    void case_UTAPI_013079() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013079",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013079", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013079", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013079", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013079")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013080")
    void case_UTAPI_013080() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013080",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013080", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013080", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013080", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013080")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryList")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryList must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryList", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryList must carry the value generated for tableName", "tableHistoryRepository", "findHistoryList", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryList", "tableHistoryRepository", "findHistoryList")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.DbEditorApplicationWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for DbEditorApplication#main.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class DbEditorApplicationMainScenario {

    @Test
    @DisplayName("UTAPI-000001")
    void case_UTAPI_000001() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000001",
                "com.matsushita.dbeditor.DbEditorApplication",
                "main",
                "void",
                new ParamSpec[] {
                    new ParamSpec("args", "String[]", "args")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000001", "args", "TARGET", "COLLECTION", "String[]"),
                    new DataRef("UTAPI-000001", "args[]", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000001")
                    .targetId("./java/com/matsushita/dbeditor/DbEditorApplication.java::DbEditorApplication::main::1::ARG::1::-::args")
                    .mirror("-", "1:length_null", "-")
                    .target("args", "args")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.APPLICATION_BOOTSTRAP)
                    .observation("the bootstrap call performed by main")
                    .expected("SpringApplication.run receives the application class and exactly the supplied argument array")
                    .failure("the arguments are dropped, replaced or rewritten before the application is started")
                    .assertion("verify the recorded static invocation and assertArrayEquals on the forwarded arguments")
                    .check(CheckType.INVOKED_ONCE, "the entry point must start the application exactly once", "SpringApplication", "run")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the application class must be handed to the bootstrap", "SpringApplication", "run", "0", "text:DbEditorApplication")
                    .check(CheckType.ARG_EQUALS, "the command line arguments must be forwarded unchanged", "SpringApplication", "run", "1", "data:args")
                    .check(CheckType.NO_EXCEPTION, "the entry point must not abort for this argument condition")
                    .build()),
            new DbEditorApplicationWrapper());
    }

    @Test
    @DisplayName("UTAPI-000002")
    void case_UTAPI_000002() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000002",
                "com.matsushita.dbeditor.DbEditorApplication",
                "main",
                "void",
                new ParamSpec[] {
                    new ParamSpec("args", "String[]", "args")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000002", "args", "TARGET", "COLLECTION", "String[]"),
                    new DataRef("UTAPI-000002", "args[]", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000002")
                    .targetId("./java/com/matsushita/dbeditor/DbEditorApplication.java::DbEditorApplication::main::1::ARG::1::-::args")
                    .mirror("-", "2:length_empty", "-")
                    .target("args", "args")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.APPLICATION_BOOTSTRAP)
                    .observation("the bootstrap call performed by main")
                    .expected("SpringApplication.run receives the application class and exactly the supplied argument array")
                    .failure("the arguments are dropped, replaced or rewritten before the application is started")
                    .assertion("verify the recorded static invocation and assertArrayEquals on the forwarded arguments")
                    .check(CheckType.INVOKED_ONCE, "the entry point must start the application exactly once", "SpringApplication", "run")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the application class must be handed to the bootstrap", "SpringApplication", "run", "0", "text:DbEditorApplication")
                    .check(CheckType.ARG_EQUALS, "the command line arguments must be forwarded unchanged", "SpringApplication", "run", "1", "data:args")
                    .check(CheckType.NO_EXCEPTION, "the entry point must not abort for this argument condition")
                    .build()),
            new DbEditorApplicationWrapper());
    }

    @Test
    @DisplayName("UTAPI-000003")
    void case_UTAPI_000003() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000003",
                "com.matsushita.dbeditor.DbEditorApplication",
                "main",
                "void",
                new ParamSpec[] {
                    new ParamSpec("args", "String[]", "args")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000003", "args", "TARGET", "COLLECTION", "String[]"),
                    new DataRef("UTAPI-000003", "args[]", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000003")
                    .targetId("./java/com/matsushita/dbeditor/DbEditorApplication.java::DbEditorApplication::main::1::ARG::1::-::args")
                    .mirror("-", "3:length_min", "-")
                    .target("args", "args")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.APPLICATION_BOOTSTRAP)
                    .observation("the bootstrap call performed by main")
                    .expected("SpringApplication.run receives the application class and exactly the supplied argument array")
                    .failure("the arguments are dropped, replaced or rewritten before the application is started")
                    .assertion("verify the recorded static invocation and assertArrayEquals on the forwarded arguments")
                    .check(CheckType.INVOKED_ONCE, "the entry point must start the application exactly once", "SpringApplication", "run")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the application class must be handed to the bootstrap", "SpringApplication", "run", "0", "text:DbEditorApplication")
                    .check(CheckType.ARG_EQUALS, "the command line arguments must be forwarded unchanged", "SpringApplication", "run", "1", "data:args")
                    .check(CheckType.NO_EXCEPTION, "the entry point must not abort for this argument condition")
                    .build()),
            new DbEditorApplicationWrapper());
    }

    @Test
    @DisplayName("UTAPI-000004")
    void case_UTAPI_000004() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000004",
                "com.matsushita.dbeditor.DbEditorApplication",
                "main",
                "void",
                new ParamSpec[] {
                    new ParamSpec("args", "String[]", "args")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000004", "args", "TARGET", "COLLECTION", "String[]"),
                    new DataRef("UTAPI-000004", "args[]", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000004")
                    .targetId("./java/com/matsushita/dbeditor/DbEditorApplication.java::DbEditorApplication::main::1::ARG::1::-::args")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("args", "args")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.APPLICATION_BOOTSTRAP)
                    .observation("the bootstrap call performed by main")
                    .expected("SpringApplication.run receives the application class and exactly the supplied argument array")
                    .failure("the arguments are dropped, replaced or rewritten before the application is started")
                    .assertion("verify the recorded static invocation and assertArrayEquals on the forwarded arguments")
                    .check(CheckType.INVOKED_ONCE, "the entry point must start the application exactly once", "SpringApplication", "run")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the application class must be handed to the bootstrap", "SpringApplication", "run", "0", "text:DbEditorApplication")
                    .check(CheckType.ARG_EQUALS, "the command line arguments must be forwarded unchanged", "SpringApplication", "run", "1", "data:args")
                    .check(CheckType.NO_EXCEPTION, "the entry point must not abort for this argument condition")
                    .build()),
            new DbEditorApplicationWrapper());
    }

    @Test
    @DisplayName("UTAPI-000005")
    void case_UTAPI_000005() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000005",
                "com.matsushita.dbeditor.DbEditorApplication",
                "main",
                "void",
                new ParamSpec[] {
                    new ParamSpec("args", "String[]", "args")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000005", "args", "TARGET", "COLLECTION", "String[]"),
                    new DataRef("UTAPI-000005", "args[]", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000005")
                    .targetId("./java/com/matsushita/dbeditor/DbEditorApplication.java::DbEditorApplication::main::1::ARG::1::-::args")
                    .mirror("-", "5:length_max", "-")
                    .target("args", "args")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.APPLICATION_BOOTSTRAP)
                    .observation("the bootstrap call performed by main")
                    .expected("SpringApplication.run receives the application class and exactly the supplied argument array")
                    .failure("the arguments are dropped, replaced or rewritten before the application is started")
                    .assertion("verify the recorded static invocation and assertArrayEquals on the forwarded arguments")
                    .check(CheckType.INVOKED_ONCE, "the entry point must start the application exactly once", "SpringApplication", "run")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the application class must be handed to the bootstrap", "SpringApplication", "run", "0", "text:DbEditorApplication")
                    .check(CheckType.ARG_EQUALS, "the command line arguments must be forwarded unchanged", "SpringApplication", "run", "1", "data:args")
                    .check(CheckType.NO_EXCEPTION, "the entry point must not abort for this argument condition")
                    .build()),
            new DbEditorApplicationWrapper());
    }

    @Test
    @DisplayName("UTAPI-000006")
    void case_UTAPI_000006() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000006",
                "com.matsushita.dbeditor.DbEditorApplication",
                "main",
                "void",
                new ParamSpec[] {
                    new ParamSpec("args", "String[]", "args")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000006", "args", "TARGET", "COLLECTION", "String[]"),
                    new DataRef("UTAPI-000006", "args[]", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000006")
                    .targetId("./java/com/matsushita/dbeditor/DbEditorApplication.java::DbEditorApplication::main::1::ARG::1::-::args")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("args", "args")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.APPLICATION_BOOTSTRAP)
                    .observation("the bootstrap call performed by main")
                    .expected("SpringApplication.run receives the application class and exactly the supplied argument array")
                    .failure("the arguments are dropped, replaced or rewritten before the application is started")
                    .assertion("verify the recorded static invocation and assertArrayEquals on the forwarded arguments")
                    .check(CheckType.INVOKED_ONCE, "the entry point must start the application exactly once", "SpringApplication", "run")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the application class must be handed to the bootstrap", "SpringApplication", "run", "0", "text:DbEditorApplication")
                    .check(CheckType.ARG_EQUALS, "the command line arguments must be forwarded unchanged", "SpringApplication", "run", "1", "data:args")
                    .check(CheckType.NO_EXCEPTION, "the entry point must not abort for this argument condition")
                    .build()),
            new DbEditorApplicationWrapper());
    }

    @Test
    @DisplayName("UTAPI-000007")
    void case_UTAPI_000007() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000007",
                "com.matsushita.dbeditor.DbEditorApplication",
                "main",
                "void",
                new ParamSpec[] {
                    new ParamSpec("args", "String[]", "args")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000007", "args", "TARGET", "COLLECTION", "String[]"),
                    new DataRef("UTAPI-000007", "args[]", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000007")
                    .targetId("./java/com/matsushita/dbeditor/DbEditorApplication.java::DbEditorApplication::main::1::ARG::1::-::args")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("args", "args")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.APPLICATION_BOOTSTRAP)
                    .observation("the bootstrap call performed by main")
                    .expected("SpringApplication.run receives the application class and exactly the supplied argument array")
                    .failure("the arguments are dropped, replaced or rewritten before the application is started")
                    .assertion("verify the recorded static invocation and assertArrayEquals on the forwarded arguments")
                    .check(CheckType.INVOKED_ONCE, "the entry point must start the application exactly once", "SpringApplication", "run")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the application class must be handed to the bootstrap", "SpringApplication", "run", "0", "text:DbEditorApplication")
                    .check(CheckType.ARG_EQUALS, "the command line arguments must be forwarded unchanged", "SpringApplication", "run", "1", "data:args")
                    .check(CheckType.NO_EXCEPTION, "the entry point must not abort for this argument condition")
                    .build()),
            new DbEditorApplicationWrapper());
    }

}

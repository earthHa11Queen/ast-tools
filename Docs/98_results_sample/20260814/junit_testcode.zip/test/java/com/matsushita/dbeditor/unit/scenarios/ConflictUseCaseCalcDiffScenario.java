package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ConflictUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ConflictUseCase#calcDiff.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ConflictUseCaseCalcDiffScenario {

    @Test
    @DisplayName("UTAPI-011549")
    void case_UTAPI_011549() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011549",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011549", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011549", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011549", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011549")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011550")
    void case_UTAPI_011550() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011550",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011550", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011550", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011550", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011550")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011551")
    void case_UTAPI_011551() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011551",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011551", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011551", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011551", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011551")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011552")
    void case_UTAPI_011552() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011552",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011552", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011552", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011552", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011552")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011553")
    void case_UTAPI_011553() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011553",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011553", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011553", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011553", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011553")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011554")
    void case_UTAPI_011554() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011554",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011554", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011554", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011554", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011554")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011555")
    void case_UTAPI_011555() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011555",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011555", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011555", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011555", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011555")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011556")
    void case_UTAPI_011556() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011556",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011556", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011556", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011556", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011556")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011557")
    void case_UTAPI_011557() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011557",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011557", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011557", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011557", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011557")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011558")
    void case_UTAPI_011558() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011558",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011558", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011558", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011558", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011558")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011559")
    void case_UTAPI_011559() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011559",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011559", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011559", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011559", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011559")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011560")
    void case_UTAPI_011560() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011560",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011560", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011560", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011560", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011560")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011561")
    void case_UTAPI_011561() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011561",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011561", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011561", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011561", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011561")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011562")
    void case_UTAPI_011562() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011562",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011562", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011562", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011562", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011562")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011563")
    void case_UTAPI_011563() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011563",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011563", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011563", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011563", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011563")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011564")
    void case_UTAPI_011564() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011564",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011564", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011564", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011564", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011564")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011565")
    void case_UTAPI_011565() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011565",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011565", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011565", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011565", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011565")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011566")
    void case_UTAPI_011566() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011566",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011566", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011566", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011566", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011566")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011567")
    void case_UTAPI_011567() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011567",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011567", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011567", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011567", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011567")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011568")
    void case_UTAPI_011568() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011568",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011568", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011568", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011568", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011568")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011569")
    void case_UTAPI_011569() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011569",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011569", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011569", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011569", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011569")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011570")
    void case_UTAPI_011570() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011570",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011570", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011570", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011570", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011570")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011571")
    void case_UTAPI_011571() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011571",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011571", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011571", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011571", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011571")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011572")
    void case_UTAPI_011572() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011572",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011572", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011572", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011572", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011572")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011573")
    void case_UTAPI_011573() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011573",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011573", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011573", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011573", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011573")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011574")
    void case_UTAPI_011574() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011574",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011574", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011574", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011574", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011574")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011575")
    void case_UTAPI_011575() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011575",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011575", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011575", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011575", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011575")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011576")
    void case_UTAPI_011576() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011576",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011576", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011576", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011576", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011576")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011577")
    void case_UTAPI_011577() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011577",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011577", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011577", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011577", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011577")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011578")
    void case_UTAPI_011578() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011578",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011578", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011578", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011578", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011578")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011579")
    void case_UTAPI_011579() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011579",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011579", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011579", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011579", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011579")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011580")
    void case_UTAPI_011580() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011580",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011580", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011580", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011580", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011580")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011581")
    void case_UTAPI_011581() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011581",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011581", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011581", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011581", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011581")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011582")
    void case_UTAPI_011582() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011582",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011582", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011582", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011582", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011582")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011583")
    void case_UTAPI_011583() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011583",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011583", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011583", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011583", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011583")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011584")
    void case_UTAPI_011584() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011584",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011584", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011584", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011584", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011584")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011585")
    void case_UTAPI_011585() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011585",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011585", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011585", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011585", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011585")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011586")
    void case_UTAPI_011586() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011586",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011586", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011586", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011586", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011586")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011587")
    void case_UTAPI_011587() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011587",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011587", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011587", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011587", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011587")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011588")
    void case_UTAPI_011588() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011588",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011588", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011588", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011588", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011588")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011589")
    void case_UTAPI_011589() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011589",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011589", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011589", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011589", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011589")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011590")
    void case_UTAPI_011590() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011590",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011590", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011590", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011590", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011590")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011591")
    void case_UTAPI_011591() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011591",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011591", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011591", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011591", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011591")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011592")
    void case_UTAPI_011592() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011592",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011592", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011592", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011592", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011592")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011593")
    void case_UTAPI_011593() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011593",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011593", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011593", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011593", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011593")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011594")
    void case_UTAPI_011594() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011594",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011594", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011594", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011594", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011594")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011595")
    void case_UTAPI_011595() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011595",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011595", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011595", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011595", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011595")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011596")
    void case_UTAPI_011596() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011596",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011596", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011596", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011596", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011596")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011597")
    void case_UTAPI_011597() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011597",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011597", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011597", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011597", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011597")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011598")
    void case_UTAPI_011598() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011598",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011598", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011598", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011598", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011598")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011599")
    void case_UTAPI_011599() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011599",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011599", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011599", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011599", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011599")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011600")
    void case_UTAPI_011600() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011600",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011600", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011600", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011600", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011600")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011601")
    void case_UTAPI_011601() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011601",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011601", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011601", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011601", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011601")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.calcDiff")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.calcDiff must carry the value generated for schemaName", "tableConflictRepository", "calcDiff", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.calcDiff must carry the value generated for tableName", "tableConflictRepository", "calcDiff", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableConflictRepository.calcDiff", "tableConflictRepository", "calcDiff")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

}

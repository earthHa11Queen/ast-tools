package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for SqlController.
 */
public final class SqlControllerWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.adapter.controller.SqlController";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.adapter.controller.SqlController";
    private static final String[] DEP_NAMES = new String[] {"sqlUseCase"};
    private static final String[] DEP_TYPES = new String[] {"SqlUseCase"};
    private static final String[] TYPES_downloadSql = new String[] {"Integer"};
    private static final String[] TYPES_executeSql = new String[] {"SqlExecuteRequest"};
    private static final String[] TYPES_getSql = new String[] {"Integer"};
    private static final String[] TYPES_listSql = new String[] {"Integer"};
    private static final String[] TYPES_saveSql = new String[] {"SqlSaveRequest"};
    private static final String[] TYPES_uploadSql = new String[] {"Integer", "MultipartFile"};

    public SqlControllerWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, false);
    }

    /** ResponseEntity<byte[]> downloadSql(id) */
    public ExecutionResult downloadSql(Object[] args) {
        return invoke("downloadSql", TYPES_downloadSql, args);
    }

    /** ResponseEntity<SqlExecuteResponse> executeSql(request) */
    public ExecutionResult executeSql(Object[] args) {
        return invoke("executeSql", TYPES_executeSql, args);
    }

    /** ResponseEntity<SqlResponse> getSql(id) */
    public ExecutionResult getSql(Object[] args) {
        return invoke("getSql", TYPES_getSql, args);
    }

    /** ResponseEntity<List<SqlResponse>> listSql(connectionId) */
    public ExecutionResult listSql(Object[] args) {
        return invoke("listSql", TYPES_listSql, args);
    }

    /** ResponseEntity<SqlResponse> saveSql(request) */
    public ExecutionResult saveSql(Object[] args) {
        return invoke("saveSql", TYPES_saveSql, args);
    }

    /** ResponseEntity<SqlResponse> uploadSql(connectionId, file) */
    public ExecutionResult uploadSql(Object[] args) {
        return invoke("uploadSql", TYPES_uploadSql, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("downloadSql".equals(operation)) {
            return downloadSql(args);
        } else if ("executeSql".equals(operation)) {
            return executeSql(args);
        } else if ("getSql".equals(operation)) {
            return getSql(args);
        } else if ("listSql".equals(operation)) {
            return listSql(args);
        } else if ("saveSql".equals(operation)) {
            return saveSql(args);
        } else if ("uploadSql".equals(operation)) {
            return uploadSql(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

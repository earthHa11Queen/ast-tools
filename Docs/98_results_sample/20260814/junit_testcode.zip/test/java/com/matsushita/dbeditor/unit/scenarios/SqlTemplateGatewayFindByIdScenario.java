package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SqlTemplateGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SqlTemplateGateway#findById.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SqlTemplateGatewayFindByIdScenario {

    @Test
    @DisplayName("UTAPI-003056")
    void case_UTAPI_003056() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003056",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "findById",
                "Optional<SqlTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003056", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-003056")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::findById::2::ARG::1::-::n")
                    .mirror("-", "1:length_null", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003057")
    void case_UTAPI_003057() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003057",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "findById",
                "Optional<SqlTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003057", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-003057")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::findById::2::ARG::1::-::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003058")
    void case_UTAPI_003058() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003058",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "findById",
                "Optional<SqlTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003058", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-003058")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::findById::2::ARG::1::-::n")
                    .mirror("-", "3:length_min", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003059")
    void case_UTAPI_003059() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003059",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "findById",
                "Optional<SqlTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003059", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-003059")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::findById::2::ARG::1::-::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003060")
    void case_UTAPI_003060() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003060",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "findById",
                "Optional<SqlTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003060", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-003060")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::findById::2::ARG::1::-::n")
                    .mirror("-", "5:length_max", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003061")
    void case_UTAPI_003061() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003061",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "findById",
                "Optional<SqlTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003061", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-003061")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::findById::2::ARG::1::-::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003062")
    void case_UTAPI_003062() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003062",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "findById",
                "Optional<SqlTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003062", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-003062")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::findById::2::ARG::1::-::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003063")
    void case_UTAPI_003063() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003063",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "findById",
                "Optional<SqlTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003063", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-003063")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::findById::2::ARG::1::-::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003064")
    void case_UTAPI_003064() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003064",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "findById",
                "Optional<SqlTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003064", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-003064")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::findById::2::ARG::1::-::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003065")
    void case_UTAPI_003065() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003065",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "findById",
                "Optional<SqlTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003065", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-003065")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::findById::2::ARG::1::-::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003066")
    void case_UTAPI_003066() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003066",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "findById",
                "Optional<SqlTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003066", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-003066")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::findById::2::ARG::1::-::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

}

package com.matsushita.dbeditor.fixtures;

import java.lang.reflect.Method;

import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.matsushita.dbeditor.constants.AstMethodReturns;

/**
 * Answers collaborator calls with the deterministic result declared by the collaborator
 * contract in AST Method Level. Keeps a stable identity per collaborator operation so the
 * Oracle can tell whether the SUT actually returned the collaborator result.
 */
public final class SentinelAnswer implements Answer<Object> {

    private final SentinelRegistry registry;

    public SentinelAnswer(SentinelRegistry registry) {
        this.registry = registry;
    }

    @Override
    public Object answer(InvocationOnMock invocation) {
        Method method = invocation.getMethod();
        String owner = method.getDeclaringClass().getSimpleName();
        String key = owner + "#" + method.getName();
        String declared = AstMethodReturns.returnTypeOf(owner, method.getName());
        Object hint = null;
        Object[] args = invocation.getArguments();
        for (int i = 0; i < args.length; i++) {
            if (args[i] instanceof Class) {
                hint = args[i];
            }
        }
        Class<?> raw = method.getReturnType();
        if (raw == void.class) {
            return null;
        }
        Object value = registry.forOperation(key, declared, raw, hint);
        if (value == null) {
            return null;
        }
        if (raw.isPrimitive() || raw.isInstance(value)) {
            return value;
        }
        return registry.forOperation(key + "#raw", null, raw, hint);
    }
}

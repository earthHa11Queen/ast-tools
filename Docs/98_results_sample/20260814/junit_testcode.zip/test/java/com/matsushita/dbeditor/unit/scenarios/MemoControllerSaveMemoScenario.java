package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.MemoControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for MemoController#saveMemo.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class MemoControllerSaveMemoScenario {

    @Test
    @DisplayName("UTAPI-000868")
    void case_UTAPI_000868() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000868",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000868", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000868", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000868", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000868", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000868", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000868", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000868")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "0", "data:connectionId", "data:request.connectionId")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000869")
    void case_UTAPI_000869() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000869",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000869", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000869", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000869", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000869", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000869", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000869", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000869")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "0", "data:connectionId", "data:request.connectionId")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000870")
    void case_UTAPI_000870() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000870",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000870", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000870", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000870", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000870", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000870", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000870", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000870")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "0", "data:connectionId", "data:request.connectionId")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000871")
    void case_UTAPI_000871() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000871",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000871", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000871", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000871", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000871", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000871", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000871", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000871")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "0", "data:connectionId", "data:request.connectionId")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000872")
    void case_UTAPI_000872() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000872",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000872", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000872", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000872", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000872", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000872", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000872", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000872")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "0", "data:connectionId", "data:request.connectionId")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000873")
    void case_UTAPI_000873() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000873",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000873", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000873", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000873", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000873", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000873", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000873", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000873")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "0", "data:connectionId", "data:request.connectionId")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000874")
    void case_UTAPI_000874() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000874",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000874", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000874", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000874", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000874", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000874", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000874", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000874")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "0", "data:connectionId", "data:request.connectionId")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000875")
    void case_UTAPI_000875() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000875",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000875", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000875", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000875", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000875", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000875", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000875", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000875")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "0", "data:connectionId", "data:request.connectionId")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000876")
    void case_UTAPI_000876() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000876",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000876", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000876", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000876", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000876", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000876", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000876", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000876")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "0", "data:connectionId", "data:request.connectionId")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000877")
    void case_UTAPI_000877() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000877",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000877", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000877", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000877", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000877", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000877", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000877", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000877")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "0", "data:connectionId", "data:request.connectionId")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000878")
    void case_UTAPI_000878() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000878",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000878", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000878", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000878", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000878", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000878", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000878", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000878")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "0", "data:connectionId", "data:request.connectionId")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000879")
    void case_UTAPI_000879() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000879",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000879", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000879", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000879", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000879", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000879", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000879", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000879")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000880")
    void case_UTAPI_000880() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000880",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000880", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000880", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000880", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000880", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000880", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000880", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000880")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000881")
    void case_UTAPI_000881() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000881",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000881", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000881", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000881", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000881", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000881", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000881", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000881")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000882")
    void case_UTAPI_000882() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000882",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000882", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000882", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000882", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000882", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000882", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000882", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000882")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000883")
    void case_UTAPI_000883() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000883",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000883", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000883", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000883", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000883", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000883", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000883", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000883")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000884")
    void case_UTAPI_000884() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000884",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000884", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000884", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000884", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000884", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000884", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000884", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000884")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000885")
    void case_UTAPI_000885() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000885",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000885", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000885", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000885", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000885", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000885", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000885", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000885")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000886")
    void case_UTAPI_000886() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000886",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000886", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000886", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000886", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000886", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000886", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000886", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000886")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::2::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000887")
    void case_UTAPI_000887() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000887",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000887", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000887", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000887", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000887", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000887", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000887", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000887")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::2::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000888")
    void case_UTAPI_000888() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000888",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000888", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000888", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000888", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000888", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000888", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000888", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000888")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::2::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000889")
    void case_UTAPI_000889() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000889",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000889", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000889", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000889", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000889", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000889", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000889", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000889")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::2::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000890")
    void case_UTAPI_000890() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000890",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000890", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000890", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000890", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000890", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000890", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000890", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000890")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000891")
    void case_UTAPI_000891() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000891",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000891", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000891", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000891", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000891", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000891", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000891", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000891")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000892")
    void case_UTAPI_000892() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000892",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000892", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000892", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000892", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000892", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000892", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000892", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000892")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000893")
    void case_UTAPI_000893() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000893",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000893", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000893", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000893", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000893", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000893", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000893", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000893")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000894")
    void case_UTAPI_000894() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000894",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000894", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000894", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000894", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000894", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000894", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000894", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000894")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000895")
    void case_UTAPI_000895() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000895",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000895", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000895", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000895", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000895", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000895", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000895", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000895")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000896")
    void case_UTAPI_000896() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000896",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000896", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000896", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000896", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000896", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000896", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000896", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000896")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000897")
    void case_UTAPI_000897() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000897",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000897", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000897", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000897", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000897", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000897", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000897", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000897")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000898")
    void case_UTAPI_000898() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000898",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000898", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000898", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000898", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000898", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000898", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000898", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000898")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000899")
    void case_UTAPI_000899() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000899",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000899", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000899", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000899", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000899", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000899", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000899", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000899")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000900")
    void case_UTAPI_000900() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000900",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000900", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000900", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000900", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000900", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000900", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000900", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000900")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.connectionId", "MemoSaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "0", "data:connectionId", "data:request.connectionId")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MemoSaveRequest.connectionId classifies this input condition", "MemoSaveRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000901")
    void case_UTAPI_000901() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000901",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000901", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000901", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000901", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000901", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000901", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000901", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000901")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("request.connectionId", "MemoSaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "0", "data:connectionId", "data:request.connectionId")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MemoSaveRequest.connectionId classifies this input condition", "MemoSaveRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000902")
    void case_UTAPI_000902() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000902",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000902", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000902", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000902", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000902", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000902", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000902", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000902")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.connectionId", "MemoSaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "0", "data:connectionId", "data:request.connectionId")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MemoSaveRequest.connectionId classifies this input condition", "MemoSaveRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000903")
    void case_UTAPI_000903() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000903",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000903", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000903", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000903", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000903", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000903", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000903", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000903")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("request.connectionId", "MemoSaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "0", "data:connectionId", "data:request.connectionId")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MemoSaveRequest.connectionId classifies this input condition", "MemoSaveRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000904")
    void case_UTAPI_000904() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000904",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000904", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000904", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000904", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000904", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000904", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000904", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000904")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.connectionId", "MemoSaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "0", "data:connectionId", "data:request.connectionId")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MemoSaveRequest.connectionId classifies this input condition", "MemoSaveRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000905")
    void case_UTAPI_000905() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000905",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000905", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000905", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000905", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000905", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000905", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000905", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000905")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.connectionId", "MemoSaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "0", "data:connectionId", "data:request.connectionId")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MemoSaveRequest.connectionId classifies this input condition", "MemoSaveRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000906")
    void case_UTAPI_000906() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000906",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000906", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000906", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000906", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000906", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000906", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000906", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000906")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("request.connectionId", "MemoSaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "0", "data:connectionId", "data:request.connectionId")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000907")
    void case_UTAPI_000907() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000907",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000907", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000907", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000907", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000907", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000907", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000907", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000907")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("request.connectionId", "MemoSaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "0", "data:connectionId", "data:request.connectionId")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000908")
    void case_UTAPI_000908() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000908",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000908", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000908", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000908", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000908", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000908", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000908", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000908")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("request.connectionId", "MemoSaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "0", "data:connectionId", "data:request.connectionId")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000909")
    void case_UTAPI_000909() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000909",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000909", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000909", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000909", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000909", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000909", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000909", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000909")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("request.connectionId", "MemoSaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "0", "data:connectionId", "data:request.connectionId")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000910")
    void case_UTAPI_000910() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000910",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000910", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000910", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000910", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000910", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000910", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000910", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000910")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::content")
                    .mirror("-", "1:length_null", "-")
                    .target("request.content", "MemoSaveRequest.content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000911")
    void case_UTAPI_000911() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000911",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000911", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000911", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000911", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000911", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000911", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000911", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000911")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::content")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.content", "MemoSaveRequest.content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000912")
    void case_UTAPI_000912() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000912",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000912", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000912", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000912", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000912", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000912", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000912", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000912")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::content")
                    .mirror("-", "3:length_min", "-")
                    .target("request.content", "MemoSaveRequest.content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000913")
    void case_UTAPI_000913() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000913",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000913", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000913", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000913", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000913", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000913", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000913", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000913")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::content")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.content", "MemoSaveRequest.content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000914")
    void case_UTAPI_000914() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000914",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000914", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000914", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000914", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000914", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000914", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000914", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000914")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::content")
                    .mirror("-", "5:length_max", "-")
                    .target("request.content", "MemoSaveRequest.content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000915")
    void case_UTAPI_000915() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000915",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000915", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000915", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000915", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000915", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000915", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000915", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000915")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::content")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.content", "MemoSaveRequest.content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000916")
    void case_UTAPI_000916() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000916",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000916", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000916", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000916", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000916", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000916", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000916", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000916")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::content")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.content", "MemoSaveRequest.content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000917")
    void case_UTAPI_000917() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000917",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000917", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000917", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000917", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000917", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000917", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000917", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000917")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::content")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.content", "MemoSaveRequest.content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000918")
    void case_UTAPI_000918() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000918",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000918", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000918", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000918", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000918", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000918", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000918", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000918")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::content")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.content", "MemoSaveRequest.content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000919")
    void case_UTAPI_000919() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000919",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000919", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000919", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000919", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000919", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000919", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000919", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000919")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::content")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.content", "MemoSaveRequest.content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000920")
    void case_UTAPI_000920() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000920",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000920", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000920", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000920", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000920", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000920", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000920", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000920")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::content")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.content", "MemoSaveRequest.content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000921")
    void case_UTAPI_000921() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000921",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000921", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000921", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000921", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000921", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000921", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000921", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000921")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::content")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.content", "MemoSaveRequest.content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000922")
    void case_UTAPI_000922() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000922",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000922", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000922", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000922", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000922", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000922", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000922", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000922")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::content")
                    .mirror("-", "-", "56:space")
                    .target("request.content", "MemoSaveRequest.content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000923")
    void case_UTAPI_000923() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000923",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000923", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000923", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000923", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000923", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000923", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000923", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000923")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::content")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.content", "MemoSaveRequest.content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000924")
    void case_UTAPI_000924() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000924",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000924", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000924", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000924", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000924", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000924", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000924", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000924")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::content")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.content", "MemoSaveRequest.content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000925")
    void case_UTAPI_000925() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000925",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000925", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000925", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000925", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000925", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000925", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000925", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000925")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::content")
                    .mirror("-", "-", "59:tab")
                    .target("request.content", "MemoSaveRequest.content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000926")
    void case_UTAPI_000926() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000926",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000926", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000926", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000926", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000926", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000926", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000926", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000926")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::content")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.content", "MemoSaveRequest.content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000927")
    void case_UTAPI_000927() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000927",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000927", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000927", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000927", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000927", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000927", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000927", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000927")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::content")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.content", "MemoSaveRequest.content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000928")
    void case_UTAPI_000928() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000928",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000928", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000928", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000928", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000928", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000928", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000928", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000928")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::content")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.content", "MemoSaveRequest.content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000929")
    void case_UTAPI_000929() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000929",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000929", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000929", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000929", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000929", "request.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000929", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000929", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000929")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::content")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.content", "MemoSaveRequest.content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000930")
    void case_UTAPI_000930() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000930",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000930", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000930", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000930", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000930", "request.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000930", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000930", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000930")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.tableName", "MemoSaveRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MemoSaveRequest.tableName classifies this input condition", "MemoSaveRequest", "tableName", "NotNull", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000931")
    void case_UTAPI_000931() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000931",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000931", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000931", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000931", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000931", "request.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000931", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000931", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000931")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("request.tableName", "MemoSaveRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MemoSaveRequest.tableName classifies this input condition", "MemoSaveRequest", "tableName", "NotNull", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000932")
    void case_UTAPI_000932() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000932",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000932", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000932", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000932", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000932", "request.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000932", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000932", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000932")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.tableName", "MemoSaveRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MemoSaveRequest.tableName classifies this input condition", "MemoSaveRequest", "tableName", "NotNull", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000933")
    void case_UTAPI_000933() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000933",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000933", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000933", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000933", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000933", "request.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000933", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000933", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000933")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("request.tableName", "MemoSaveRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MemoSaveRequest.tableName classifies this input condition", "MemoSaveRequest", "tableName", "NotNull", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000934")
    void case_UTAPI_000934() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000934",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000934", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000934", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000934", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000934", "request.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000934", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000934", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000934")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.tableName", "MemoSaveRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MemoSaveRequest.tableName classifies this input condition", "MemoSaveRequest", "tableName", "NotNull", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000935")
    void case_UTAPI_000935() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000935",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000935", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000935", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000935", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000935", "request.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000935", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000935", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000935")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.tableName", "MemoSaveRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of MemoSaveRequest.tableName classifies this input condition", "MemoSaveRequest", "tableName", "NotNull", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000936")
    void case_UTAPI_000936() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000936",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000936", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000936", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000936", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000936", "request.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000936", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000936", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000936")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.tableName", "MemoSaveRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000937")
    void case_UTAPI_000937() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000937",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000937", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000937", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000937", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000937", "request.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000937", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000937", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000937")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.tableName", "MemoSaveRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000938")
    void case_UTAPI_000938() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000938",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000938", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000938", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000938", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000938", "request.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000938", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000938", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000938")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.tableName", "MemoSaveRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000939")
    void case_UTAPI_000939() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000939",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000939", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000939", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000939", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000939", "request.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000939", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000939", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000939")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.tableName", "MemoSaveRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000940")
    void case_UTAPI_000940() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000940",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000940", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000940", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000940", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000940", "request.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000940", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000940", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000940")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.tableName", "MemoSaveRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000941")
    void case_UTAPI_000941() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000941",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000941", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000941", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000941", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000941", "request.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000941", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000941", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000941")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.tableName", "MemoSaveRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000942")
    void case_UTAPI_000942() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000942",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000942", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000942", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000942", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000942", "request.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000942", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000942", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000942")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::tableName")
                    .mirror("-", "-", "56:space")
                    .target("request.tableName", "MemoSaveRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000943")
    void case_UTAPI_000943() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000943",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000943", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000943", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000943", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000943", "request.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000943", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000943", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000943")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.tableName", "MemoSaveRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000944")
    void case_UTAPI_000944() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000944",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000944", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000944", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000944", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000944", "request.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000944", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000944", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000944")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.tableName", "MemoSaveRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000945")
    void case_UTAPI_000945() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000945",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000945", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000945", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000945", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000945", "request.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000945", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000945", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000945")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("request.tableName", "MemoSaveRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000946")
    void case_UTAPI_000946() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000946",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000946", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000946", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000946", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000946", "request.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000946", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000946", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000946")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.tableName", "MemoSaveRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000947")
    void case_UTAPI_000947() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000947",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000947", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000947", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000947", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000947", "request.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000947", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000947", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000947")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.tableName", "MemoSaveRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000948")
    void case_UTAPI_000948() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000948",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000948", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000948", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000948", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000948", "request.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000948", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000948", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000948")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.tableName", "MemoSaveRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000949")
    void case_UTAPI_000949() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000949",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "saveMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("request", "MemoSaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000949", "request", "NORMAL", "OBJECT", "MemoSaveRequest"),
                    new DataRef("UTAPI-000949", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000949", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000949", "request.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000949", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000949", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000949")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::saveMemo::2::FIELD::3::MemoSaveRequest::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.tableName", "MemoSaveRequest.tableName")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.saveMemo")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.saveMemo", "memoUseCase", "saveMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.saveMemo must carry the value generated for connectionId", "memoUseCase", "saveMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.saveMemo must carry the value generated for tableName", "memoUseCase", "saveMemo", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of memoUseCase.saveMemo must carry the value generated for request.content", "memoUseCase", "saveMemo", "2", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.VALUE_NOT_SUBSTITUTED, "the addressed resource identifier must win over the duplicated body value", "memoUseCase", "saveMemo", "1", "data:tableName", "data:request.tableName")
                    .build()),
            new MemoControllerWrapper());
    }

}

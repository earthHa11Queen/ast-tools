package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ImportControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ImportController#excelAutoMapping.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ImportControllerExcelAutoMappingScenario {

    @Test
    @DisplayName("UTAPI-000736")
    void case_UTAPI_000736() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000736",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000736", "file", "TARGET", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000736", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000736", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000736", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000736", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000736")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::1::-::file")
                    .mirror("-", "1:length_null", "-")
                    .target("file", "file")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for file is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_REQUIRED, "an absent upload cannot be processed", "java.lang.RuntimeException", "data:file")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000737")
    void case_UTAPI_000737() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000737",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000737", "file", "TARGET", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000737", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000737", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000737", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000737", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000737")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::1::-::file")
                    .mirror("-", "2:length_empty", "-")
                    .target("file", "file")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for file is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SAME, "the uploaded document must be handed on as it was received", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000738")
    void case_UTAPI_000738() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000738",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000738", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000738", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000738", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000738", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000738", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000738")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::2::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000739")
    void case_UTAPI_000739() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000739",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000739", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000739", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000739", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000739", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000739", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000739")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::2::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000740")
    void case_UTAPI_000740() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000740",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000740", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000740", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000740", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000740", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000740", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000740")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::2::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000741")
    void case_UTAPI_000741() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000741",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000741", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000741", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000741", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000741", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000741", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000741")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::2::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000742")
    void case_UTAPI_000742() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000742",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000742", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000742", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000742", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000742", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000742", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000742")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::2::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000743")
    void case_UTAPI_000743() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000743",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000743", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000743", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000743", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000743", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000743", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000743")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::2::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000744")
    void case_UTAPI_000744() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000744",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000744", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000744", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000744", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000744", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000744", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000744")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::2::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000745")
    void case_UTAPI_000745() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000745",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000745", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000745", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000745", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000745", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000745", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000745")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::2::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000746")
    void case_UTAPI_000746() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000746",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000746", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000746", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000746", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000746", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000746", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000746")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::2::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000747")
    void case_UTAPI_000747() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000747",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000747", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000747", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000747", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000747", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000747", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000747")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::2::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000748")
    void case_UTAPI_000748() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000748",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000748", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000748", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000748", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000748", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000748", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000748")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::2::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000749")
    void case_UTAPI_000749() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000749",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000749", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000749", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000749", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000749", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000749", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000749")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000750")
    void case_UTAPI_000750() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000750",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000750", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000750", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000750", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000750", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000750", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000750")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000751")
    void case_UTAPI_000751() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000751",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000751", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000751", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000751", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000751", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000751", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000751")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000752")
    void case_UTAPI_000752() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000752",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000752", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000752", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000752", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000752", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000752", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000752")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000753")
    void case_UTAPI_000753() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000753",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000753", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000753", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000753", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000753", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000753", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000753")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000754")
    void case_UTAPI_000754() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000754",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000754", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000754", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000754", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000754", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000754", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000754")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000755")
    void case_UTAPI_000755() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000755",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000755", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000755", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000755", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000755", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000755", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000755")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000756")
    void case_UTAPI_000756() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000756",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000756", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000756", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000756", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000756", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000756", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000756")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000757")
    void case_UTAPI_000757() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000757",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000757", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000757", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000757", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000757", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000757", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000757")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000758")
    void case_UTAPI_000758() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000758",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000758", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000758", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000758", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000758", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000758", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000758")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000759")
    void case_UTAPI_000759() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000759",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000759", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000759", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000759", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000759", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000759", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000759")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000760")
    void case_UTAPI_000760() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000760",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000760", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000760", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000760", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000760", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000760", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000760")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000761")
    void case_UTAPI_000761() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000761",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000761", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000761", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000761", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000761", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000761", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000761")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000762")
    void case_UTAPI_000762() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000762",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000762", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000762", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000762", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000762", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000762", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000762")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000763")
    void case_UTAPI_000763() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000763",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000763", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000763", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000763", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000763", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000763", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000763")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000764")
    void case_UTAPI_000764() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000764",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000764", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000764", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000764", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000764", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000764", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000764")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000765")
    void case_UTAPI_000765() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000765",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000765", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000765", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000765", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000765", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000765", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000765")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000766")
    void case_UTAPI_000766() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000766",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000766", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000766", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000766", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000766", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000766", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000766")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000767")
    void case_UTAPI_000767() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000767",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000767", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000767", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000767", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000767", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000767", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000767")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000768")
    void case_UTAPI_000768() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000768",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000768", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000768", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000768", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000768", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000768", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000768")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000769")
    void case_UTAPI_000769() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000769",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000769", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000769", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000769", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000769", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000769", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000769")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000770")
    void case_UTAPI_000770() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000770",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000770", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000770", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000770", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000770", "sheetIndex", "TARGET", "NUMBER", "int"),
                    new DataRef("UTAPI-000770", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000770")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::4::-::sheetIndex")
                    .mirror("-", "1:length_null", "-")
                    .target("sheetIndex", "sheetIndex")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for sheetIndex is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000771")
    void case_UTAPI_000771() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000771",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000771", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000771", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000771", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000771", "sheetIndex", "TARGET", "NUMBER", "int"),
                    new DataRef("UTAPI-000771", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000771")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::4::-::sheetIndex")
                    .mirror("-", "2:length_empty", "-")
                    .target("sheetIndex", "sheetIndex")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for sheetIndex is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000772")
    void case_UTAPI_000772() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000772",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000772", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000772", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000772", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000772", "sheetIndex", "TARGET", "NUMBER", "int"),
                    new DataRef("UTAPI-000772", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000772")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::4::-::sheetIndex")
                    .mirror("-", "3:length_min", "-")
                    .target("sheetIndex", "sheetIndex")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for sheetIndex is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000773")
    void case_UTAPI_000773() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000773",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000773", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000773", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000773", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000773", "sheetIndex", "TARGET", "NUMBER", "int"),
                    new DataRef("UTAPI-000773", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000773")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::4::-::sheetIndex")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("sheetIndex", "sheetIndex")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for sheetIndex is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000774")
    void case_UTAPI_000774() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000774",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000774", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000774", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000774", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000774", "sheetIndex", "TARGET", "NUMBER", "int"),
                    new DataRef("UTAPI-000774", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000774")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::4::-::sheetIndex")
                    .mirror("-", "5:length_max", "-")
                    .target("sheetIndex", "sheetIndex")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for sheetIndex is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000775")
    void case_UTAPI_000775() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000775",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000775", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000775", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000775", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000775", "sheetIndex", "TARGET", "NUMBER", "int"),
                    new DataRef("UTAPI-000775", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000775")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::4::-::sheetIndex")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("sheetIndex", "sheetIndex")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for sheetIndex is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000776")
    void case_UTAPI_000776() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000776",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000776", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000776", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000776", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000776", "sheetIndex", "TARGET", "NUMBER", "int"),
                    new DataRef("UTAPI-000776", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000776")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::4::-::sheetIndex")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("sheetIndex", "sheetIndex")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for sheetIndex is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000777")
    void case_UTAPI_000777() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000777",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000777", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000777", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000777", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000777", "sheetIndex", "TARGET", "NUMBER", "int"),
                    new DataRef("UTAPI-000777", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000777")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::4::-::sheetIndex")
                    .mirror("46:hw_integer", "-", "-")
                    .target("sheetIndex", "sheetIndex")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for sheetIndex is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000778")
    void case_UTAPI_000778() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000778",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000778", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000778", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000778", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000778", "sheetIndex", "TARGET", "NUMBER", "int"),
                    new DataRef("UTAPI-000778", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000778")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::4::-::sheetIndex")
                    .mirror("-", "-", "12:integer_positive")
                    .target("sheetIndex", "sheetIndex")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for sheetIndex is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000779")
    void case_UTAPI_000779() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000779",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000779", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000779", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000779", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000779", "sheetIndex", "TARGET", "NUMBER", "int"),
                    new DataRef("UTAPI-000779", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000779")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::4::-::sheetIndex")
                    .mirror("-", "-", "13:integer_negative")
                    .target("sheetIndex", "sheetIndex")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for sheetIndex is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000780")
    void case_UTAPI_000780() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000780",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000780", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000780", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000780", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000780", "sheetIndex", "TARGET", "NUMBER", "int"),
                    new DataRef("UTAPI-000780", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000780")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::4::-::sheetIndex")
                    .mirror("-", "-", "14:integer_zero")
                    .target("sheetIndex", "sheetIndex")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for sheetIndex is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000781")
    void case_UTAPI_000781() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000781",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000781", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000781", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000781", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000781", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000781", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000781")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::5::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000782")
    void case_UTAPI_000782() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000782",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000782", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000782", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000782", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000782", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000782", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000782")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::5::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000783")
    void case_UTAPI_000783() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000783",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000783", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000783", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000783", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000783", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000783", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000783")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::5::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000784")
    void case_UTAPI_000784() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000784",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000784", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000784", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000784", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000784", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000784", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000784")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::5::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000785")
    void case_UTAPI_000785() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000785",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000785", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000785", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000785", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000785", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000785", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000785")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::5::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000786")
    void case_UTAPI_000786() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000786",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000786", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000786", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000786", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000786", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000786", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000786")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::5::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000787")
    void case_UTAPI_000787() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000787",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000787", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000787", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000787", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000787", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000787", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000787")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::5::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000788")
    void case_UTAPI_000788() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000788",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000788", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000788", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000788", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000788", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000788", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000788")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::5::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000789")
    void case_UTAPI_000789() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000789",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000789", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000789", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000789", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000789", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000789", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000789")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::5::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000790")
    void case_UTAPI_000790() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000790",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000790", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000790", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000790", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000790", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000790", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000790")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::5::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000791")
    void case_UTAPI_000791() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000791",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000791", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000791", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000791", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000791", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000791", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000791")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::5::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000792")
    void case_UTAPI_000792() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000792",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000792", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000792", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000792", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000792", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000792", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000792")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::5::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000793")
    void case_UTAPI_000793() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000793",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000793", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000793", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000793", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000793", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000793", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000793")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::5::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000794")
    void case_UTAPI_000794() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000794",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000794", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000794", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000794", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000794", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000794", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000794")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::5::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000795")
    void case_UTAPI_000795() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000795",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000795", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000795", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000795", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000795", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000795", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000795")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::5::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000796")
    void case_UTAPI_000796() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000796",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000796", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000796", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000796", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000796", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000796", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000796")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::5::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000797")
    void case_UTAPI_000797() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000797",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000797", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000797", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000797", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000797", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000797", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000797")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::5::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000798")
    void case_UTAPI_000798() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000798",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000798", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000798", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000798", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000798", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000798", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000798")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::5::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000799")
    void case_UTAPI_000799() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000799",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000799", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000799", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000799", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000799", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000799", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000799")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::5::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000800")
    void case_UTAPI_000800() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000800",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000800", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000800", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000800", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000800", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000800", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000800")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::5::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000801")
    void case_UTAPI_000801() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000801",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "excelAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000801", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000801", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000801", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000801", "sheetIndex", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-000801", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000801")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::excelAutoMapping::3::ARG::5::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.excelSheetAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.excelSheetAutoMapping", "importUseCase", "excelSheetAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.excelSheetAutoMapping must carry the value generated for connectionId", "importUseCase", "excelSheetAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.excelSheetAutoMapping must carry the value generated for tableName", "importUseCase", "excelSheetAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.excelSheetAutoMapping must carry the value generated for schemaName", "importUseCase", "excelSheetAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.excelSheetAutoMapping must carry the value generated for file", "importUseCase", "excelSheetAutoMapping", "3", "data:file")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.excelSheetAutoMapping must carry the value generated for sheetIndex", "importUseCase", "excelSheetAutoMapping", "4", "data:sheetIndex")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TemplateControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TemplateController#listSqlTemplates.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TemplateControllerListSqlTemplatesScenario {

    @Test
    @DisplayName("UTAPI-001768")
    void case_UTAPI_001768() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001768",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "listSqlTemplates",
                "ResponseEntity<List<TemplateResponse>>",
                new ParamSpec[] {},
                new DataRef[] {},
                OraclePlan.builder("UTAPI-001768")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::listSqlTemplates::4::METHOD::-1::-::-")
                    .mirror("-", "-", "-")
                    .target("-", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.listSqlTemplates")
                    .expected("the value generated for - is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.listSqlTemplates", "templateUseCase", "listSqlTemplates")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the retrieved content")
                    .check(CheckType.RETURN_COLLECTION_SIZE_MATCHES_STUB, "the response must expose exactly what templateUseCase.listSqlTemplates returned", "templateUseCase", "listSqlTemplates")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

}

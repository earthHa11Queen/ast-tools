package com.matsushita.dbeditor.utils;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Map;

/**
 * Comparison and rendering helpers used by the Oracle. No test value is created here.
 */
public final class ValueSupport {

    private ValueSupport() {
    }

    public static boolean equal(Object expected, Object actual) {
        if (expected == actual) {
            return true;
        }
        if (expected == null || actual == null) {
            return false;
        }
        if (expected.getClass().isArray() && actual.getClass().isArray()) {
            int len = Array.getLength(expected);
            if (len != Array.getLength(actual)) {
                return false;
            }
            for (int i = 0; i < len; i++) {
                if (!equal(Array.get(expected, i), Array.get(actual, i))) {
                    return false;
                }
            }
            return true;
        }
        if (expected instanceof Number && actual instanceof Number
                && !expected.getClass().equals(actual.getClass())) {
            return ((Number) expected).doubleValue() == ((Number) actual).doubleValue();
        }
        return expected.equals(actual);
    }

    public static String render(Object value) {
        if (value == null) {
            return "null";
        }
        if (value.getClass().isArray()) {
            StringBuilder sb = new StringBuilder("[");
            int len = Array.getLength(value);
            for (int i = 0; i < len && i < 8; i++) {
                if (i > 0) {
                    sb.append(", ");
                }
                sb.append(render(Array.get(value, i)));
            }
            if (len > 8) {
                sb.append(", ...(").append(len).append(")");
            }
            return sb.append(']').toString();
        }
        String text = String.valueOf(value);
        if (text.length() > 200) {
            return text.substring(0, 200) + "...(len=" + text.length() + ")";
        }
        return text;
    }

    public static boolean containsText(Object container, Object fragment) {
        if (container == null || fragment == null) {
            return false;
        }
        String haystack = String.valueOf(container);
        String needle = String.valueOf(fragment);
        if (needle.isEmpty()) {
            return true;
        }
        return haystack.contains(needle);
    }

    /** Deep search for a value inside an object graph (collections, maps, arrays, bean getters). */
    public static boolean deepContains(Object graph, Object wanted, int depth) {
        if (depth < 0) {
            return false;
        }
        if (equal(wanted, graph)) {
            return true;
        }
        if (graph == null) {
            return false;
        }
        if (graph instanceof Collection) {
            for (Object o : (Collection<?>) graph) {
                if (deepContains(o, wanted, depth - 1)) {
                    return true;
                }
            }
            return false;
        }
        if (graph instanceof Map) {
            Map<?, ?> map = (Map<?, ?>) graph;
            for (Map.Entry<?, ?> e : map.entrySet()) {
                if (deepContains(e.getKey(), wanted, depth - 1) || deepContains(e.getValue(), wanted, depth - 1)) {
                    return true;
                }
            }
            return false;
        }
        if (graph.getClass().isArray()) {
            int len = Array.getLength(graph);
            for (int i = 0; i < len; i++) {
                if (deepContains(Array.get(graph, i), wanted, depth - 1)) {
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    public static Object property(Object bean, String getter) {
        if (bean == null) {
            return null;
        }
        try {
            java.lang.reflect.Method m = bean.getClass().getMethod(getter);
            m.setAccessible(true);
            return m.invoke(bean);
        } catch (NoSuchMethodException e) {
            throw new HarnessException("Getter " + getter + " not found on " + bean.getClass().getName(), e);
        } catch (Exception e) {
            throw new HarnessException("Getter " + getter + " failed on " + bean.getClass().getName(), e);
        }
    }

    public static boolean hasProperty(Object bean, String getter) {
        if (bean == null) {
            return false;
        }
        try {
            bean.getClass().getMethod(getter);
            return true;
        } catch (NoSuchMethodException e) {
            return false;
        }
    }

    public static int sizeOf(Object value) {
        if (value == null) {
            return -1;
        }
        if (value instanceof Collection) {
            return ((Collection<?>) value).size();
        }
        if (value instanceof Map) {
            return ((Map<?, ?>) value).size();
        }
        if (value.getClass().isArray()) {
            return Array.getLength(value);
        }
        return -1;
    }
}

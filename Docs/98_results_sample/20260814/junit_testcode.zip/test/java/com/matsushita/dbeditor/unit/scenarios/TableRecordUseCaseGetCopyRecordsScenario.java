package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableRecordUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableRecordUseCase#getCopyRecords.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableRecordUseCaseGetCopyRecordsScenario {

    @Test
    @DisplayName("UTAPI-013439")
    void case_UTAPI_013439() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013439",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013439", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013439", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013439", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013439")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013440")
    void case_UTAPI_013440() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013440",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013440", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013440", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013440", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013440")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013441")
    void case_UTAPI_013441() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013441",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013441", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013441", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013441", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013441")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013442")
    void case_UTAPI_013442() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013442",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013442", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013442", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013442", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013442")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013443")
    void case_UTAPI_013443() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013443",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013443", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013443", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013443", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013443")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013444")
    void case_UTAPI_013444() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013444",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013444", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013444", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013444", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013444")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013445")
    void case_UTAPI_013445() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013445",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013445", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013445", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013445", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013445")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013446")
    void case_UTAPI_013446() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013446",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013446", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013446", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013446", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013446")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013447")
    void case_UTAPI_013447() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013447",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013447", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013447", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013447", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013447")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013448")
    void case_UTAPI_013448() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013448",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013448", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013448", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013448", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013448")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013449")
    void case_UTAPI_013449() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013449",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013449", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013449", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013449", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013449")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013450")
    void case_UTAPI_013450() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013450",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013450", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013450", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013450", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013450")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013451")
    void case_UTAPI_013451() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013451",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013451", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013451", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013451", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013451")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013452")
    void case_UTAPI_013452() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013452",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013452", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013452", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013452", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013452")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013453")
    void case_UTAPI_013453() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013453",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013453", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013453", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013453", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013453")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013454")
    void case_UTAPI_013454() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013454",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013454", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013454", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013454", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013454")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013455")
    void case_UTAPI_013455() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013455",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013455", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013455", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013455", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013455")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013456")
    void case_UTAPI_013456() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013456",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013456", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013456", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013456", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013456")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013457")
    void case_UTAPI_013457() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013457",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013457", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013457", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013457", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013457")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013458")
    void case_UTAPI_013458() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013458",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013458", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013458", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013458", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013458")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013459")
    void case_UTAPI_013459() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013459",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013459", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013459", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013459", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013459")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013460")
    void case_UTAPI_013460() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013460",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013460", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013460", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013460", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013460")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013461")
    void case_UTAPI_013461() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013461",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013461", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013461", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013461", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013461")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013462")
    void case_UTAPI_013462() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013462",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013462", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013462", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013462", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013462")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013463")
    void case_UTAPI_013463() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013463",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013463", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013463", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013463", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013463")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013464")
    void case_UTAPI_013464() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013464",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013464", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013464", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013464", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013464")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013465")
    void case_UTAPI_013465() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013465",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013465", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013465", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013465", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013465")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013466")
    void case_UTAPI_013466() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013466",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013466", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013466", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013466", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013466")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013467")
    void case_UTAPI_013467() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013467",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013467", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013467", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013467", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013467")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013468")
    void case_UTAPI_013468() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013468",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013468", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013468", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013468", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013468")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013469")
    void case_UTAPI_013469() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013469",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013469", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013469", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013469", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013469")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013470")
    void case_UTAPI_013470() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013470",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013470", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013470", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013470", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013470")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013471")
    void case_UTAPI_013471() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013471",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013471", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013471", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013471", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013471")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013472")
    void case_UTAPI_013472() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013472",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013472", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013472", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013472", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013472")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013473")
    void case_UTAPI_013473() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013473",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013473", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013473", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013473", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013473")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013474")
    void case_UTAPI_013474() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013474",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013474", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013474", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013474", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013474")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013475")
    void case_UTAPI_013475() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013475",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013475", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013475", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013475", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013475")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013476")
    void case_UTAPI_013476() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013476",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013476", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013476", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013476", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013476")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013477")
    void case_UTAPI_013477() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013477",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013477", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013477", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013477", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013477")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013478")
    void case_UTAPI_013478() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013478",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013478", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013478", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013478", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013478")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013479")
    void case_UTAPI_013479() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013479",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013479", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013479", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013479", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013479")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013480")
    void case_UTAPI_013480() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013480",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013480", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013480", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013480", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013480")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013481")
    void case_UTAPI_013481() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013481",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013481", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013481", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013481", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013481")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013482")
    void case_UTAPI_013482() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013482",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013482", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013482", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013482", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013482")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013483")
    void case_UTAPI_013483() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013483",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013483", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013483", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013483", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013483")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013484")
    void case_UTAPI_013484() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013484",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013484", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013484", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013484", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013484")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013485")
    void case_UTAPI_013485() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013485",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013485", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013485", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013485", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013485")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013486")
    void case_UTAPI_013486() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013486",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013486", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013486", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013486", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013486")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013487")
    void case_UTAPI_013487() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013487",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013487", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013487", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013487", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013487")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013488")
    void case_UTAPI_013488() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013488",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013488", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013488", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013488", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013488")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013489")
    void case_UTAPI_013489() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013489",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013489", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013489", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013489", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013489")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013490")
    void case_UTAPI_013490() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013490",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013490", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013490", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013490", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013490")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013491")
    void case_UTAPI_013491() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013491",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013491", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013491", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013491", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013491")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllCopyRecords must carry the value generated for tableName", "tableRecordRepository", "findAllCopyRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllCopyRecords", "tableRecordRepository", "findAllCopyRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

}

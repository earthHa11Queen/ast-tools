package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ConnectionSettingResponseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ConnectionSettingResponse#fromEntity.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ConnectionSettingResponseFromEntityScenario {

    @Test
    @DisplayName("UTAPI-010112")
    void case_UTAPI_010112() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010112",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010112", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010112", "entity.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010112", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010112", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010112", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010112", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010112", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010112", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010112", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010112", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010112")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("entity.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010113")
    void case_UTAPI_010113() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010113",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010113", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010113", "entity.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010113", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010113", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010113", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010113", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010113", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010113", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010113", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010113", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010113")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("entity.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010114")
    void case_UTAPI_010114() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010114",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010114", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010114", "entity.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010114", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010114", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010114", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010114", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010114", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010114", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010114", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010114", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010114")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("entity.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010115")
    void case_UTAPI_010115() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010115",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010115", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010115", "entity.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010115", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010115", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010115", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010115", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010115", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010115", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010115", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010115", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010115")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("entity.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010116")
    void case_UTAPI_010116() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010116",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010116", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010116", "entity.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010116", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010116", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010116", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010116", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010116", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010116", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010116", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010116", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010116")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("entity.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010117")
    void case_UTAPI_010117() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010117",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010117", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010117", "entity.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010117", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010117", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010117", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010117", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010117", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010117", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010117", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010117", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010117")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("entity.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010118")
    void case_UTAPI_010118() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010118",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010118", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010118", "entity.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010118", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010118", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010118", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010118", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010118", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010118", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010118", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010118", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010118")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("entity.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010119")
    void case_UTAPI_010119() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010119",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010119", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010119", "entity.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010119", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010119", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010119", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010119", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010119", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010119", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010119", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010119", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010119")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("entity.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010120")
    void case_UTAPI_010120() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010120",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010120", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010120", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010120", "entity.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010120", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010120", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010120", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010120", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010120", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010120", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010120", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010120")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("entity.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.databaseName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010121")
    void case_UTAPI_010121() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010121",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010121", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010121", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010121", "entity.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010121", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010121", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010121", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010121", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010121", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010121", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010121", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010121")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("entity.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.databaseName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010122")
    void case_UTAPI_010122() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010122",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010122", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010122", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010122", "entity.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010122", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010122", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010122", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010122", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010122", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010122", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010122", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010122")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("entity.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.databaseName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010123")
    void case_UTAPI_010123() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010123",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010123", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010123", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010123", "entity.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010123", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010123", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010123", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010123", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010123", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010123", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010123", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010123")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("entity.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.databaseName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010124")
    void case_UTAPI_010124() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010124",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010124", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010124", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010124", "entity.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010124", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010124", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010124", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010124", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010124", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010124", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010124", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010124")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("entity.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.databaseName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010125")
    void case_UTAPI_010125() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010125",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010125", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010125", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010125", "entity.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010125", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010125", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010125", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010125", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010125", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010125", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010125", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010125")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("entity.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.databaseName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010126")
    void case_UTAPI_010126() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010126",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010126", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010126", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010126", "entity.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010126", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010126", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010126", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010126", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010126", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010126", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010126", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010126")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("entity.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.databaseName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010127")
    void case_UTAPI_010127() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010127",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010127", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010127", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010127", "entity.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010127", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010127", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010127", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010127", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010127", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010127", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010127", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010127")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("entity.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.databaseName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010128")
    void case_UTAPI_010128() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010128",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010128", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010128", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010128", "entity.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010128", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010128", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010128", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010128", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010128", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010128", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010128", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010128")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("entity.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.databaseName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010129")
    void case_UTAPI_010129() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010129",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010129", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010129", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010129", "entity.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010129", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010129", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010129", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010129", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010129", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010129", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010129", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010129")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("entity.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.databaseName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010130")
    void case_UTAPI_010130() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010130",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010130", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010130", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010130", "entity.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010130", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010130", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010130", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010130", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010130", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010130", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010130", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010130")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("entity.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.databaseName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010131")
    void case_UTAPI_010131() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010131",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010131", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010131", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010131", "entity.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010131", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010131", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010131", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010131", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010131", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010131", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010131", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010131")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("entity.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.databaseName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010132")
    void case_UTAPI_010132() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010132",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010132", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010132", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010132", "entity.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010132", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010132", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010132", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010132", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010132", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010132", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010132", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010132")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("entity.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.databaseName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010133")
    void case_UTAPI_010133() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010133",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010133", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010133", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010133", "entity.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010133", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010133", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010133", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010133", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010133", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010133", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010133", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010133")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("entity.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.databaseName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010134")
    void case_UTAPI_010134() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010134",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010134", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010134", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010134", "entity.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010134", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010134", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010134", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010134", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010134", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010134", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010134", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010134")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("entity.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.databaseName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010135")
    void case_UTAPI_010135() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010135",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010135", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010135", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010135", "entity.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010135", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010135", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010135", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010135", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010135", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010135", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010135", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010135")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("entity.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.databaseName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010136")
    void case_UTAPI_010136() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010136",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010136", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010136", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010136", "entity.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010136", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010136", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010136", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010136", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010136", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010136", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010136", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010136")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("entity.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.databaseName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010137")
    void case_UTAPI_010137() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010137",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010137", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010137", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010137", "entity.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010137", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010137", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010137", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010137", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010137", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010137", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010137", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010137")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("entity.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.databaseName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010138")
    void case_UTAPI_010138() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010138",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010138", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010138", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010138", "entity.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010138", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010138", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010138", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010138", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010138", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010138", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010138", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010138")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("entity.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.databaseName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010139")
    void case_UTAPI_010139() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010139",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010139", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010139", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010139", "entity.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010139", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010139", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010139", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010139", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010139", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010139", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010139", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010139")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("entity.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.databaseName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010140")
    void case_UTAPI_010140() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010140",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010140", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010140", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010140", "entity.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010140", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010140", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010140", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010140", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010140", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010140", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010140", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010140")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("entity.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.databaseName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010141")
    void case_UTAPI_010141() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010141",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010141", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010141", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010141", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010141", "entity.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010141", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010141", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010141", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010141", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010141", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010141", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010141")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("entity.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbHost survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010142")
    void case_UTAPI_010142() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010142",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010142", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010142", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010142", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010142", "entity.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010142", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010142", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010142", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010142", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010142", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010142", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010142")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("entity.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbHost survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010143")
    void case_UTAPI_010143() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010143",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010143", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010143", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010143", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010143", "entity.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010143", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010143", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010143", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010143", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010143", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010143", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010143")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("entity.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbHost survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010144")
    void case_UTAPI_010144() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010144",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010144", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010144", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010144", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010144", "entity.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010144", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010144", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010144", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010144", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010144", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010144", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010144")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("entity.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbHost survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010145")
    void case_UTAPI_010145() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010145",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010145", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010145", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010145", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010145", "entity.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010145", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010145", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010145", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010145", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010145", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010145", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010145")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("entity.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbHost survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010146")
    void case_UTAPI_010146() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010146",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010146", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010146", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010146", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010146", "entity.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010146", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010146", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010146", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010146", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010146", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010146", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010146")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("entity.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbHost survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010147")
    void case_UTAPI_010147() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010147",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010147", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010147", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010147", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010147", "entity.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010147", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010147", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010147", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010147", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010147", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010147", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010147")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("entity.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbHost survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010148")
    void case_UTAPI_010148() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010148",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010148", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010148", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010148", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010148", "entity.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010148", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010148", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010148", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010148", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010148", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010148", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010148")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("entity.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbHost survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010149")
    void case_UTAPI_010149() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010149",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010149", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010149", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010149", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010149", "entity.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010149", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010149", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010149", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010149", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010149", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010149", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010149")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("entity.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbHost survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010150")
    void case_UTAPI_010150() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010150",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010150", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010150", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010150", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010150", "entity.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010150", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010150", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010150", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010150", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010150", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010150", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010150")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("entity.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbHost survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010151")
    void case_UTAPI_010151() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010151",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010151", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010151", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010151", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010151", "entity.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010151", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010151", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010151", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010151", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010151", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010151", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010151")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("entity.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbHost survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010152")
    void case_UTAPI_010152() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010152",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010152", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010152", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010152", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010152", "entity.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010152", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010152", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010152", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010152", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010152", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010152", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010152")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("entity.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbHost survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010153")
    void case_UTAPI_010153() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010153",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010153", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010153", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010153", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010153", "entity.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010153", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010153", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010153", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010153", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010153", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010153", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010153")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("entity.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbHost survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010154")
    void case_UTAPI_010154() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010154",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010154", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010154", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010154", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010154", "entity.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010154", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010154", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010154", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010154", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010154", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010154", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010154")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("entity.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbHost survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010155")
    void case_UTAPI_010155() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010155",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010155", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010155", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010155", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010155", "entity.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010155", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010155", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010155", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010155", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010155", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010155", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010155")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("entity.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbHost survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010156")
    void case_UTAPI_010156() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010156",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010156", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010156", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010156", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010156", "entity.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010156", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010156", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010156", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010156", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010156", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010156", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010156")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("entity.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbHost survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010157")
    void case_UTAPI_010157() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010157",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010157", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010157", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010157", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010157", "entity.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010157", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010157", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010157", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010157", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010157", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010157", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010157")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("entity.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbHost survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010158")
    void case_UTAPI_010158() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010158",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010158", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010158", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010158", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010158", "entity.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010158", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010158", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010158", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010158", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010158", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010158", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010158")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("entity.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbHost survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010159")
    void case_UTAPI_010159() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010159",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010159", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010159", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010159", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010159", "entity.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010159", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010159", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010159", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010159", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010159", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010159", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010159")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("entity.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbHost survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010160")
    void case_UTAPI_010160() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010160",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010160", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010160", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010160", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010160", "entity.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010160", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010160", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010160", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010160", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010160", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010160", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010160")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("entity.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbHost survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010161")
    void case_UTAPI_010161() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010161",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010161", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010161", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010161", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010161", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010161", "entity.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010161", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010161", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010161", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010161", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010161", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010161")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("entity.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010162")
    void case_UTAPI_010162() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010162",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010162", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010162", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010162", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010162", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010162", "entity.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010162", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010162", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010162", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010162", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010162", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010162")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("entity.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010163")
    void case_UTAPI_010163() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010163",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010163", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010163", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010163", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010163", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010163", "entity.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010163", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010163", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010163", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010163", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010163", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010163")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("entity.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010164")
    void case_UTAPI_010164() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010164",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010164", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010164", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010164", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010164", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010164", "entity.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010164", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010164", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010164", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010164", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010164", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010164")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("entity.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010165")
    void case_UTAPI_010165() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010165",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010165", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010165", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010165", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010165", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010165", "entity.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010165", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010165", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010165", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010165", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010165", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010165")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("entity.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010166")
    void case_UTAPI_010166() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010166",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010166", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010166", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010166", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010166", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010166", "entity.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010166", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010166", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010166", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010166", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010166", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010166")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("entity.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010167")
    void case_UTAPI_010167() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010167",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010167", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010167", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010167", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010167", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010167", "entity.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010167", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010167", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010167", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010167", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010167", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010167")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("entity.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010168")
    void case_UTAPI_010168() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010168",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010168", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010168", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010168", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010168", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010168", "entity.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010168", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010168", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010168", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010168", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010168", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010168")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("entity.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010169")
    void case_UTAPI_010169() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010169",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010169", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010169", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010169", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010169", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010169", "entity.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010169", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010169", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010169", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010169", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010169", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010169")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("entity.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010170")
    void case_UTAPI_010170() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010170",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010170", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010170", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010170", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010170", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010170", "entity.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010170", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010170", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010170", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010170", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010170", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010170")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("entity.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010171")
    void case_UTAPI_010171() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010171",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010171", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010171", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010171", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010171", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010171", "entity.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010171", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010171", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010171", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010171", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010171", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010171")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("entity.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010172")
    void case_UTAPI_010172() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010172",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010172", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010172", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010172", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010172", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010172", "entity.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010172", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010172", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010172", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010172", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010172", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010172")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("entity.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010173")
    void case_UTAPI_010173() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010173",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010173", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010173", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010173", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010173", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010173", "entity.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010173", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010173", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010173", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010173", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010173", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010173")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("entity.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010174")
    void case_UTAPI_010174() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010174",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010174", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010174", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010174", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010174", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010174", "entity.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010174", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010174", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010174", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010174", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010174", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010174")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("entity.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010175")
    void case_UTAPI_010175() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010175",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010175", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010175", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010175", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010175", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010175", "entity.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010175", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010175", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010175", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010175", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010175", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010175")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("entity.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010176")
    void case_UTAPI_010176() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010176",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010176", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010176", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010176", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010176", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010176", "entity.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010176", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010176", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010176", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010176", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010176", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010176")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("entity.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010177")
    void case_UTAPI_010177() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010177",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010177", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010177", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010177", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010177", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010177", "entity.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010177", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010177", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010177", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010177", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010177", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010177")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("entity.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010178")
    void case_UTAPI_010178() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010178",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010178", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010178", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010178", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010178", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010178", "entity.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010178", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010178", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010178", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010178", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010178", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010178")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("entity.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010179")
    void case_UTAPI_010179() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010179",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010179", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010179", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010179", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010179", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010179", "entity.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010179", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010179", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010179", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010179", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010179", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010179")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("entity.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010180")
    void case_UTAPI_010180() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010180",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010180", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010180", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010180", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010180", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010180", "entity.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010180", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010180", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010180", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010180", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010180", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010180")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("entity.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010181")
    void case_UTAPI_010181() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010181",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010181", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010181", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010181", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010181", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010181", "entity.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010181", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010181", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010181", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010181", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010181", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010181")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("entity.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010182")
    void case_UTAPI_010182() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010182",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010182", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010182", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010182", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010182", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010182", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010182", "entity.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010182", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010182", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010182", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010182", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010182")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("entity.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPassword survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose dbPassword", "getDbPassword")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010183")
    void case_UTAPI_010183() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010183",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010183", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010183", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010183", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010183", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010183", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010183", "entity.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010183", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010183", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010183", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010183", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010183")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("entity.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPassword survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose dbPassword", "getDbPassword")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010184")
    void case_UTAPI_010184() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010184",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010184", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010184", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010184", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010184", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010184", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010184", "entity.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010184", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010184", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010184", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010184", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010184")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("entity.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPassword survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose dbPassword", "getDbPassword")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010185")
    void case_UTAPI_010185() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010185",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010185", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010185", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010185", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010185", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010185", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010185", "entity.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010185", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010185", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010185", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010185", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010185")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("entity.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPassword survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose dbPassword", "getDbPassword")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010186")
    void case_UTAPI_010186() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010186",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010186", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010186", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010186", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010186", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010186", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010186", "entity.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010186", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010186", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010186", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010186", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010186")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("entity.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPassword survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose dbPassword", "getDbPassword")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010187")
    void case_UTAPI_010187() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010187",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010187", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010187", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010187", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010187", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010187", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010187", "entity.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010187", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010187", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010187", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010187", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010187")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("entity.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPassword survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose dbPassword", "getDbPassword")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010188")
    void case_UTAPI_010188() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010188",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010188", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010188", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010188", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010188", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010188", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010188", "entity.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010188", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010188", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010188", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010188", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010188")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("entity.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPassword survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose dbPassword", "getDbPassword")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010189")
    void case_UTAPI_010189() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010189",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010189", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010189", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010189", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010189", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010189", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010189", "entity.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010189", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010189", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010189", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010189", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010189")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("entity.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPassword survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose dbPassword", "getDbPassword")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010190")
    void case_UTAPI_010190() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010190",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010190", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010190", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010190", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010190", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010190", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010190", "entity.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010190", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010190", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010190", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010190", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010190")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("entity.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPassword survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose dbPassword", "getDbPassword")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010191")
    void case_UTAPI_010191() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010191",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010191", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010191", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010191", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010191", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010191", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010191", "entity.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010191", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010191", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010191", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010191", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010191")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("entity.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPassword survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose dbPassword", "getDbPassword")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010192")
    void case_UTAPI_010192() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010192",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010192", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010192", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010192", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010192", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010192", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010192", "entity.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010192", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010192", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010192", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010192", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010192")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("entity.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPassword survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose dbPassword", "getDbPassword")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010193")
    void case_UTAPI_010193() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010193",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010193", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010193", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010193", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010193", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010193", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010193", "entity.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010193", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010193", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010193", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010193", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010193")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("entity.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPassword survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose dbPassword", "getDbPassword")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010194")
    void case_UTAPI_010194() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010194",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010194", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010194", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010194", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010194", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010194", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010194", "entity.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010194", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010194", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010194", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010194", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010194")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("entity.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPassword survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose dbPassword", "getDbPassword")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010195")
    void case_UTAPI_010195() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010195",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010195", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010195", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010195", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010195", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010195", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010195", "entity.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010195", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010195", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010195", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010195", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010195")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("entity.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPassword survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose dbPassword", "getDbPassword")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010196")
    void case_UTAPI_010196() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010196",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010196", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010196", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010196", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010196", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010196", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010196", "entity.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010196", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010196", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010196", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010196", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010196")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("entity.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPassword survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose dbPassword", "getDbPassword")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010197")
    void case_UTAPI_010197() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010197",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010197", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010197", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010197", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010197", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010197", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010197", "entity.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010197", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010197", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010197", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010197", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010197")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("entity.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPassword survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose dbPassword", "getDbPassword")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010198")
    void case_UTAPI_010198() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010198",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010198", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010198", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010198", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010198", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010198", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010198", "entity.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010198", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010198", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010198", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010198", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010198")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("entity.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPassword survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose dbPassword", "getDbPassword")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010199")
    void case_UTAPI_010199() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010199",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010199", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010199", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010199", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010199", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010199", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010199", "entity.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010199", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010199", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010199", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010199", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010199")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("entity.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPassword survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose dbPassword", "getDbPassword")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010200")
    void case_UTAPI_010200() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010200",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010200", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010200", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010200", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010200", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010200", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010200", "entity.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010200", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010200", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010200", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010200", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010200")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("entity.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPassword survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose dbPassword", "getDbPassword")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010201")
    void case_UTAPI_010201() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010201",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010201", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010201", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010201", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010201", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010201", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010201", "entity.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010201", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010201", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010201", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010201", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010201")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("entity.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPassword survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose dbPassword", "getDbPassword")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010202")
    void case_UTAPI_010202() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010202",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010202", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010202", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010202", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010202", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010202", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010202", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010202", "entity.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010202", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010202", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010202", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010202")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("entity.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPort survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010203")
    void case_UTAPI_010203() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010203",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010203", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010203", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010203", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010203", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010203", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010203", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010203", "entity.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010203", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010203", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010203", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010203")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("entity.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPort survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010204")
    void case_UTAPI_010204() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010204",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010204", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010204", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010204", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010204", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010204", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010204", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010204", "entity.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010204", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010204", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010204", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010204")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("entity.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPort survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010205")
    void case_UTAPI_010205() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010205",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010205", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010205", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010205", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010205", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010205", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010205", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010205", "entity.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010205", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010205", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010205", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010205")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("entity.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPort survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010206")
    void case_UTAPI_010206() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010206",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010206", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010206", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010206", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010206", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010206", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010206", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010206", "entity.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010206", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010206", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010206", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010206")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("entity.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPort survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010207")
    void case_UTAPI_010207() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010207",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010207", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010207", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010207", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010207", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010207", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010207", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010207", "entity.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010207", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010207", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010207", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010207")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("entity.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPort survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010208")
    void case_UTAPI_010208() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010208",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010208", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010208", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010208", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010208", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010208", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010208", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010208", "entity.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010208", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010208", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010208", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010208")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("entity.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPort survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010209")
    void case_UTAPI_010209() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010209",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010209", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010209", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010209", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010209", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010209", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010209", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010209", "entity.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010209", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010209", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010209", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010209")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("entity.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPort survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010210")
    void case_UTAPI_010210() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010210",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010210", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010210", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010210", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010210", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010210", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010210", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010210", "entity.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010210", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010210", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010210", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010210")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("entity.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPort survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010211")
    void case_UTAPI_010211() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010211",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010211", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010211", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010211", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010211", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010211", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010211", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010211", "entity.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010211", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010211", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010211", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010211")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("entity.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPort survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010212")
    void case_UTAPI_010212() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010212",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010212", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010212", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010212", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010212", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010212", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010212", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010212", "entity.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010212", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010212", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010212", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010212")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("entity.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbPort survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010213")
    void case_UTAPI_010213() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010213",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010213", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010213", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010213", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010213", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010213", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010213", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010213", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010213", "entity.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010213", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010213", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010213")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("entity.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbUsername survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010214")
    void case_UTAPI_010214() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010214",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010214", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010214", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010214", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010214", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010214", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010214", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010214", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010214", "entity.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010214", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010214", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010214")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("entity.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbUsername survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010215")
    void case_UTAPI_010215() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010215",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010215", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010215", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010215", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010215", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010215", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010215", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010215", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010215", "entity.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010215", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010215", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010215")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("entity.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbUsername survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010216")
    void case_UTAPI_010216() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010216",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010216", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010216", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010216", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010216", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010216", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010216", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010216", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010216", "entity.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010216", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010216", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010216")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("entity.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbUsername survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010217")
    void case_UTAPI_010217() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010217",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010217", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010217", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010217", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010217", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010217", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010217", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010217", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010217", "entity.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010217", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010217", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010217")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("entity.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbUsername survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010218")
    void case_UTAPI_010218() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010218",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010218", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010218", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010218", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010218", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010218", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010218", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010218", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010218", "entity.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010218", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010218", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010218")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("entity.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbUsername survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010219")
    void case_UTAPI_010219() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010219",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010219", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010219", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010219", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010219", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010219", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010219", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010219", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010219", "entity.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010219", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010219", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010219")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("entity.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbUsername survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010220")
    void case_UTAPI_010220() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010220",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010220", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010220", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010220", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010220", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010220", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010220", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010220", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010220", "entity.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010220", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010220", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010220")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("entity.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbUsername survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010221")
    void case_UTAPI_010221() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010221",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010221", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010221", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010221", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010221", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010221", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010221", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010221", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010221", "entity.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010221", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010221", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010221")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("entity.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbUsername survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010222")
    void case_UTAPI_010222() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010222",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010222", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010222", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010222", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010222", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010222", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010222", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010222", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010222", "entity.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010222", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010222", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010222")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("entity.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbUsername survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010223")
    void case_UTAPI_010223() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010223",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010223", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010223", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010223", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010223", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010223", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010223", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010223", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010223", "entity.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010223", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010223", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010223")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("entity.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbUsername survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010224")
    void case_UTAPI_010224() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010224",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010224", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010224", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010224", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010224", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010224", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010224", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010224", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010224", "entity.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010224", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010224", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010224")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("entity.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbUsername survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010225")
    void case_UTAPI_010225() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010225",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010225", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010225", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010225", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010225", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010225", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010225", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010225", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010225", "entity.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010225", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010225", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010225")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("entity.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbUsername survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010226")
    void case_UTAPI_010226() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010226",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010226", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010226", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010226", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010226", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010226", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010226", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010226", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010226", "entity.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010226", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010226", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010226")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("entity.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbUsername survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010227")
    void case_UTAPI_010227() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010227",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010227", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010227", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010227", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010227", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010227", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010227", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010227", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010227", "entity.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010227", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010227", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010227")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("entity.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbUsername survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010228")
    void case_UTAPI_010228() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010228",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010228", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010228", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010228", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010228", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010228", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010228", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010228", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010228", "entity.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010228", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010228", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010228")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("entity.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbUsername survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010229")
    void case_UTAPI_010229() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010229",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010229", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010229", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010229", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010229", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010229", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010229", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010229", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010229", "entity.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010229", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010229", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010229")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("entity.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbUsername survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010230")
    void case_UTAPI_010230() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010230",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010230", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010230", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010230", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010230", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010230", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010230", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010230", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010230", "entity.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010230", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010230", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010230")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("entity.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbUsername survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010231")
    void case_UTAPI_010231() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010231",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010231", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010231", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010231", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010231", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010231", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010231", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010231", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010231", "entity.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010231", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010231", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010231")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("entity.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbUsername survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010232")
    void case_UTAPI_010232() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010232",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010232", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010232", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010232", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010232", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010232", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010232", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010232", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010232", "entity.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010232", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010232", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010232")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("entity.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbUsername survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010233")
    void case_UTAPI_010233() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010233",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010233", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010233", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010233", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010233", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010233", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010233", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010233", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010233", "entity.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010233", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010233", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010233")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("entity.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.dbUsername survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010234")
    void case_UTAPI_010234() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010234",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010234", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010234", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010234", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010234", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010234", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010234", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010234", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010234", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010234", "entity.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010234", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010234")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("entity.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010235")
    void case_UTAPI_010235() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010235",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010235", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010235", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010235", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010235", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010235", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010235", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010235", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010235", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010235", "entity.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010235", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010235")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("entity.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010236")
    void case_UTAPI_010236() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010236",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010236", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010236", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010236", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010236", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010236", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010236", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010236", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010236", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010236", "entity.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010236", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010236")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("entity.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010237")
    void case_UTAPI_010237() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010237",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010237", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010237", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010237", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010237", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010237", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010237", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010237", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010237", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010237", "entity.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010237", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010237")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("entity.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010238")
    void case_UTAPI_010238() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010238",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010238", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010238", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010238", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010238", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010238", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010238", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010238", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010238", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010238", "entity.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010238", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010238")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("entity.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010239")
    void case_UTAPI_010239() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010239",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010239", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010239", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010239", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010239", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010239", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010239", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010239", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010239", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010239", "entity.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010239", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010239")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("entity.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010240")
    void case_UTAPI_010240() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010240",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010240", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010240", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010240", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010240", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010240", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010240", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010240", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010240", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010240", "entity.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010240", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010240")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("entity.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010241")
    void case_UTAPI_010241() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010241",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010241", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010241", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010241", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010241", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010241", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010241", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010241", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010241", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010241", "entity.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010241", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010241")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("entity.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010242")
    void case_UTAPI_010242() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010242",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010242", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010242", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010242", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010242", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010242", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010242", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010242", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010242", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010242", "entity.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010242", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010242")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("entity.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010243")
    void case_UTAPI_010243() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010243",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010243", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010243", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010243", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010243", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010243", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010243", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010243", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010243", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010243", "entity.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010243", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010243")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("entity.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010244")
    void case_UTAPI_010244() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010244",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010244", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010244", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010244", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010244", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010244", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010244", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010244", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010244", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010244", "entity.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010244", "entity.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010244")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("entity.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010245")
    void case_UTAPI_010245() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010245",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010245", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010245", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010245", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010245", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010245", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010245", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010245", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010245", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010245", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010245", "entity.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010245")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("entity.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010246")
    void case_UTAPI_010246() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010246",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010246", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010246", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010246", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010246", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010246", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010246", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010246", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010246", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010246", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010246", "entity.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010246")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("entity.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010247")
    void case_UTAPI_010247() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010247",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010247", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010247", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010247", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010247", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010247", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010247", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010247", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010247", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010247", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010247", "entity.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010247")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("entity.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010248")
    void case_UTAPI_010248() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010248",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010248", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010248", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010248", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010248", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010248", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010248", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010248", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010248", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010248", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010248", "entity.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010248")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("entity.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010249")
    void case_UTAPI_010249() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010249",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010249", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010249", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010249", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010249", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010249", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010249", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010249", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010249", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010249", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010249", "entity.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010249")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("entity.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010250")
    void case_UTAPI_010250() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010250",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010250", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010250", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010250", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010250", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010250", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010250", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010250", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010250", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010250", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010250", "entity.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010250")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("entity.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010251")
    void case_UTAPI_010251() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010251",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010251", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010251", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010251", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010251", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010251", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010251", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010251", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010251", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010251", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010251", "entity.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010251")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("entity.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010252")
    void case_UTAPI_010252() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010252",
                "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse",
                "fromEntity",
                "ConnectionSettingResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "ConnectionSetting", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010252", "entity", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010252", "entity.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010252", "entity.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010252", "entity.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010252", "entity.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010252", "entity.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010252", "entity.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010252", "entity.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010252", "entity.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010252", "entity.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010252")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/ConnectionSettingResponse.java::ConnectionSettingResponse::fromEntity::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("entity.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by ConnectionSettingResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry entity.n", "getN", "data:entity.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbName must carry entity.dbName", "getDbName", "data:entity.dbName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbHost must carry entity.dbHost", "getDbHost", "data:entity.dbHost")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbPort must carry entity.dbPort", "getDbPort", "data:entity.dbPort")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDatabaseName must carry entity.databaseName", "getDatabaseName", "data:entity.databaseName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getDbUsername must carry entity.dbUsername", "getDbUsername", "data:entity.dbUsername")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getCreatedTimestamp must carry entity.createdTimestamp", "getCreatedTimestamp", "data:entity.createdTimestamp")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getUpdatedTimestamp must carry entity.updatedTimestamp", "getUpdatedTimestamp", "data:entity.updatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new ConnectionSettingResponseWrapper());
    }

}

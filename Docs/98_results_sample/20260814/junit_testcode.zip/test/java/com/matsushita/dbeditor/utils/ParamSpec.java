package com.matsushita.dbeditor.utils;

/**
 * One declared parameter of the target method, taken from AST Method Level.
 */
public final class ParamSpec {

    private final String name;
    private final String declaredType;
    private final String dataId;

    public ParamSpec(String name, String declaredType, String dataId) {
        this.name = name;
        this.declaredType = declaredType;
        this.dataId = dataId;
    }

    public String name() {
        return name;
    }

    public String declaredType() {
        return declaredType;
    }

    /** dataId that supplies this parameter, or null when the parameter has no instruction row. */
    public String dataId() {
        return dataId;
    }

    @Override
    public String toString() {
        return declaredType + " " + name;
    }
}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableRecordUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableRecordUseCase#getConnection.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableRecordUseCaseGetConnectionScenario {

    @Test
    @DisplayName("UTAPI-013428")
    void case_UTAPI_013428() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013428",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013428", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013428")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getConnection::7::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013429")
    void case_UTAPI_013429() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013429",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013429", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013429")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getConnection::7::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013430")
    void case_UTAPI_013430() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013430",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013430", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013430")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getConnection::7::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013431")
    void case_UTAPI_013431() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013431",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013431", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013431")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getConnection::7::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013432")
    void case_UTAPI_013432() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013432",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013432", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013432")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getConnection::7::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013433")
    void case_UTAPI_013433() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013433",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013433", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013433")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getConnection::7::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013434")
    void case_UTAPI_013434() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013434",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013434", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013434")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getConnection::7::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013435")
    void case_UTAPI_013435() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013435",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013435", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013435")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getConnection::7::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013436")
    void case_UTAPI_013436() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013436",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013436", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013436")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getConnection::7::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013437")
    void case_UTAPI_013437() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013437",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013437", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013437")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getConnection::7::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013438")
    void case_UTAPI_013438() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013438",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013438", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013438")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getConnection::7::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

}

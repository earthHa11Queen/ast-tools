package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.WebConfigWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for WebConfig#addCorsMappings.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class WebConfigAddCorsMappingsScenario {

    @Test
    @DisplayName("UTAPI-010743")
    void case_UTAPI_010743() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010743",
                "com.matsushita.dbeditor.infrastructure.config.WebConfig",
                "addCorsMappings",
                "void",
                new ParamSpec[] {
                    new ParamSpec("registry", "CorsRegistry", "registry")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010743", "registry", "TARGET", "OBJECT", "CorsRegistry")
                },
                OraclePlan.builder("UTAPI-010743")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/config/WebConfig.java::WebConfig::addCorsMappings::1::ARG::1::-::registry")
                    .mirror("-", "1:length_null", "-")
                    .target("registry", "registry")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.CORS_REGISTRATION)
                    .observation("the outcome of addCorsMappings for a missing registry")
                    .expected("the configuration fails instead of silently skipping the CORS registration")
                    .failure("the method returns normally, leaving the application without the declared CORS rules")
                    .assertion("assertThrows for the missing registry")
                    .check(CheckType.EXCEPTION_REQUIRED, "CORS rules cannot be registered on a missing registry", "java.lang.RuntimeException", "data:registry")
                    .build()),
            new WebConfigWrapper());
    }

    @Test
    @DisplayName("UTAPI-010744")
    void case_UTAPI_010744() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010744",
                "com.matsushita.dbeditor.infrastructure.config.WebConfig",
                "addCorsMappings",
                "void",
                new ParamSpec[] {
                    new ParamSpec("registry", "CorsRegistry", "registry")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010744", "registry", "TARGET", "OBJECT", "CorsRegistry")
                },
                OraclePlan.builder("UTAPI-010744")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/config/WebConfig.java::WebConfig::addCorsMappings::1::ARG::1::-::registry")
                    .mirror("-", "2:length_empty", "-")
                    .target("registry", "registry")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.CORS_REGISTRATION)
                    .observation("the interactions with the supplied CorsRegistry")
                    .expected("addMapping is called on the supplied registry")
                    .failure("no mapping is registered, so the declared CORS policy is never applied")
                    .assertion("verify(registry).addMapping(...)")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the configuration must register at least one mapping on the supplied registry", "CorsRegistry", "addMapping", "data:registry")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the registered mapping must address a request path", "CorsRegistry", "addMapping", "0", "text:/")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the registered mapping must be configured, not left at its defaults", "CorsRegistration", "")
                    .check(CheckType.NO_EXCEPTION, "the registration must complete")
                    .build()),
            new WebConfigWrapper());
    }

}

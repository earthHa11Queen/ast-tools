package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SqlControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SqlController#listSql.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SqlControllerListSqlScenario {

    @Test
    @DisplayName("UTAPI-001035")
    void case_UTAPI_001035() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001035",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "listSql",
                "ResponseEntity<List<SqlResponse>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001035", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001035")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::listSql::1::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.listSql")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.listSql", "sqlUseCase", "listSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.listSql must carry the value generated for connectionId", "sqlUseCase", "listSql", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001036")
    void case_UTAPI_001036() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001036",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "listSql",
                "ResponseEntity<List<SqlResponse>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001036", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001036")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::listSql::1::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.listSql")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.listSql", "sqlUseCase", "listSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.listSql must carry the value generated for connectionId", "sqlUseCase", "listSql", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001037")
    void case_UTAPI_001037() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001037",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "listSql",
                "ResponseEntity<List<SqlResponse>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001037", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001037")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::listSql::1::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.listSql")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.listSql", "sqlUseCase", "listSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.listSql must carry the value generated for connectionId", "sqlUseCase", "listSql", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001038")
    void case_UTAPI_001038() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001038",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "listSql",
                "ResponseEntity<List<SqlResponse>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001038", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001038")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::listSql::1::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.listSql")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.listSql", "sqlUseCase", "listSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.listSql must carry the value generated for connectionId", "sqlUseCase", "listSql", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001039")
    void case_UTAPI_001039() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001039",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "listSql",
                "ResponseEntity<List<SqlResponse>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001039", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001039")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::listSql::1::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.listSql")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.listSql", "sqlUseCase", "listSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.listSql must carry the value generated for connectionId", "sqlUseCase", "listSql", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001040")
    void case_UTAPI_001040() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001040",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "listSql",
                "ResponseEntity<List<SqlResponse>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001040", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001040")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::listSql::1::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.listSql")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.listSql", "sqlUseCase", "listSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.listSql must carry the value generated for connectionId", "sqlUseCase", "listSql", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001041")
    void case_UTAPI_001041() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001041",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "listSql",
                "ResponseEntity<List<SqlResponse>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001041", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001041")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::listSql::1::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.listSql")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.listSql", "sqlUseCase", "listSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.listSql must carry the value generated for connectionId", "sqlUseCase", "listSql", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001042")
    void case_UTAPI_001042() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001042",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "listSql",
                "ResponseEntity<List<SqlResponse>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001042", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001042")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::listSql::1::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.listSql")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.listSql", "sqlUseCase", "listSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.listSql must carry the value generated for connectionId", "sqlUseCase", "listSql", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001043")
    void case_UTAPI_001043() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001043",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "listSql",
                "ResponseEntity<List<SqlResponse>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001043", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001043")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::listSql::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.listSql")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.listSql", "sqlUseCase", "listSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.listSql must carry the value generated for connectionId", "sqlUseCase", "listSql", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001044")
    void case_UTAPI_001044() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001044",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "listSql",
                "ResponseEntity<List<SqlResponse>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001044", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001044")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::listSql::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.listSql")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.listSql", "sqlUseCase", "listSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.listSql must carry the value generated for connectionId", "sqlUseCase", "listSql", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001045")
    void case_UTAPI_001045() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001045",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "listSql",
                "ResponseEntity<List<SqlResponse>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001045", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001045")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::listSql::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.listSql")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.listSql", "sqlUseCase", "listSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.listSql must carry the value generated for connectionId", "sqlUseCase", "listSql", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableConflictRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableConflictRepository#calcDiff.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableConflictRepositoryCalcDiffScenario {

    @Test
    @DisplayName("UTAPI-007466")
    void case_UTAPI_007466() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007466",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007466", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007466", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007466", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007466", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007466", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007466", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007466", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007466", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007466", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007466", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007466", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007466", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007466")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007467")
    void case_UTAPI_007467() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007467",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007467", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007467", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007467", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007467", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007467", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007467", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007467", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007467", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007467", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007467", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007467", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007467", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007467")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007468")
    void case_UTAPI_007468() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007468",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007468", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007468", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007468", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007468", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007468", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007468", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007468", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007468", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007468", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007468", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007468", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007468", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007468")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007469")
    void case_UTAPI_007469() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007469",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007469", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007469", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007469", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007469", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007469", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007469", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007469", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007469", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007469", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007469", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007469", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007469", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007469")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007470")
    void case_UTAPI_007470() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007470",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007470", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007470", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007470", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007470", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007470", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007470", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007470", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007470", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007470", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007470", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007470", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007470", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007470")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007471")
    void case_UTAPI_007471() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007471",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007471", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007471", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007471", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007471", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007471", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007471", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007471", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007471", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007471", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007471", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007471", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007471", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007471")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007472")
    void case_UTAPI_007472() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007472",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007472", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007472", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007472", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007472", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007472", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007472", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007472", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007472", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007472", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007472", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007472", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007472", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007472")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007473")
    void case_UTAPI_007473() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007473",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007473", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007473", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007473", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007473", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007473", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007473", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007473", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007473", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007473", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007473", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007473", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007473", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007473")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007474")
    void case_UTAPI_007474() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007474",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007474", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007474", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007474", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007474", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007474", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007474", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007474", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007474", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007474", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007474", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007474", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007474", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007474")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007475")
    void case_UTAPI_007475() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007475",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007475", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007475", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007475", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007475", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007475", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007475", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007475", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007475", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007475", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007475", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007475", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007475", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007475")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007476")
    void case_UTAPI_007476() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007476",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007476", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007476", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007476", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007476", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007476", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007476", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007476", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007476", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007476", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007476", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007476", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007476", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007476")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007477")
    void case_UTAPI_007477() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007477",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007477", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007477", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007477", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007477", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007477", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007477", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007477", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007477", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007477", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007477", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007477", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007477", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007477")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007478")
    void case_UTAPI_007478() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007478",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007478", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007478", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007478", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007478", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007478", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007478", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007478", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007478", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007478", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007478", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007478", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007478", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007478")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007479")
    void case_UTAPI_007479() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007479",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007479", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007479", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007479", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007479", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007479", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007479", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007479", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007479", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007479", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007479", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007479", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007479", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007479")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007480")
    void case_UTAPI_007480() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007480",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007480", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007480", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007480", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007480", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007480", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007480", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007480", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007480", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007480", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007480", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007480", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007480", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007480")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007481")
    void case_UTAPI_007481() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007481",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007481", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007481", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007481", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007481", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007481", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007481", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007481", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007481", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007481", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007481", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007481", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007481", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007481")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007482")
    void case_UTAPI_007482() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007482",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007482", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007482", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007482", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007482", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007482", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007482", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007482", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007482", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007482", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007482", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007482", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007482", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007482")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007483")
    void case_UTAPI_007483() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007483",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007483", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007483", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007483", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007483", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007483", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007483", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007483", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007483", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007483", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007483", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007483", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007483", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007483")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007484")
    void case_UTAPI_007484() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007484",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007484", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007484", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007484", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007484", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007484", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007484", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007484", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007484", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007484", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007484", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007484", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007484", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007484")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007485")
    void case_UTAPI_007485() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007485",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007485", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007485", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007485", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007485", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007485", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007485", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007485", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007485", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007485", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007485", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007485", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007485", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007485")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007486")
    void case_UTAPI_007486() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007486",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007486", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007486", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007486", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007486", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007486", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007486", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007486", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007486", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007486", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007486", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007486", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007486", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007486")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007487")
    void case_UTAPI_007487() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007487",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007487", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007487", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007487", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007487", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007487", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007487", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007487", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007487", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007487", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007487", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007487", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007487", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007487")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007488")
    void case_UTAPI_007488() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007488",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007488", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007488", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007488", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007488", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007488", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007488", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007488", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007488", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007488", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007488", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007488", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007488", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007488")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007489")
    void case_UTAPI_007489() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007489",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007489", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007489", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007489", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007489", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007489", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007489", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007489", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007489", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007489", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007489", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007489", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007489", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007489")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007490")
    void case_UTAPI_007490() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007490",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007490", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007490", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007490", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007490", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007490", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007490", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007490", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007490", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007490", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007490", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007490", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007490", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007490")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007491")
    void case_UTAPI_007491() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007491",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007491", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007491", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007491", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007491", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007491", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007491", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007491", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007491", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007491", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007491", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007491", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007491", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007491")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007492")
    void case_UTAPI_007492() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007492",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007492", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007492", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007492", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007492", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007492", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007492", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007492", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007492", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007492", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007492", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007492", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007492", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007492")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007493")
    void case_UTAPI_007493() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007493",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007493", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007493", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007493", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007493", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007493", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007493", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007493", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007493", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007493", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007493", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007493", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007493", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007493")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007494")
    void case_UTAPI_007494() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007494",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007494", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007494", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007494", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007494", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007494", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007494", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007494", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007494", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007494", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007494", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007494", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007494", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007494")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007495")
    void case_UTAPI_007495() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007495",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007495", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007495", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007495", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007495", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007495", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007495", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007495", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007495", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007495", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007495", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007495", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007495", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007495")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007496")
    void case_UTAPI_007496() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007496",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007496", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007496", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007496", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007496", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007496", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007496", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007496", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007496", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007496", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007496", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007496", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007496", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007496")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007497")
    void case_UTAPI_007497() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007497",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007497", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007497", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007497", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007497", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007497", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007497", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007497", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007497", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007497", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007497", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007497", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007497", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007497")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007498")
    void case_UTAPI_007498() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007498",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007498", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007498", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007498", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007498", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007498", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007498", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007498", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007498", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007498", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007498", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007498", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007498", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007498")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007499")
    void case_UTAPI_007499() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007499",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007499", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007499", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007499", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007499", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007499", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007499", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007499", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007499", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007499", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007499", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007499", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007499", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007499")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007500")
    void case_UTAPI_007500() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007500",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007500", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007500", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007500", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007500", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007500", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007500", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007500", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007500", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007500", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007500", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007500", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007500", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007500")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007501")
    void case_UTAPI_007501() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007501",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007501", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007501", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007501", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007501", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007501", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007501", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007501", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007501", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007501", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007501", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007501", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007501", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007501")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007502")
    void case_UTAPI_007502() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007502",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007502", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007502", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007502", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007502", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007502", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007502", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007502", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007502", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007502", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007502", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007502", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007502", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007502")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007503")
    void case_UTAPI_007503() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007503",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007503", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007503", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007503", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007503", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007503", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007503", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007503", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007503", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007503", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007503", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007503", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007503", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007503")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007504")
    void case_UTAPI_007504() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007504",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007504", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007504", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007504", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007504", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007504", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007504", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007504", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007504", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007504", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007504", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007504", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007504", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007504")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007505")
    void case_UTAPI_007505() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007505",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007505", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007505", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007505", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007505", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007505", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007505", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007505", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007505", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007505", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007505", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007505", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007505", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007505")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007506")
    void case_UTAPI_007506() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007506",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007506", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007506", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007506", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007506", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007506", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007506", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007506", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007506", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007506", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007506", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007506", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007506", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007506")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007507")
    void case_UTAPI_007507() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007507",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007507", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007507", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007507", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007507", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007507", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007507", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007507", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007507", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007507", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007507", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007507", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007507", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007507")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007508")
    void case_UTAPI_007508() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007508",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007508", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007508", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007508", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007508", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007508", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007508", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007508", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007508", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007508", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007508", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007508", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007508", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007508")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007509")
    void case_UTAPI_007509() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007509",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007509", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007509", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007509", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007509", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007509", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007509", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007509", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007509", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007509", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007509", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007509", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007509", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007509")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007510")
    void case_UTAPI_007510() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007510",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007510", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007510", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007510", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007510", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007510", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007510", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007510", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007510", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007510", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007510", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007510", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007510", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007510")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007511")
    void case_UTAPI_007511() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007511",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007511", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007511", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007511", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007511", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007511", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007511", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007511", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007511", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007511", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007511", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007511", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007511", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007511")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007512")
    void case_UTAPI_007512() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007512",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007512", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007512", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007512", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007512", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007512", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007512", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007512", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007512", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007512", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007512", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007512", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007512", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007512")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007513")
    void case_UTAPI_007513() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007513",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007513", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007513", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007513", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007513", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007513", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007513", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007513", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007513", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007513", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007513", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007513", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007513", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007513")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007514")
    void case_UTAPI_007514() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007514",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007514", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007514", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007514", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007514", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007514", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007514", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007514", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007514", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007514", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007514", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007514", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007514", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007514")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007515")
    void case_UTAPI_007515() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007515",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007515", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007515", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007515", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007515", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007515", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007515", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007515", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007515", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007515", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007515", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007515", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007515", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007515")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007516")
    void case_UTAPI_007516() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007516",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007516", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007516", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007516", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007516", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007516", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007516", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007516", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007516", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007516", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007516", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007516", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007516", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007516")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007517")
    void case_UTAPI_007517() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007517",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007517", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007517", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007517", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007517", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007517", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007517", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007517", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007517", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007517", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007517", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007517", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007517", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007517")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007518")
    void case_UTAPI_007518() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007518",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007518", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007518", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007518", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007518", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007518", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007518", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007518", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007518", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007518", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007518", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007518", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007518", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007518")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007519")
    void case_UTAPI_007519() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007519",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007519", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007519", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007519", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007519", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007519", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007519", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007519", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007519", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007519", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007519", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007519", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007519", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007519")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007520")
    void case_UTAPI_007520() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007520",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007520", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007520", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007520", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007520", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007520", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007520", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007520", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007520", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007520", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007520", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007520", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007520", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007520")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007521")
    void case_UTAPI_007521() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007521",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007521", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007521", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007521", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007521", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007521", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007521", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007521", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007521", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007521", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007521", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007521", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007521", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007521")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007522")
    void case_UTAPI_007522() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007522",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007522", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007522", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007522", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007522", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007522", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007522", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007522", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007522", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007522", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007522", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007522", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007522", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007522")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007523")
    void case_UTAPI_007523() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007523",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007523", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007523", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007523", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007523", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007523", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007523", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007523", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007523", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007523", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007523", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007523", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007523", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007523")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007524")
    void case_UTAPI_007524() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007524",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007524", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007524", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007524", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007524", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007524", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007524", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007524", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007524", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007524", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007524", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007524", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007524", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007524")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007525")
    void case_UTAPI_007525() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007525",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007525", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007525", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007525", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007525", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007525", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007525", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007525", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007525", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007525", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007525", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007525", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007525", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007525")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007526")
    void case_UTAPI_007526() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007526",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007526", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007526", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007526", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007526", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007526", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007526", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007526", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007526", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007526", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007526", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007526", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007526", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007526")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007527")
    void case_UTAPI_007527() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007527",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007527", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007527", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007527", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007527", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007527", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007527", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007527", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007527", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007527", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007527", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007527", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007527", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007527")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007528")
    void case_UTAPI_007528() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007528",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007528", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007528", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007528", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007528", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007528", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007528", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007528", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007528", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007528", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007528", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007528", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007528", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007528")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007529")
    void case_UTAPI_007529() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007529",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007529", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007529", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007529", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007529", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007529", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007529", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007529", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007529", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007529", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007529", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007529", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007529", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007529")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007530")
    void case_UTAPI_007530() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007530",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007530", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007530", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007530", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007530", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007530", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007530", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007530", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007530", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007530", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007530", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007530", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007530", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007530")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007531")
    void case_UTAPI_007531() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007531",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007531", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007531", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007531", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007531", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007531", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007531", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007531", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007531", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007531", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007531", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007531", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007531", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007531")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007532")
    void case_UTAPI_007532() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007532",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007532", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007532", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007532", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007532", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007532", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007532", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007532", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007532", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007532", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007532", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007532", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007532", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007532")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007533")
    void case_UTAPI_007533() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007533",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007533", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007533", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007533", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007533", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007533", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007533", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007533", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007533", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007533", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007533", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007533", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007533", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007533")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007534")
    void case_UTAPI_007534() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007534",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007534", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007534", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007534", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007534", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007534", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007534", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007534", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007534", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007534", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007534", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007534", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007534", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007534")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007535")
    void case_UTAPI_007535() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007535",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007535", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007535", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007535", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007535", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007535", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007535", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007535", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007535", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007535", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007535", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007535", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007535", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007535")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007536")
    void case_UTAPI_007536() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007536",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007536", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007536", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007536", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007536", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007536", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007536", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007536", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007536", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007536", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007536", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007536", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007536", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007536")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007537")
    void case_UTAPI_007537() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007537",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007537", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007537", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007537", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007537", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007537", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007537", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007537", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007537", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007537", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007537", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007537", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007537", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007537")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007538")
    void case_UTAPI_007538() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007538",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007538", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007538", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007538", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007538", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007538", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007538", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007538", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007538", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007538", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007538", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007538", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007538", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007538")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007539")
    void case_UTAPI_007539() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007539",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007539", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007539", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007539", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007539", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007539", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007539", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007539", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007539", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007539", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007539", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007539", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007539", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007539")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007540")
    void case_UTAPI_007540() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007540",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007540", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007540", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007540", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007540", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007540", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007540", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007540", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007540", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007540", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007540", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007540", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007540", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007540")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007541")
    void case_UTAPI_007541() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007541",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007541", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007541", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007541", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007541", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007541", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007541", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007541", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007541", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007541", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007541", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007541", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007541", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007541")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007542")
    void case_UTAPI_007542() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007542",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007542", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007542", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007542", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007542", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007542", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007542", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007542", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007542", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007542", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007542", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007542", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007542", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007542")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007543")
    void case_UTAPI_007543() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007543",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007543", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007543", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007543", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007543", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007543", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007543", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007543", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007543", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007543", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007543", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007543", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007543", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007543")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007544")
    void case_UTAPI_007544() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007544",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007544", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007544", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007544", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007544", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007544", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007544", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007544", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007544", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007544", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007544", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007544", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007544", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007544")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007545")
    void case_UTAPI_007545() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007545",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007545", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007545", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007545", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007545", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007545", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007545", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007545", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007545", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007545", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007545", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007545", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007545", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007545")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007546")
    void case_UTAPI_007546() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007546",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007546", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007546", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007546", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007546", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007546", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007546", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007546", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007546", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007546", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007546", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007546", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007546", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007546")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007547")
    void case_UTAPI_007547() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007547",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007547", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007547", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007547", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007547", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007547", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007547", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007547", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007547", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007547", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007547", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007547", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007547", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007547")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007548")
    void case_UTAPI_007548() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007548",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007548", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007548", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007548", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007548", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007548", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007548", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007548", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007548", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007548", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007548", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007548", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007548", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007548")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007549")
    void case_UTAPI_007549() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007549",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007549", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007549", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007549", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007549", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007549", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007549", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007549", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007549", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007549", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007549", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007549", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007549", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007549")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007550")
    void case_UTAPI_007550() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007550",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007550", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007550", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007550", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007550", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007550", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007550", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007550", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007550", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007550", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007550", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007550", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007550", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007550")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007551")
    void case_UTAPI_007551() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007551",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007551", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007551", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007551", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007551", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007551", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007551", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007551", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007551", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007551", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007551", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007551", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007551", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007551")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007552")
    void case_UTAPI_007552() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007552",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007552", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007552", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007552", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007552", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007552", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007552", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007552", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007552", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007552", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007552", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007552", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007552", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007552")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007553")
    void case_UTAPI_007553() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007553",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007553", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007553", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007553", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007553", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007553", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007553", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007553", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007553", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007553", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007553", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007553", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007553", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007553")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007554")
    void case_UTAPI_007554() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007554",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007554", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007554", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007554", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007554", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007554", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007554", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007554", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007554", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007554", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007554", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007554", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007554", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007554")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007555")
    void case_UTAPI_007555() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007555",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007555", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007555", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007555", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007555", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007555", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007555", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007555", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007555", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007555", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007555", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007555", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007555", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007555")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007556")
    void case_UTAPI_007556() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007556",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007556", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007556", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007556", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007556", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007556", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007556", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007556", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007556", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007556", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007556", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007556", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007556", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007556")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007557")
    void case_UTAPI_007557() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007557",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007557", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007557", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007557", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007557", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007557", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007557", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007557", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007557", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007557", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007557", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007557", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007557", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007557")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007558")
    void case_UTAPI_007558() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007558",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007558", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007558", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007558", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007558", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007558", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007558", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007558", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007558", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007558", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007558", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007558", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007558", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007558")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007559")
    void case_UTAPI_007559() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007559",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007559", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007559", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007559", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007559", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007559", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007559", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007559", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007559", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007559", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007559", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007559", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007559", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007559")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007560")
    void case_UTAPI_007560() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007560",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007560", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007560", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007560", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007560", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007560", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007560", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007560", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007560", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007560", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007560", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007560", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007560", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007560")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007561")
    void case_UTAPI_007561() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007561",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007561", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007561", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007561", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007561", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007561", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007561", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007561", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007561", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007561", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007561", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007561", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007561", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007561")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007562")
    void case_UTAPI_007562() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007562",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007562", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007562", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007562", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007562", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007562", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007562", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007562", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007562", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007562", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007562", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007562", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007562", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007562")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007563")
    void case_UTAPI_007563() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007563",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007563", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007563", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007563", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007563", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007563", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007563", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007563", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007563", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007563", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007563", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007563", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007563", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007563")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007564")
    void case_UTAPI_007564() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007564",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007564", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007564", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007564", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007564", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007564", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007564", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007564", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007564", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007564", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007564", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007564", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007564", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007564")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007565")
    void case_UTAPI_007565() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007565",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007565", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007565", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007565", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007565", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007565", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007565", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007565", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007565", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007565", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007565", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007565", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007565", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007565")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007566")
    void case_UTAPI_007566() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007566",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007566", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007566", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007566", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007566", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007566", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007566", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007566", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007566", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007566", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007566", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007566", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007566", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007566")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007567")
    void case_UTAPI_007567() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007567",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007567", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007567", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007567", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007567", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007567", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007567", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007567", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007567", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007567", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007567", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007567", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007567", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007567")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007568")
    void case_UTAPI_007568() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007568",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007568", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007568", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007568", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007568", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007568", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007568", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007568", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007568", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007568", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007568", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007568", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007568", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007568")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007569")
    void case_UTAPI_007569() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007569",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007569", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007569", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007569", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007569", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007569", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007569", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007569", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007569", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007569", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007569", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007569", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007569", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007569")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007570")
    void case_UTAPI_007570() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007570",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007570", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007570", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007570", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007570", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007570", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007570", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007570", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007570", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007570", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007570", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007570", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007570", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007570")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007571")
    void case_UTAPI_007571() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007571",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007571", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007571", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007571", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007571", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007571", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007571", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007571", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007571", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007571", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007571", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007571", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007571", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007571")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007572")
    void case_UTAPI_007572() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007572",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007572", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007572", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007572", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007572", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007572", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007572", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007572", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007572", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007572", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007572", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007572", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007572", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007572")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007573")
    void case_UTAPI_007573() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007573",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007573", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007573", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007573", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007573", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007573", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007573", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007573", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007573", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007573", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007573", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007573", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007573", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007573")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007574")
    void case_UTAPI_007574() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007574",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007574", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007574", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007574", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007574", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007574", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007574", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007574", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007574", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007574", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007574", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007574", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007574", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007574")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007575")
    void case_UTAPI_007575() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007575",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007575", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007575", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007575", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007575", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007575", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007575", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007575", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007575", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007575", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007575", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007575", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007575", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007575")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007576")
    void case_UTAPI_007576() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007576",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007576", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007576", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007576", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007576", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007576", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007576", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007576", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007576", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007576", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007576", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007576", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007576", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007576")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007577")
    void case_UTAPI_007577() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007577",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007577", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007577", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007577", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007577", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007577", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007577", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007577", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007577", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007577", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007577", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007577", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007577", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007577")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007578")
    void case_UTAPI_007578() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007578",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007578", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007578", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007578", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007578", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007578", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007578", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007578", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007578", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007578", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007578", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007578", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007578", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007578")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007579")
    void case_UTAPI_007579() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007579",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007579", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007579", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007579", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007579", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007579", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007579", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007579", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007579", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007579", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007579", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007579", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007579", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007579")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007580")
    void case_UTAPI_007580() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007580",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007580", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007580", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007580", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007580", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007580", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007580", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007580", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007580", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007580", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007580", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007580", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007580", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007580")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007581")
    void case_UTAPI_007581() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007581",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007581", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007581", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007581", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007581", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007581", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007581", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007581", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007581", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007581", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007581", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007581", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007581", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007581")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007582")
    void case_UTAPI_007582() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007582",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007582", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007582", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007582", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007582", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007582", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007582", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007582", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007582", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007582", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007582", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007582", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007582", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007582")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007583")
    void case_UTAPI_007583() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007583",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007583", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007583", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007583", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007583", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007583", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007583", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007583", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007583", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007583", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007583", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007583", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007583", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007583")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007584")
    void case_UTAPI_007584() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007584",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007584", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007584", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007584", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007584", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007584", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007584", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007584", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007584", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007584", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007584", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007584", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007584", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007584")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007585")
    void case_UTAPI_007585() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007585",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007585", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007585", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007585", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007585", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007585", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007585", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007585", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007585", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007585", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007585", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007585", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007585", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007585")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007586")
    void case_UTAPI_007586() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007586",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007586", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007586", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007586", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007586", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007586", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007586", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007586", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007586", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007586", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007586", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007586", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007586", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007586")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007587")
    void case_UTAPI_007587() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007587",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007587", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007587", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007587", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007587", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007587", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007587", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007587", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007587", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007587", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007587", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007587", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007587", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007587")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007588")
    void case_UTAPI_007588() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007588",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007588", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007588", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007588", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007588", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007588", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007588", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007588", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007588", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007588", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007588", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007588", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007588", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007588")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007589")
    void case_UTAPI_007589() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007589",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007589", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007589", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007589", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007589", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007589", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007589", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007589", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007589", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007589", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007589", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007589", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007589", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007589")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007590")
    void case_UTAPI_007590() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007590",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007590", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007590", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007590", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007590", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007590", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007590", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007590", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007590", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007590", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007590", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007590", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007590", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007590")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007591")
    void case_UTAPI_007591() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007591",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007591", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007591", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007591", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007591", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007591", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007591", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007591", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007591", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007591", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007591", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007591", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007591", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007591")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007592")
    void case_UTAPI_007592() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007592",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007592", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007592", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007592", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007592", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007592", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007592", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007592", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007592", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007592", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007592", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007592", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007592", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007592")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007593")
    void case_UTAPI_007593() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007593",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007593", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007593", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007593", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007593", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007593", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007593", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007593", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007593", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007593", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007593", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007593", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007593", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007593")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007594")
    void case_UTAPI_007594() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007594",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007594", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007594", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007594", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007594", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007594", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007594", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007594", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007594", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007594", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007594", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007594", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007594", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007594")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007595")
    void case_UTAPI_007595() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007595",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007595", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007595", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007595", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007595", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007595", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007595", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007595", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007595", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007595", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007595", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007595", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007595", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007595")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007596")
    void case_UTAPI_007596() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007596",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007596", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007596", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007596", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007596", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007596", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007596", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007596", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007596", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007596", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007596", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007596", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007596", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007596")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007597")
    void case_UTAPI_007597() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007597",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007597", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007597", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007597", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007597", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007597", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007597", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007597", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007597", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007597", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007597", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007597", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007597", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007597")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007598")
    void case_UTAPI_007598() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007598",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007598", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007598", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007598", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007598", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007598", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007598", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007598", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007598", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007598", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007598", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007598", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007598", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007598")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007599")
    void case_UTAPI_007599() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007599",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007599", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007599", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007599", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007599", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007599", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007599", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007599", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007599", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007599", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007599", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007599", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007599", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007599")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007600")
    void case_UTAPI_007600() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007600",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007600", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007600", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007600", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007600", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007600", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007600", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007600", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007600", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007600", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007600", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007600", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007600", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007600")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007601")
    void case_UTAPI_007601() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007601",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007601", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007601", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007601", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007601", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007601", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007601", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007601", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007601", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007601", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007601", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007601", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007601", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007601")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007602")
    void case_UTAPI_007602() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007602",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007602", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007602", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007602", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007602", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007602", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007602", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007602", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007602", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007602", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007602", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007602", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007602", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007602")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007603")
    void case_UTAPI_007603() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007603",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007603", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007603", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007603", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007603", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007603", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007603", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007603", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007603", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007603", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007603", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007603", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007603", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007603")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007604")
    void case_UTAPI_007604() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007604",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007604", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007604", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007604", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007604", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007604", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007604", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007604", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007604", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007604", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007604", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007604", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007604", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007604")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007605")
    void case_UTAPI_007605() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007605",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007605", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007605", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007605", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007605", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007605", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007605", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007605", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007605", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007605", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007605", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007605", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007605", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007605")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007606")
    void case_UTAPI_007606() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007606",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007606", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007606", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007606", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007606", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007606", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007606", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007606", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007606", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007606", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007606", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007606", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007606", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007606")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007607")
    void case_UTAPI_007607() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007607",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007607", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007607", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007607", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007607", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007607", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007607", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007607", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007607", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007607", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007607", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007607", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007607", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007607")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007608")
    void case_UTAPI_007608() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007608",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007608", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007608", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007608", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007608", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007608", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007608", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007608", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007608", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007608", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007608", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007608", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007608", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007608")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007609")
    void case_UTAPI_007609() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007609",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007609", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007609", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007609", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007609", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007609", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007609", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007609", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007609", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007609", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007609", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007609", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007609", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007609")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007610")
    void case_UTAPI_007610() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007610",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007610", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007610", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007610", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007610", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007610", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007610", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007610", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007610", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007610", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007610", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007610", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007610", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007610")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007611")
    void case_UTAPI_007611() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007611",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007611", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007611", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007611", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007611", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007611", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007611", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007611", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007611", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007611", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007611", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007611", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007611", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007611")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007612")
    void case_UTAPI_007612() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007612",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007612", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007612", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007612", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007612", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007612", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007612", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007612", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007612", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007612", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007612", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007612", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007612", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007612")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007613")
    void case_UTAPI_007613() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007613",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007613", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007613", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007613", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007613", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007613", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007613", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007613", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007613", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007613", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007613", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007613", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007613", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007613")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007614")
    void case_UTAPI_007614() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007614",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007614", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007614", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007614", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007614", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007614", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007614", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007614", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007614", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007614", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007614", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007614", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007614", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007614")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007615")
    void case_UTAPI_007615() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007615",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007615", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007615", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007615", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007615", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007615", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007615", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007615", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007615", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007615", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007615", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007615", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007615", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007615")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007616")
    void case_UTAPI_007616() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007616",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007616", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007616", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007616", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007616", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007616", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007616", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007616", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007616", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007616", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007616", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007616", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007616", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007616")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007617")
    void case_UTAPI_007617() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007617",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007617", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007617", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007617", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007617", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007617", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007617", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007617", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007617", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007617", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007617", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007617", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007617", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007617")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007618")
    void case_UTAPI_007618() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007618",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007618", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007618", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007618", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007618", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007618", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007618", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007618", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007618", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007618", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007618", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007618", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007618", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007618")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007619")
    void case_UTAPI_007619() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007619",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007619", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007619", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007619", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007619", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007619", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007619", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007619", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007619", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007619", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007619", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007619", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007619", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007619")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007620")
    void case_UTAPI_007620() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007620",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007620", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007620", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007620", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007620", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007620", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007620", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007620", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007620", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007620", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007620", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007620", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007620", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007620")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007621")
    void case_UTAPI_007621() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007621",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007621", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007621", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007621", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007621", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007621", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007621", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007621", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007621", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007621", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007621", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007621", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007621", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007621")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007622")
    void case_UTAPI_007622() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007622",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007622", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007622", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007622", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007622", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007622", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007622", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007622", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007622", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007622", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007622", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007622", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007622", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007622")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007623")
    void case_UTAPI_007623() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007623",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007623", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007623", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007623", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007623", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007623", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007623", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007623", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007623", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007623", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007623", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007623", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007623", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007623")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007624")
    void case_UTAPI_007624() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007624",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007624", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007624", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007624", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007624", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007624", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007624", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007624", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007624", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007624", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007624", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007624", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007624", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007624")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007625")
    void case_UTAPI_007625() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007625",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007625", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007625", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007625", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007625", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007625", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007625", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007625", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007625", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007625", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007625", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007625", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007625", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007625")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007626")
    void case_UTAPI_007626() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007626",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007626", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007626", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007626", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007626", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007626", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007626", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007626", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007626", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007626", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007626", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007626", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007626", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007626")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007627")
    void case_UTAPI_007627() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007627",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007627", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007627", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007627", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007627", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007627", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007627", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007627", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007627", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007627", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007627", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007627", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007627", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007627")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007628")
    void case_UTAPI_007628() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007628",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007628", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007628", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007628", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007628", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007628", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007628", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007628", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007628", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007628", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007628", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007628", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007628", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007628")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007629")
    void case_UTAPI_007629() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007629",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007629", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007629", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007629", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007629", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007629", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007629", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007629", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007629", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007629", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007629", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007629", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007629", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007629")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007630")
    void case_UTAPI_007630() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007630",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007630", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007630", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007630", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007630", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007630", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007630", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007630", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007630", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007630", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007630", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007630", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007630", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007630")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007631")
    void case_UTAPI_007631() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007631",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007631", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007631", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007631", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007631", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007631", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007631", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007631", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007631", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007631", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007631", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007631", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007631", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007631")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007632")
    void case_UTAPI_007632() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007632",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007632", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007632", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007632", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007632", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007632", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007632", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007632", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007632", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007632", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007632", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007632", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007632", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007632")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007633")
    void case_UTAPI_007633() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007633",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007633", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007633", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007633", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007633", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007633", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007633", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007633", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007633", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007633", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007633", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007633", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007633", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007633")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007634")
    void case_UTAPI_007634() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007634",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007634", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007634", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007634", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007634", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007634", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007634", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007634", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007634", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007634", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007634", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007634", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007634", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007634")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007635")
    void case_UTAPI_007635() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007635",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007635", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007635", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007635", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007635", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007635", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007635", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007635", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007635", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007635", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007635", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007635", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007635", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007635")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007636")
    void case_UTAPI_007636() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007636",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007636", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007636", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007636", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007636", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007636", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007636", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007636", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007636", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007636", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007636", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007636", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007636", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007636")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007637")
    void case_UTAPI_007637() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007637",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007637", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007637", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007637", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007637", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007637", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007637", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007637", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007637", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007637", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007637", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007637", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007637", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007637")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007638")
    void case_UTAPI_007638() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007638",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007638", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007638", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007638", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007638", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007638", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007638", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007638", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007638", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007638", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007638", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007638", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007638", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007638")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007639")
    void case_UTAPI_007639() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007639",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007639", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007639", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007639", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007639", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007639", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007639", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007639", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007639", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007639", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007639", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007639", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007639", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007639")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007640")
    void case_UTAPI_007640() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007640",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007640", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007640", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007640", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007640", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007640", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007640", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007640", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007640", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007640", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007640", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007640", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007640", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007640")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007641")
    void case_UTAPI_007641() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007641",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007641", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007641", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007641", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007641", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007641", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007641", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007641", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007641", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007641", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007641", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007641", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007641", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007641")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007642")
    void case_UTAPI_007642() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007642",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007642", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007642", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007642", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007642", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007642", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007642", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007642", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007642", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007642", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007642", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007642", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007642", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007642")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007643")
    void case_UTAPI_007643() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007643",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007643", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007643", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007643", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007643", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007643", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007643", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007643", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007643", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007643", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007643", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007643", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007643", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007643")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007644")
    void case_UTAPI_007644() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007644",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007644", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007644", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007644", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007644", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007644", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007644", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007644", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007644", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007644", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007644", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007644", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007644", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007644")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007645")
    void case_UTAPI_007645() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007645",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007645", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007645", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007645", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007645", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007645", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007645", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007645", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007645", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007645", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007645", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007645", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007645", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007645")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007646")
    void case_UTAPI_007646() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007646",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007646", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007646", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007646", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007646", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007646", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007646", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007646", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007646", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007646", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007646", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007646", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007646", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007646")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007647")
    void case_UTAPI_007647() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007647",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007647", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007647", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007647", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007647", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007647", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007647", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007647", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007647", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007647", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007647", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007647", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007647", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007647")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007648")
    void case_UTAPI_007648() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007648",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007648", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007648", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007648", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007648", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007648", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007648", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007648", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007648", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007648", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007648", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007648", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007648", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007648")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

}

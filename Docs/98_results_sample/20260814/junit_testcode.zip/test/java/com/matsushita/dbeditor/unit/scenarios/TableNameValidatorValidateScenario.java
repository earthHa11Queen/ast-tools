package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableNameValidatorWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableNameValidator#validate.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableNameValidatorValidateScenario {

    @Test
    @DisplayName("UTAPI-011041")
    void case_UTAPI_011041() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011041",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "validate",
                "String",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011041", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011041")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::validate::2::ARG::1::-::name")
                    .mirror("-", "1:length_null", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_VALIDATION)
                    .observation("the outcome of validate for an absent or empty identifier")
                    .expected("validate rejects it, as its declared null check and identifier pattern require")
                    .failure("an absent or empty identifier is accepted and returned")
                    .assertion("assertThrows(IllegalArgumentException.class, ...)")
                    .check(CheckType.EXCEPTION_REQUIRED, "an absent or empty identifier can never match the declared identifier pattern", "java.lang.IllegalArgumentException", "data:name")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011042")
    void case_UTAPI_011042() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011042",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "validate",
                "String",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011042", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011042")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::validate::2::ARG::1::-::name")
                    .mirror("-", "2:length_empty", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_VALIDATION)
                    .observation("the outcome of validate for an absent or empty identifier")
                    .expected("validate rejects it, as its declared null check and identifier pattern require")
                    .failure("an absent or empty identifier is accepted and returned")
                    .assertion("assertThrows(IllegalArgumentException.class, ...)")
                    .check(CheckType.EXCEPTION_REQUIRED, "an absent or empty identifier can never match the declared identifier pattern", "java.lang.IllegalArgumentException", "data:name")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011043")
    void case_UTAPI_011043() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011043",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "validate",
                "String",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011043", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011043")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::validate::2::ARG::1::-::name")
                    .mirror("-", "3:length_min", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_VALIDATION)
                    .observation("the return value of validate")
                    .expected("a valid identifier is accepted and returned exactly as supplied")
                    .failure("a valid identifier is rejected, or it is silently rewritten, truncated or normalised")
                    .assertion("assertEquals on the returned identifier")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted")
                    .check(CheckType.RETURN_EQUALS_VALUE, "an accepted identifier must be returned unchanged", "data:name")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011044")
    void case_UTAPI_011044() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011044",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "validate",
                "String",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011044", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011044")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::validate::2::ARG::1::-::name")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_VALIDATION)
                    .observation("the return value of validate, or the rejection it raises")
                    .expected("the identifier is either rejected as an invalid argument or returned exactly as supplied")
                    .failure("the identifier is silently rewritten, truncated or normalised while being accepted")
                    .assertion("assertEquals on the returned identifier, IllegalArgumentException on rejection")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_EQUALS_VALUE, "an accepted identifier must be returned unchanged", "data:name")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011045")
    void case_UTAPI_011045() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011045",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "validate",
                "String",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011045", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011045")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::validate::2::ARG::1::-::name")
                    .mirror("-", "5:length_max", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_VALIDATION)
                    .observation("the return value of validate")
                    .expected("a valid identifier is accepted and returned exactly as supplied")
                    .failure("a valid identifier is rejected, or it is silently rewritten, truncated or normalised")
                    .assertion("assertEquals on the returned identifier")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted")
                    .check(CheckType.RETURN_EQUALS_VALUE, "an accepted identifier must be returned unchanged", "data:name")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011046")
    void case_UTAPI_011046() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011046",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "validate",
                "String",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011046", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011046")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::validate::2::ARG::1::-::name")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_VALIDATION)
                    .observation("the return value of validate, or the rejection it raises")
                    .expected("the identifier is either rejected as an invalid argument or returned exactly as supplied")
                    .failure("the identifier is silently rewritten, truncated or normalised while being accepted")
                    .assertion("assertEquals on the returned identifier, IllegalArgumentException on rejection")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_EQUALS_VALUE, "an accepted identifier must be returned unchanged", "data:name")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011047")
    void case_UTAPI_011047() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011047",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "validate",
                "String",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011047", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011047")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::validate::2::ARG::1::-::name")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_VALIDATION)
                    .observation("the return value of validate")
                    .expected("a valid identifier is accepted and returned exactly as supplied")
                    .failure("a valid identifier is rejected, or it is silently rewritten, truncated or normalised")
                    .assertion("assertEquals on the returned identifier")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted")
                    .check(CheckType.RETURN_EQUALS_VALUE, "an accepted identifier must be returned unchanged", "data:name")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011048")
    void case_UTAPI_011048() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011048",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "validate",
                "String",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011048", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011048")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::validate::2::ARG::1::-::name")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_VALIDATION)
                    .observation("the return value of validate, or the rejection it raises")
                    .expected("the identifier is either rejected as an invalid argument or returned exactly as supplied")
                    .failure("the identifier is silently rewritten, truncated or normalised while being accepted")
                    .assertion("assertEquals on the returned identifier, IllegalArgumentException on rejection")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_EQUALS_VALUE, "an accepted identifier must be returned unchanged", "data:name")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011049")
    void case_UTAPI_011049() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011049",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "validate",
                "String",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011049", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011049")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::validate::2::ARG::1::-::name")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_VALIDATION)
                    .observation("the return value of validate")
                    .expected("a valid identifier is accepted and returned exactly as supplied")
                    .failure("a valid identifier is rejected, or it is silently rewritten, truncated or normalised")
                    .assertion("assertEquals on the returned identifier")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted")
                    .check(CheckType.RETURN_EQUALS_VALUE, "an accepted identifier must be returned unchanged", "data:name")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011050")
    void case_UTAPI_011050() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011050",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "validate",
                "String",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011050", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011050")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::validate::2::ARG::1::-::name")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_VALIDATION)
                    .observation("the return value of validate, or the rejection it raises")
                    .expected("the identifier is either rejected as an invalid argument or returned exactly as supplied")
                    .failure("the identifier is silently rewritten, truncated or normalised while being accepted")
                    .assertion("assertEquals on the returned identifier, IllegalArgumentException on rejection")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_EQUALS_VALUE, "an accepted identifier must be returned unchanged", "data:name")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011051")
    void case_UTAPI_011051() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011051",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "validate",
                "String",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011051", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011051")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::validate::2::ARG::1::-::name")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_VALIDATION)
                    .observation("the return value of validate, or the rejection it raises")
                    .expected("the identifier is either rejected as an invalid argument or returned exactly as supplied")
                    .failure("the identifier is silently rewritten, truncated or normalised while being accepted")
                    .assertion("assertEquals on the returned identifier, IllegalArgumentException on rejection")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_EQUALS_VALUE, "an accepted identifier must be returned unchanged", "data:name")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011052")
    void case_UTAPI_011052() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011052",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "validate",
                "String",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011052", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011052")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::validate::2::ARG::1::-::name")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_VALIDATION)
                    .observation("the return value of validate, or the rejection it raises")
                    .expected("the identifier is either rejected as an invalid argument or returned exactly as supplied")
                    .failure("the identifier is silently rewritten, truncated or normalised while being accepted")
                    .assertion("assertEquals on the returned identifier, IllegalArgumentException on rejection")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_EQUALS_VALUE, "an accepted identifier must be returned unchanged", "data:name")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011053")
    void case_UTAPI_011053() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011053",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "validate",
                "String",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011053", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011053")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::validate::2::ARG::1::-::name")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_VALIDATION)
                    .observation("the return value of validate, or the rejection it raises")
                    .expected("the identifier is either rejected as an invalid argument or returned exactly as supplied")
                    .failure("the identifier is silently rewritten, truncated or normalised while being accepted")
                    .assertion("assertEquals on the returned identifier, IllegalArgumentException on rejection")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_EQUALS_VALUE, "an accepted identifier must be returned unchanged", "data:name")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011054")
    void case_UTAPI_011054() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011054",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "validate",
                "String",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011054", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011054")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::validate::2::ARG::1::-::name")
                    .mirror("-", "-", "56:space")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_VALIDATION)
                    .observation("the return value of validate, or the rejection it raises")
                    .expected("the identifier is either rejected as an invalid argument or returned exactly as supplied")
                    .failure("the identifier is silently rewritten, truncated or normalised while being accepted")
                    .assertion("assertEquals on the returned identifier, IllegalArgumentException on rejection")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_EQUALS_VALUE, "an accepted identifier must be returned unchanged", "data:name")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011055")
    void case_UTAPI_011055() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011055",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "validate",
                "String",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011055", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011055")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::validate::2::ARG::1::-::name")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_VALIDATION)
                    .observation("the return value of validate, or the rejection it raises")
                    .expected("the identifier is either rejected as an invalid argument or returned exactly as supplied")
                    .failure("the identifier is silently rewritten, truncated or normalised while being accepted")
                    .assertion("assertEquals on the returned identifier, IllegalArgumentException on rejection")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_EQUALS_VALUE, "an accepted identifier must be returned unchanged", "data:name")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011056")
    void case_UTAPI_011056() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011056",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "validate",
                "String",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011056", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011056")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::validate::2::ARG::1::-::name")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_VALIDATION)
                    .observation("the return value of validate, or the rejection it raises")
                    .expected("the identifier is either rejected as an invalid argument or returned exactly as supplied")
                    .failure("the identifier is silently rewritten, truncated or normalised while being accepted")
                    .assertion("assertEquals on the returned identifier, IllegalArgumentException on rejection")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_EQUALS_VALUE, "an accepted identifier must be returned unchanged", "data:name")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011057")
    void case_UTAPI_011057() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011057",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "validate",
                "String",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011057", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011057")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::validate::2::ARG::1::-::name")
                    .mirror("-", "-", "59:tab")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_VALIDATION)
                    .observation("the return value of validate, or the rejection it raises")
                    .expected("the identifier is either rejected as an invalid argument or returned exactly as supplied")
                    .failure("the identifier is silently rewritten, truncated or normalised while being accepted")
                    .assertion("assertEquals on the returned identifier, IllegalArgumentException on rejection")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_EQUALS_VALUE, "an accepted identifier must be returned unchanged", "data:name")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011058")
    void case_UTAPI_011058() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011058",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "validate",
                "String",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011058", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011058")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::validate::2::ARG::1::-::name")
                    .mirror("-", "-", "60:control_character_null")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_VALIDATION)
                    .observation("the return value of validate, or the rejection it raises")
                    .expected("the identifier is either rejected as an invalid argument or returned exactly as supplied")
                    .failure("the identifier is silently rewritten, truncated or normalised while being accepted")
                    .assertion("assertEquals on the returned identifier, IllegalArgumentException on rejection")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_EQUALS_VALUE, "an accepted identifier must be returned unchanged", "data:name")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011059")
    void case_UTAPI_011059() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011059",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "validate",
                "String",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011059", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011059")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::validate::2::ARG::1::-::name")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_VALIDATION)
                    .observation("the return value of validate, or the rejection it raises")
                    .expected("the identifier is either rejected as an invalid argument or returned exactly as supplied")
                    .failure("the identifier is silently rewritten, truncated or normalised while being accepted")
                    .assertion("assertEquals on the returned identifier, IllegalArgumentException on rejection")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_EQUALS_VALUE, "an accepted identifier must be returned unchanged", "data:name")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011060")
    void case_UTAPI_011060() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011060",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "validate",
                "String",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011060", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011060")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::validate::2::ARG::1::-::name")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_VALIDATION)
                    .observation("the return value of validate, or the rejection it raises")
                    .expected("the identifier is either rejected as an invalid argument or returned exactly as supplied")
                    .failure("the identifier is silently rewritten, truncated or normalised while being accepted")
                    .assertion("assertEquals on the returned identifier, IllegalArgumentException on rejection")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_EQUALS_VALUE, "an accepted identifier must be returned unchanged", "data:name")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011061")
    void case_UTAPI_011061() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011061",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "validate",
                "String",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011061", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011061")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::validate::2::ARG::1::-::name")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_VALIDATION)
                    .observation("the return value of validate, or the rejection it raises")
                    .expected("the identifier is either rejected as an invalid argument or returned exactly as supplied")
                    .failure("the identifier is silently rewritten, truncated or normalised while being accepted")
                    .assertion("assertEquals on the returned identifier, IllegalArgumentException on rejection")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_EQUALS_VALUE, "an accepted identifier must be returned unchanged", "data:name")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011062")
    void case_UTAPI_011062() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011062",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "validate",
                "String",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011062", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011062")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::validate::2::ARG::1::-::name")
                    .mirror("-", "-", "26:valid_value")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_VALIDATION)
                    .observation("the return value of validate, or the rejection it raises")
                    .expected("the identifier is either rejected as an invalid argument or returned exactly as supplied")
                    .failure("the identifier is silently rewritten, truncated or normalised while being accepted")
                    .assertion("assertEquals on the returned identifier, IllegalArgumentException on rejection")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_EQUALS_VALUE, "an accepted identifier must be returned unchanged", "data:name")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011063")
    void case_UTAPI_011063() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011063",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "validate",
                "String",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011063", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011063")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::validate::2::ARG::1::-::name")
                    .mirror("-", "-", "27:invalid_value")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_VALIDATION)
                    .observation("the return value of validate, or the rejection it raises")
                    .expected("the identifier is either rejected as an invalid argument or returned exactly as supplied")
                    .failure("the identifier is silently rewritten, truncated or normalised while being accepted")
                    .assertion("assertEquals on the returned identifier, IllegalArgumentException on rejection")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_EQUALS_VALUE, "an accepted identifier must be returned unchanged", "data:name")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011064")
    void case_UTAPI_011064() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011064",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "validate",
                "String",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011064", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011064")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::validate::2::ARG::1::-::name")
                    .mirror("-", "-", "28:leap_year")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_VALIDATION)
                    .observation("the return value of validate, or the rejection it raises")
                    .expected("the identifier is either rejected as an invalid argument or returned exactly as supplied")
                    .failure("the identifier is silently rewritten, truncated or normalised while being accepted")
                    .assertion("assertEquals on the returned identifier, IllegalArgumentException on rejection")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_EQUALS_VALUE, "an accepted identifier must be returned unchanged", "data:name")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011065")
    void case_UTAPI_011065() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011065",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "validate",
                "String",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011065", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011065")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::validate::2::ARG::1::-::name")
                    .mirror("-", "-", "31:zero_padded")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_VALIDATION)
                    .observation("the return value of validate, or the rejection it raises")
                    .expected("the identifier is either rejected as an invalid argument or returned exactly as supplied")
                    .failure("the identifier is silently rewritten, truncated or normalised while being accepted")
                    .assertion("assertEquals on the returned identifier, IllegalArgumentException on rejection")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_EQUALS_VALUE, "an accepted identifier must be returned unchanged", "data:name")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011066")
    void case_UTAPI_011066() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011066",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "validate",
                "String",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011066", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011066")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::validate::2::ARG::1::-::name")
                    .mirror("-", "-", "32:not_zero_padded")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_VALIDATION)
                    .observation("the return value of validate, or the rejection it raises")
                    .expected("the identifier is either rejected as an invalid argument or returned exactly as supplied")
                    .failure("the identifier is silently rewritten, truncated or normalised while being accepted")
                    .assertion("assertEquals on the returned identifier, IllegalArgumentException on rejection")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_EQUALS_VALUE, "an accepted identifier must be returned unchanged", "data:name")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011067")
    void case_UTAPI_011067() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011067",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "validate",
                "String",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011067", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011067")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::validate::2::ARG::1::-::name")
                    .mirror("-", "-", "33:with_time_zone")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_VALIDATION)
                    .observation("the return value of validate, or the rejection it raises")
                    .expected("the identifier is either rejected as an invalid argument or returned exactly as supplied")
                    .failure("the identifier is silently rewritten, truncated or normalised while being accepted")
                    .assertion("assertEquals on the returned identifier, IllegalArgumentException on rejection")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_EQUALS_VALUE, "an accepted identifier must be returned unchanged", "data:name")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011068")
    void case_UTAPI_011068() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011068",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "validate",
                "String",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011068", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011068")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::validate::2::ARG::1::-::name")
                    .mirror("-", "-", "34:without_time_zone")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_VALIDATION)
                    .observation("the return value of validate, or the rejection it raises")
                    .expected("the identifier is either rejected as an invalid argument or returned exactly as supplied")
                    .failure("the identifier is silently rewritten, truncated or normalised while being accepted")
                    .assertion("assertEquals on the returned identifier, IllegalArgumentException on rejection")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_EQUALS_VALUE, "an accepted identifier must be returned unchanged", "data:name")
                    .build()),
            new TableNameValidatorWrapper());
    }

}

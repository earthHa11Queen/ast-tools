package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for ExportController.
 */
public final class ExportControllerWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.adapter.controller.ExportController";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.adapter.controller.ExportController";
    private static final String[] DEP_NAMES = new String[] {"exportUseCase", "TS"};
    private static final String[] DEP_TYPES = new String[] {"ExportUseCase", "DateTimeFormatter"};
    private static final String[] TYPES_downloadHeaders = new String[] {"String", "String"};
    private static final String[] TYPES_export = new String[] {"String", "Integer", "String", "String"};
    private static final String[] TYPES_markdown = new String[] {"String", "Integer", "String"};

    public ExportControllerWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, false);
    }

    /** HttpHeaders downloadHeaders(filename, contentType) */
    public ExecutionResult downloadHeaders(Object[] args) {
        return invoke("downloadHeaders", TYPES_downloadHeaders, args);
    }

    /** ResponseEntity<byte[]> export(name, connectionId, format, schema) */
    public ExecutionResult export(Object[] args) {
        return invoke("export", TYPES_export, args);
    }

    /** ResponseEntity<byte[]> markdown(name, connectionId, schema) */
    public ExecutionResult markdown(Object[] args) {
        return invoke("markdown", TYPES_markdown, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("downloadHeaders".equals(operation)) {
            return downloadHeaders(args);
        } else if ("export".equals(operation)) {
            return export(args);
        } else if ("markdown".equals(operation)) {
            return markdown(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;
import org.mockito.MockedStatic;
import java.sql.DriverManager;

/**
 * Operation wrapper for ConnectionSettingGateway.
 */
public final class ConnectionSettingGatewayWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway";
    private static final String[] DEP_NAMES = new String[] {"jdbcTemplate", "SCHEMA", "rowMapper"};
    private static final String[] DEP_TYPES = new String[] {"JdbcTemplate", "String", "RowMapper<ConnectionSetting>"};
    private static final String[] TYPES_deleteById = new String[] {"Integer"};
    private static final String[] TYPES_findAll = new String[] {};
    private static final String[] TYPES_findById = new String[] {"Integer"};
    private static final String[] TYPES_save = new String[] {"ConnectionSetting"};
    private static final String[] TYPES_testConnection = new String[] {"String", "Integer", "String", "String", "String"};
    private static final String[] TYPES_update = new String[] {"ConnectionSetting"};

    public ConnectionSettingGatewayWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, false);
        registry().setGenericHint("ConnectionSetting");
    }

    @Override
    protected void openStatics() {
        final ConnectionSettingGatewayWrapper self = this;
        MockedStatic<DriverManager> mocked = org.mockito.Mockito.mockStatic(DriverManager.class,
                invocation -> {
                    self.recordStatic("DriverManager", invocation.getMethod().getName(), invocation.getArguments());
                    Class<?> ret = invocation.getMethod().getReturnType();
                    if (ret == void.class) {
                        return null;
                    } else if (ret.isPrimitive()) {
                        return org.mockito.Answers.RETURNS_DEFAULTS.get().answer(invocation);
                    } else if (ret.isInterface() || !java.lang.reflect.Modifier.isFinal(ret.getModifiers())) {
                        return org.mockito.Mockito.mock(ret);
                    } else {
                        return null;
                    }
                });
        registerCloseable(mocked);
    }

    /** void deleteById(n) */
    public ExecutionResult deleteById(Object[] args) {
        return invoke("deleteById", TYPES_deleteById, args);
    }

    /** List<ConnectionSetting> findAll() */
    public ExecutionResult findAll(Object[] args) {
        return invoke("findAll", TYPES_findAll, args);
    }

    /** Optional<ConnectionSetting> findById(n) */
    public ExecutionResult findById(Object[] args) {
        return invoke("findById", TYPES_findById, args);
    }

    /** ConnectionSetting save(setting) */
    public ExecutionResult save(Object[] args) {
        return invoke("save", TYPES_save, args);
    }

    /** boolean testConnection(host, port, databaseName, username, password) */
    public ExecutionResult testConnection(Object[] args) {
        return invoke("testConnection", TYPES_testConnection, args);
    }

    /** ConnectionSetting update(setting) */
    public ExecutionResult update(Object[] args) {
        return invoke("update", TYPES_update, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("deleteById".equals(operation)) {
            return deleteById(args);
        } else if ("findAll".equals(operation)) {
            return findAll(args);
        } else if ("findById".equals(operation)) {
            return findById(args);
        } else if ("save".equals(operation)) {
            return save(args);
        } else if ("testConnection".equals(operation)) {
            return testConnection(args);
        } else if ("update".equals(operation)) {
            return update(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

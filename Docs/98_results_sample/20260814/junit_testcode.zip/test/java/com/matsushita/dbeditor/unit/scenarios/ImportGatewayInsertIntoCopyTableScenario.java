package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ImportGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ImportGateway#insertIntoCopyTable.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ImportGatewayInsertIntoCopyTableScenario {

    @Test
    @DisplayName("UTAPI-002632")
    void case_UTAPI_002632() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002632",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002632", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002632", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002632", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002632", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002632", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002632", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002632", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002632", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002632", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002632", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002632", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002632", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002632", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002632", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002632", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002632", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002632", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002632", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002632")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002633")
    void case_UTAPI_002633() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002633",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002633", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002633", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002633", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002633", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002633", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002633", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002633", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002633", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002633", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002633", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002633", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002633", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002633", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002633", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002633", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002633", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002633", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002633", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002633")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002634")
    void case_UTAPI_002634() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002634",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002634", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002634", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002634", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002634", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002634", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002634", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002634", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002634", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002634", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002634", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002634", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002634", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002634", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002634", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002634", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002634", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002634", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002634", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002634")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002635")
    void case_UTAPI_002635() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002635",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002635", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002635", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002635", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002635", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002635", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002635", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002635", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002635", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002635", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002635", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002635", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002635", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002635", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002635", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002635", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002635", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002635", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002635", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002635")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002636")
    void case_UTAPI_002636() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002636",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002636", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002636", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002636", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002636", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002636", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002636", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002636", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002636", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002636", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002636", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002636", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002636", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002636", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002636", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002636", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002636", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002636", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002636", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002636")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002637")
    void case_UTAPI_002637() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002637",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002637", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002637", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002637", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002637", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002637", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002637", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002637", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002637", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002637", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002637", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002637", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002637", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002637", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002637", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002637", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002637", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002637", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002637", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002637")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002638")
    void case_UTAPI_002638() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002638",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002638", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002638", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002638", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002638", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002638", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002638", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002638", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002638", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002638", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002638", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002638", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002638", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002638", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002638", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002638", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002638", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002638", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002638", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002638")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002639")
    void case_UTAPI_002639() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002639",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002639", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002639", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002639", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002639", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002639", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002639", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002639", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002639", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002639", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002639", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002639", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002639", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002639", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002639", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002639", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002639", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002639", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002639", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002639")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002640")
    void case_UTAPI_002640() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002640",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002640", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002640", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002640", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002640", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002640", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002640", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002640", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002640", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002640", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002640", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002640", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002640", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002640", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002640", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002640", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002640", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002640", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002640", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002640")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002641")
    void case_UTAPI_002641() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002641",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002641", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002641", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002641", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002641", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002641", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002641", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002641", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002641", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002641", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002641", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002641", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002641", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002641", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002641", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002641", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002641", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002641", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002641", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002641")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002642")
    void case_UTAPI_002642() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002642",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002642", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002642", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002642", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002642", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002642", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002642", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002642", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002642", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002642", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002642", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002642", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002642", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002642", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002642", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002642", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002642", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002642", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002642", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002642")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002643")
    void case_UTAPI_002643() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002643",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002643", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002643", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002643", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002643", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002643", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002643", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002643", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002643", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002643", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002643", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002643", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002643", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002643", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002643", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002643", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002643", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002643", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002643", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002643")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002644")
    void case_UTAPI_002644() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002644",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002644", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002644", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002644", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002644", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002644", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002644", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002644", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002644", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002644", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002644", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002644", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002644", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002644", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002644", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002644", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002644", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002644", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002644", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002644")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002645")
    void case_UTAPI_002645() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002645",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002645", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002645", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002645", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002645", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002645", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002645", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002645", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002645", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002645", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002645", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002645", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002645", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002645", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002645", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002645", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002645", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002645", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002645", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002645")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002646")
    void case_UTAPI_002646() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002646",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002646", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002646", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002646", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002646", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002646", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002646", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002646", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002646", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002646", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002646", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002646", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002646", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002646", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002646", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002646", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002646", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002646", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002646", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002646")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002647")
    void case_UTAPI_002647() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002647",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002647", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002647", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002647", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002647", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002647", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002647", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002647", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002647", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002647", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002647", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002647", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002647", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002647", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002647", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002647", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002647", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002647", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002647", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002647")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002648")
    void case_UTAPI_002648() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002648",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002648", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002648", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002648", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002648", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002648", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002648", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002648", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002648", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002648", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002648", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002648", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002648", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002648", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002648", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002648", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002648", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002648", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002648", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002648")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002649")
    void case_UTAPI_002649() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002649",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002649", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002649", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002649", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002649", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002649", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002649", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002649", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002649", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002649", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002649", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002649", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002649", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002649", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002649", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002649", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002649", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002649", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002649", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002649")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002650")
    void case_UTAPI_002650() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002650",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002650", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002650", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002650", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002650", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002650", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002650", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002650", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002650", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002650", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002650", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002650", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002650", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002650", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002650", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002650", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002650", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002650", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002650", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002650")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002651")
    void case_UTAPI_002651() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002651",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002651", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002651", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002651", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002651", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002651", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002651", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002651", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002651", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002651", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002651", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002651", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002651", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002651", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002651", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002651", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002651", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002651", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002651", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002651")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002652")
    void case_UTAPI_002652() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002652",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002652", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002652", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002652", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002652", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002652", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002652", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002652", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002652", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002652", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002652", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002652", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002652", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002652", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002652", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002652", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002652", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002652", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002652", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002652")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002653")
    void case_UTAPI_002653() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002653",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002653", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002653", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002653", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002653", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002653", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002653", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002653", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002653", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002653", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002653", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002653", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002653", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002653", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002653", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002653", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002653", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002653", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002653", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002653")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002654")
    void case_UTAPI_002654() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002654",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002654", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002654", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002654", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002654", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002654", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002654", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002654", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002654", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002654", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002654", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002654", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002654", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002654", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002654", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002654", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002654", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002654", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002654", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002654")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002655")
    void case_UTAPI_002655() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002655",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002655", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002655", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002655", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002655", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002655", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002655", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002655", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002655", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002655", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002655", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002655", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002655", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002655", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002655", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002655", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002655", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002655", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002655", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002655")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002656")
    void case_UTAPI_002656() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002656",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002656", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002656", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002656", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002656", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002656", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002656", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002656", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002656", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002656", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002656", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002656", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002656", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002656", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002656", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002656", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002656", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002656", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002656", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002656")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002657")
    void case_UTAPI_002657() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002657",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002657", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002657", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002657", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002657", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002657", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002657", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002657", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002657", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002657", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002657", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002657", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002657", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002657", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002657", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002657", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002657", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002657", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002657", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002657")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002658")
    void case_UTAPI_002658() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002658",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002658", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002658", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002658", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002658", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002658", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002658", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002658", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002658", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002658", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002658", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002658", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002658", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002658", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002658", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002658", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002658", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002658", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002658", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002658")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002659")
    void case_UTAPI_002659() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002659",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002659", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002659", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002659", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002659", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002659", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002659", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002659", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002659", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002659", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002659", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002659", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002659", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002659", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002659", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002659", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002659", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002659", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002659", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002659")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002660")
    void case_UTAPI_002660() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002660",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002660", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002660", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002660", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002660", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002660", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002660", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002660", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002660", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002660", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002660", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002660", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002660", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002660", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002660", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002660", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002660", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002660", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002660", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002660")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002661")
    void case_UTAPI_002661() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002661",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002661", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002661", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002661", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002661", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002661", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002661", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002661", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002661", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002661", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002661", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002661", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002661", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002661", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002661", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002661", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002661", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002661", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002661", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002661")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002662")
    void case_UTAPI_002662() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002662",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002662", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002662", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002662", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002662", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002662", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002662", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002662", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002662", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002662", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002662", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002662", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002662", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002662", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002662", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002662", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002662", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002662", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002662", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002662")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002663")
    void case_UTAPI_002663() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002663",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002663", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002663", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002663", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002663", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002663", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002663", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002663", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002663", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002663", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002663", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002663", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002663", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002663", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002663", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002663", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002663", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002663", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002663", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002663")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002664")
    void case_UTAPI_002664() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002664",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002664", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002664", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002664", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002664", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002664", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002664", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002664", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002664", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002664", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002664", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002664", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002664", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002664", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002664", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002664", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002664", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002664", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002664", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002664")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002665")
    void case_UTAPI_002665() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002665",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002665", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002665", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002665", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002665", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002665", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002665", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002665", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002665", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002665", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002665", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002665", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002665", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002665", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002665", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002665", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002665", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002665", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002665", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002665")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002666")
    void case_UTAPI_002666() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002666",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002666", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002666", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002666", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002666", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002666", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002666", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002666", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002666", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002666", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002666", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002666", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002666", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002666", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002666", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002666", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002666", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002666", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002666", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002666")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002667")
    void case_UTAPI_002667() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002667",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002667", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002667", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002667", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002667", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002667", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002667", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002667", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002667", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002667", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002667", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002667", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002667", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002667", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002667", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002667", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002667", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002667", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002667", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002667")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002668")
    void case_UTAPI_002668() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002668",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002668", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002668", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002668", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002668", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002668", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002668", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002668", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002668", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002668", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002668", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002668", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002668", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002668", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002668", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002668", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002668", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002668", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002668", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002668")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002669")
    void case_UTAPI_002669() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002669",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002669", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002669", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002669", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002669", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002669", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002669", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002669", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002669", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002669", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002669", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002669", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002669", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002669", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002669", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002669", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002669", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002669", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002669", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002669")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002670")
    void case_UTAPI_002670() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002670",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002670", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002670", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002670", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002670", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002670", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002670", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002670", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002670", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002670", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002670", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002670", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002670", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002670", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002670", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002670", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002670", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002670", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002670", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002670")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002671")
    void case_UTAPI_002671() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002671",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002671", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002671", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002671", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002671", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002671", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002671", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002671", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002671", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002671", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002671", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002671", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002671", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002671", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002671", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002671", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002671", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002671", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002671", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002671")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002672")
    void case_UTAPI_002672() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002672",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002672", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002672", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002672", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002672", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002672", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002672", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002672", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002672", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002672", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002672", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002672", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002672", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002672", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002672", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002672", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002672", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002672", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002672", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002672")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002673")
    void case_UTAPI_002673() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002673",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002673", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002673", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002673", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002673", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002673", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002673", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002673", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002673", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002673", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002673", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002673", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002673", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002673", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002673", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002673", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002673", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002673", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002673", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002673")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002674")
    void case_UTAPI_002674() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002674",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002674", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002674", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002674", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002674", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002674", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002674", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002674", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002674", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002674", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002674", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002674", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002674", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002674", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002674", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002674", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002674", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002674", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002674", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002674")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002675")
    void case_UTAPI_002675() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002675",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002675", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002675", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002675", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002675", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002675", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002675", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002675", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002675", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002675", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002675", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002675", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002675", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002675", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002675", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002675", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002675", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002675", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002675", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002675")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002676")
    void case_UTAPI_002676() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002676",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002676", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002676", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002676", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002676", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002676", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002676", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002676", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002676", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002676", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002676", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002676", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002676", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002676", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002676", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002676", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002676", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002676", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002676", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002676")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002677")
    void case_UTAPI_002677() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002677",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002677", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002677", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002677", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002677", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002677", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002677", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002677", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002677", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002677", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002677", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002677", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002677", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002677", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002677", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002677", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002677", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002677", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002677", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002677")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002678")
    void case_UTAPI_002678() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002678",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002678", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002678", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002678", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002678", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002678", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002678", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002678", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002678", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002678", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002678", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002678", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002678", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002678", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002678", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002678", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002678", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002678", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002678", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002678")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002679")
    void case_UTAPI_002679() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002679",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002679", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002679", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002679", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002679", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002679", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002679", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002679", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002679", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002679", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002679", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002679", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002679", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002679", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002679", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002679", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002679", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002679", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002679", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002679")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002680")
    void case_UTAPI_002680() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002680",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002680", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002680", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002680", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002680", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002680", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002680", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002680", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002680", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002680", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002680", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002680", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002680", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002680", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002680", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002680", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002680", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002680", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002680", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002680")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002681")
    void case_UTAPI_002681() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002681",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002681", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002681", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002681", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002681", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002681", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002681", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002681", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002681", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002681", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002681", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002681", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002681", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002681", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002681", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002681", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002681", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002681", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002681", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002681")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002682")
    void case_UTAPI_002682() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002682",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002682", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002682", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002682", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002682", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002682", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002682", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002682", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002682", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002682", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002682", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002682", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002682", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002682", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002682", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002682", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002682", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002682", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002682", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002682")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002683")
    void case_UTAPI_002683() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002683",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002683", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002683", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002683", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002683", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002683", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002683", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002683", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002683", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002683", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002683", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002683", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002683", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002683", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002683", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002683", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002683", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002683", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002683", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002683")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002684")
    void case_UTAPI_002684() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002684",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002684", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002684", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002684", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002684", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002684", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002684", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002684", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002684", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002684", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002684", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002684", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002684", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002684", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002684", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002684", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002684", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002684", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002684", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002684")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002685")
    void case_UTAPI_002685() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002685",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002685", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002685", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002685", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002685", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002685", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002685", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002685", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002685", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002685", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002685", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002685", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002685", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002685", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002685", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002685", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002685", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002685", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002685", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002685")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002686")
    void case_UTAPI_002686() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002686",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002686", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002686", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002686", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002686", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002686", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002686", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002686", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002686", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002686", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002686", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002686", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002686", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002686", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002686", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002686", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002686", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002686", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002686", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002686")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002687")
    void case_UTAPI_002687() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002687",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002687", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002687", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002687", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002687", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002687", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002687", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002687", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002687", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002687", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002687", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002687", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002687", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002687", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002687", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002687", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002687", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002687", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002687", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002687")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002688")
    void case_UTAPI_002688() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002688",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002688", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002688", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002688", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002688", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002688", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002688", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002688", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002688", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002688", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002688", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002688", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002688", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002688", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002688", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002688", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002688", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002688", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002688", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002688")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002689")
    void case_UTAPI_002689() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002689",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002689", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002689", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002689", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002689", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002689", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002689", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002689", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002689", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002689", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002689", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002689", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002689", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002689", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002689", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002689", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002689", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002689", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002689", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002689")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002690")
    void case_UTAPI_002690() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002690",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002690", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002690", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002690", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002690", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002690", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002690", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002690", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002690", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002690", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002690", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002690", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002690", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002690", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002690", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002690", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002690", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002690", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002690", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002690")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002691")
    void case_UTAPI_002691() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002691",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002691", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002691", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002691", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002691", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002691", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002691", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002691", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002691", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002691", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002691", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002691", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002691", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002691", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002691", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002691", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002691", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002691", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002691", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002691")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002692")
    void case_UTAPI_002692() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002692",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002692", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002692", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002692", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002692", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002692", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002692", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002692", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002692", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002692", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002692", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002692", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002692", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002692", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002692", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002692", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002692", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002692", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002692", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002692")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002693")
    void case_UTAPI_002693() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002693",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002693", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002693", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002693", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002693", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002693", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002693", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002693", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002693", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002693", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002693", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002693", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002693", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002693", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002693", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002693", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002693", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002693", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002693", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002693")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002694")
    void case_UTAPI_002694() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002694",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002694", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002694", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002694", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002694", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002694", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002694", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002694", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002694", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002694", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002694", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002694", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002694", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002694", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002694", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002694", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002694", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002694", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002694", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002694")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002695")
    void case_UTAPI_002695() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002695",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002695", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002695", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002695", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002695", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002695", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002695", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002695", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002695", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002695", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002695", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002695", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002695", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002695", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002695", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002695", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002695", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002695", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002695", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002695")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002696")
    void case_UTAPI_002696() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002696",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002696", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002696", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002696", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002696", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002696", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002696", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002696", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002696", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002696", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002696", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002696", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002696", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002696", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002696", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002696", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002696", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002696", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002696", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002696")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002697")
    void case_UTAPI_002697() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002697",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002697", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002697", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002697", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002697", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002697", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002697", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002697", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002697", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002697", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002697", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002697", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002697", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002697", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002697", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002697", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002697", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002697", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002697", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002697")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002698")
    void case_UTAPI_002698() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002698",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002698", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002698", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002698", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002698", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002698", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002698", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002698", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002698", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002698", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002698", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002698", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002698", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002698", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002698", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002698", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002698", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002698", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002698", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002698")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002699")
    void case_UTAPI_002699() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002699",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002699", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002699", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002699", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002699", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002699", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002699", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002699", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002699", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002699", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002699", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002699", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002699", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002699", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002699", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002699", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002699", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002699", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002699", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002699")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002700")
    void case_UTAPI_002700() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002700",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002700", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002700", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002700", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002700", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002700", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002700", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002700", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002700", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002700", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002700", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002700", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002700", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002700", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002700", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002700", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002700", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002700", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002700", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002700")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002701")
    void case_UTAPI_002701() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002701",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002701", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002701", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002701", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002701", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002701", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002701", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002701", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002701", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002701", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002701", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002701", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002701", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002701", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002701", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002701", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002701", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002701", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002701", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002701")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002702")
    void case_UTAPI_002702() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002702",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002702", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002702", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002702", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002702", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002702", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002702", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002702", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002702", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002702", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002702", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002702", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002702", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002702", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002702", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002702", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002702", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002702", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002702", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002702")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002703")
    void case_UTAPI_002703() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002703",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002703", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002703", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002703", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002703", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002703", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002703", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002703", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002703", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002703", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002703", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002703", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002703", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002703", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002703", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002703", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002703", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002703", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002703", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002703")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002704")
    void case_UTAPI_002704() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002704",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002704", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002704", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002704", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002704", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002704", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002704", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002704", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002704", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002704", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002704", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002704", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002704", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002704", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002704", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002704", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002704", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002704", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002704", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002704")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002705")
    void case_UTAPI_002705() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002705",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002705", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002705", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002705", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002705", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002705", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002705", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002705", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002705", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002705", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002705", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002705", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002705", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002705", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002705", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002705", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002705", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002705", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002705", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002705")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002706")
    void case_UTAPI_002706() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002706",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002706", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002706", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002706", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002706", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002706", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002706", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002706", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002706", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002706", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002706", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002706", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002706", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002706", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002706", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002706", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002706", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002706", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002706", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002706")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002707")
    void case_UTAPI_002707() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002707",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002707", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002707", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002707", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002707", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002707", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002707", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002707", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002707", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002707", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002707", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002707", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002707", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002707", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002707", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002707", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002707", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002707", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002707", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002707")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002708")
    void case_UTAPI_002708() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002708",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002708", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002708", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002708", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002708", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002708", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002708", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002708", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002708", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002708", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002708", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002708", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002708", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002708", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002708", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002708", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002708", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002708", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002708", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002708")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002709")
    void case_UTAPI_002709() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002709",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002709", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002709", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002709", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002709", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002709", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002709", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002709", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002709", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002709", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002709", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002709", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002709", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002709", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002709", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002709", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002709", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002709", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002709", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002709")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002710")
    void case_UTAPI_002710() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002710",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002710", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002710", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002710", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002710", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002710", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002710", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002710", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002710", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002710", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002710", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002710", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002710", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002710", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002710", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002710", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002710", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002710", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002710", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002710")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002711")
    void case_UTAPI_002711() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002711",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002711", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002711", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002711", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002711", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002711", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002711", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002711", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002711", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002711", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002711", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002711", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002711", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002711", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002711", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002711", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002711", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002711", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002711", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002711")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002712")
    void case_UTAPI_002712() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002712",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002712", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002712", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002712", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002712", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002712", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002712", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002712", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002712", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002712", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002712", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002712", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002712", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002712", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002712", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002712", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002712", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002712", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002712", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002712")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002713")
    void case_UTAPI_002713() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002713",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002713", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002713", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002713", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002713", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002713", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002713", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002713", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002713", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002713", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002713", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002713", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002713", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002713", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002713", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002713", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002713", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002713", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002713", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002713")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002714")
    void case_UTAPI_002714() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002714",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002714", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002714", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002714", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002714", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002714", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002714", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002714", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002714", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002714", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002714", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002714", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002714", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002714", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002714", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002714", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002714", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002714", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002714", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002714")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002715")
    void case_UTAPI_002715() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002715",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002715", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002715", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002715", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002715", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002715", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002715", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002715", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002715", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002715", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002715", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002715", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002715", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002715", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002715", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002715", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002715", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002715", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002715", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002715")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002716")
    void case_UTAPI_002716() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002716",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002716", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002716", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002716", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002716", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002716", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002716", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002716", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002716", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002716", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002716", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002716", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002716", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002716", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002716", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002716", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002716", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002716", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002716", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002716")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002717")
    void case_UTAPI_002717() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002717",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002717", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002717", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002717", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002717", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002717", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002717", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002717", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002717", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002717", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002717", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002717", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002717", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002717", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002717", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002717", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002717", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002717", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002717", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002717")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002718")
    void case_UTAPI_002718() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002718",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002718", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002718", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002718", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002718", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002718", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002718", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002718", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002718", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002718", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002718", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002718", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002718", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002718", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002718", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002718", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002718", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002718", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002718", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002718")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002719")
    void case_UTAPI_002719() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002719",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002719", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002719", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002719", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002719", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002719", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002719", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002719", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002719", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002719", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002719", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002719", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002719", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002719", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002719", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002719", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002719", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002719", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002719", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002719")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002720")
    void case_UTAPI_002720() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002720",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002720", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002720", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002720", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002720", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002720", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002720", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002720", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002720", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002720", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002720", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002720", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002720", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002720", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002720", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002720", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002720", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002720", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002720", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002720")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002721")
    void case_UTAPI_002721() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002721",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002721", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002721", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002721", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002721", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002721", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002721", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002721", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002721", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002721", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002721", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002721", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002721", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002721", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002721", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002721", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002721", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002721", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002721", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002721")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002722")
    void case_UTAPI_002722() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002722",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002722", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002722", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002722", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002722", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002722", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002722", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002722", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002722", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002722", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002722", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002722", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002722", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002722", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002722", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002722", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002722", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002722", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002722", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002722")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002723")
    void case_UTAPI_002723() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002723",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002723", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002723", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002723", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002723", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002723", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002723", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002723", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002723", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002723", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002723", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002723", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002723", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002723", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002723", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002723", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002723", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002723", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002723", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002723")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002724")
    void case_UTAPI_002724() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002724",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002724", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002724", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002724", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002724", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002724", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002724", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002724", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002724", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002724", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002724", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002724", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002724", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002724", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002724", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002724", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002724", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002724", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002724", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002724")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002725")
    void case_UTAPI_002725() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002725",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002725", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002725", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002725", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002725", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002725", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002725", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002725", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002725", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002725", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002725", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002725", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002725", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002725", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002725", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002725", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002725", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002725", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002725", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002725")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002726")
    void case_UTAPI_002726() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002726",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002726", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002726", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002726", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002726", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002726", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002726", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002726", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002726", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002726", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002726", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002726", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002726", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002726", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002726", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002726", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002726", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002726", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002726", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002726")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002727")
    void case_UTAPI_002727() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002727",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002727", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002727", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002727", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002727", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002727", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002727", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002727", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002727", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002727", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002727", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002727", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002727", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002727", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002727", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002727", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002727", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002727", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002727", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002727")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002728")
    void case_UTAPI_002728() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002728",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002728", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002728", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002728", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002728", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002728", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002728", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002728", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002728", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002728", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002728", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002728", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002728", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002728", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002728", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002728", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002728", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002728", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002728", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002728")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002729")
    void case_UTAPI_002729() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002729",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002729", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002729", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002729", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002729", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002729", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002729", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002729", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002729", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002729", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002729", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002729", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002729", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002729", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002729", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002729", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002729", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002729", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002729", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002729")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002730")
    void case_UTAPI_002730() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002730",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002730", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002730", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002730", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002730", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002730", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002730", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002730", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002730", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002730", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002730", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002730", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002730", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002730", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002730", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002730", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002730", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002730", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002730", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002730")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002731")
    void case_UTAPI_002731() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002731",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002731", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002731", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002731", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002731", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002731", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002731", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002731", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002731", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002731", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002731", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002731", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002731", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002731", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002731", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002731", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002731", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002731", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002731", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002731")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002732")
    void case_UTAPI_002732() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002732",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002732", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002732", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002732", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002732", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002732", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002732", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002732", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002732", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002732", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002732", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002732", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002732", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002732", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002732", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002732", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002732", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002732", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002732", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002732")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002733")
    void case_UTAPI_002733() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002733",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002733", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002733", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002733", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002733", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002733", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002733", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002733", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002733", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002733", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002733", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002733", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002733", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002733", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002733", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002733", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002733", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002733", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002733", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002733")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002734")
    void case_UTAPI_002734() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002734",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002734", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002734", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002734", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002734", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002734", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002734", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002734", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002734", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002734", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002734", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002734", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002734", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002734", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002734", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002734", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002734", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002734", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002734", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002734")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002735")
    void case_UTAPI_002735() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002735",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002735", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002735", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002735", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002735", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002735", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002735", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002735", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002735", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002735", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002735", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002735", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002735", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002735", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002735", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002735", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002735", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002735", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002735", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002735")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002736")
    void case_UTAPI_002736() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002736",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002736", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002736", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002736", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002736", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002736", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002736", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002736", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002736", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002736", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002736", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002736", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002736", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002736", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002736", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002736", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002736", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002736", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002736", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002736")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002737")
    void case_UTAPI_002737() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002737",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002737", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002737", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002737", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002737", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002737", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002737", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002737", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002737", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002737", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002737", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002737", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002737", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002737", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002737", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002737", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002737", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002737", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002737", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002737")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002738")
    void case_UTAPI_002738() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002738",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002738", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002738", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002738", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002738", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002738", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002738", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002738", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002738", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002738", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002738", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002738", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002738", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002738", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002738", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002738", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002738", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002738", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002738", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002738")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002739")
    void case_UTAPI_002739() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002739",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002739", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002739", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002739", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002739", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002739", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002739", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002739", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002739", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002739", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002739", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002739", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002739", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002739", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002739", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002739", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002739", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002739", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002739", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002739")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002740")
    void case_UTAPI_002740() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002740",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002740", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002740", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002740", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002740", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002740", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002740", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002740", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002740", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002740", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002740", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002740", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002740", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002740", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002740", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002740", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002740", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002740", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002740", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002740")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002741")
    void case_UTAPI_002741() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002741",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002741", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002741", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002741", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002741", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002741", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002741", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002741", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002741", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002741", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002741", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002741", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002741", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002741", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002741", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002741", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002741", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002741", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002741", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002741")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002742")
    void case_UTAPI_002742() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002742",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002742", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002742", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002742", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002742", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002742", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002742", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002742", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002742", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002742", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002742", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002742", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002742", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002742", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002742", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002742", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002742", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002742", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002742", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002742")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002743")
    void case_UTAPI_002743() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002743",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002743", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002743", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002743", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002743", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002743", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002743", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002743", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002743", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002743", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002743", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002743", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002743", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002743", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002743", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002743", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002743", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002743", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002743", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002743")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002744")
    void case_UTAPI_002744() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002744",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002744", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002744", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002744", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002744", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002744", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002744", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002744", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002744", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002744", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002744", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002744", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002744", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002744", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002744", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002744", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002744", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002744", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002744", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002744")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002745")
    void case_UTAPI_002745() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002745",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002745", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002745", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002745", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002745", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002745", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002745", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002745", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002745", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002745", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002745", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002745", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002745", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002745", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002745", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002745", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002745", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002745", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002745", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002745")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002746")
    void case_UTAPI_002746() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002746",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002746", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002746", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002746", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002746", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002746", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002746", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002746", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002746", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002746", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002746", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002746", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002746", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002746", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002746", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002746", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002746", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002746", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002746", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002746")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002747")
    void case_UTAPI_002747() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002747",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002747", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002747", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002747", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002747", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002747", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002747", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002747", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002747", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002747", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002747", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002747", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002747", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002747", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002747", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002747", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002747", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002747", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002747", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002747")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002748")
    void case_UTAPI_002748() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002748",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002748", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002748", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002748", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002748", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002748", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002748", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002748", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002748", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002748", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002748", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002748", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002748", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002748", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002748", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002748", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002748", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002748", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002748", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002748")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002749")
    void case_UTAPI_002749() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002749",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002749", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002749", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002749", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002749", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002749", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002749", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002749", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002749", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002749", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002749", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002749", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002749", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002749", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002749", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002749", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002749", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002749", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002749", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002749")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002750")
    void case_UTAPI_002750() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002750",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002750", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002750", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002750", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002750", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002750", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002750", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002750", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002750", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002750", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002750", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002750", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002750", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002750", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002750", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002750", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002750", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002750", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002750", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002750")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002751")
    void case_UTAPI_002751() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002751",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002751", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002751", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002751", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002751", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002751", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002751", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002751", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002751", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002751", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002751", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002751", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002751", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002751", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002751", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002751", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002751", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002751", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002751", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002751")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002752")
    void case_UTAPI_002752() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002752",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002752", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002752", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002752", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002752", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002752", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002752", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002752", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002752", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002752", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002752", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002752", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002752", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002752", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002752", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002752", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002752", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002752", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002752", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002752")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002753")
    void case_UTAPI_002753() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002753",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002753", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002753", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002753", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002753", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002753", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002753", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002753", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002753", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002753", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002753", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002753", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002753", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002753", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002753", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002753", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002753", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002753", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002753", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002753")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002754")
    void case_UTAPI_002754() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002754",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002754", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002754", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002754", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002754", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002754", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002754", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002754", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002754", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002754", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002754", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002754", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002754", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002754", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002754", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002754", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002754", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002754", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002754", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002754")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002755")
    void case_UTAPI_002755() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002755",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002755", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002755", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002755", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002755", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002755", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002755", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002755", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002755", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002755", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002755", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002755", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002755", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002755", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002755", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002755", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002755", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002755", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002755", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002755")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002756")
    void case_UTAPI_002756() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002756",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002756", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002756", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002756", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002756", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002756", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002756", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002756", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002756", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002756", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002756", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002756", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002756", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002756", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002756", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002756", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002756", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002756", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002756", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002756")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002757")
    void case_UTAPI_002757() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002757",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002757", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002757", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002757", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002757", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002757", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002757", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002757", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002757", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002757", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002757", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002757", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002757", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002757", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002757", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002757", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002757", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002757", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002757", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002757")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002758")
    void case_UTAPI_002758() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002758",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002758", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002758", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002758", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002758", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002758", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002758", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002758", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002758", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002758", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002758", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002758", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002758", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002758", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002758", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002758", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002758", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002758", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002758", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002758")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002759")
    void case_UTAPI_002759() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002759",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002759", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002759", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002759", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002759", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002759", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002759", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002759", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002759", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002759", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002759", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002759", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002759", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002759", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002759", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002759", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002759", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002759", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002759", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002759")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002760")
    void case_UTAPI_002760() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002760",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002760", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002760", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002760", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002760", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002760", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002760", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002760", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002760", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002760", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002760", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002760", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002760", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002760", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002760", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002760", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002760", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002760", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002760", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002760")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002761")
    void case_UTAPI_002761() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002761",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002761", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002761", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002761", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002761", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002761", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002761", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002761", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002761", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002761", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002761", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002761", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002761", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002761", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002761", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002761", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002761", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002761", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002761", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002761")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002762")
    void case_UTAPI_002762() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002762",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002762", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002762", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002762", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002762", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002762", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002762", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002762", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002762", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002762", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002762", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002762", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002762", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002762", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002762", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002762", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002762", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002762", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002762", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002762")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002763")
    void case_UTAPI_002763() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002763",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002763", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002763", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002763", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002763", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002763", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002763", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002763", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002763", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002763", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002763", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002763", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002763", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002763", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002763", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002763", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002763", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002763", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002763", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002763")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002764")
    void case_UTAPI_002764() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002764",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002764", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002764", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002764", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002764", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002764", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002764", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002764", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002764", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002764", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002764", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002764", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002764", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002764", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002764", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002764", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002764", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002764", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002764", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002764")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002765")
    void case_UTAPI_002765() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002765",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002765", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002765", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002765", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002765", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002765", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002765", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002765", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002765", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002765", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002765", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002765", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002765", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002765", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002765", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002765", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002765", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002765", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002765", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002765")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002766")
    void case_UTAPI_002766() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002766",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002766", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002766", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002766", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002766", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002766", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002766", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002766", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002766", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002766", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002766", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002766", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002766", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002766", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002766", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002766", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002766", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002766", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002766", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002766")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002767")
    void case_UTAPI_002767() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002767",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002767", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002767", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002767", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002767", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002767", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002767", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002767", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002767", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002767", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002767", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002767", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002767", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002767", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002767", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002767", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002767", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002767", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002767", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002767")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002768")
    void case_UTAPI_002768() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002768",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002768", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002768", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002768", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002768", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002768", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002768", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002768", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002768", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002768", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002768", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002768", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002768", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002768", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002768", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002768", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002768", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002768", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002768", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002768")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002769")
    void case_UTAPI_002769() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002769",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002769", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002769", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002769", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002769", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002769", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002769", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002769", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002769", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002769", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002769", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002769", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002769", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002769", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002769", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002769", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002769", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002769", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002769", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002769")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002770")
    void case_UTAPI_002770() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002770",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002770", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002770", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002770", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002770", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002770", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002770", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002770", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002770", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002770", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002770", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002770", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002770", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002770", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002770", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002770", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002770", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002770", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002770", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002770")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002771")
    void case_UTAPI_002771() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002771",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002771", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002771", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002771", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002771", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002771", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002771", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002771", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002771", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002771", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002771", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002771", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002771", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002771", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002771", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002771", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002771", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002771", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002771", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002771")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002772")
    void case_UTAPI_002772() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002772",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002772", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002772", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002772", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002772", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002772", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002772", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002772", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002772", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002772", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002772", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002772", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002772", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002772", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002772", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002772", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002772", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002772", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002772", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002772")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002773")
    void case_UTAPI_002773() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002773",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002773", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002773", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002773", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002773", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002773", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002773", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002773", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002773", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002773", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002773", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002773", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002773", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002773", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002773", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002773", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002773", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002773", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002773", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002773")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002774")
    void case_UTAPI_002774() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002774",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002774", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002774", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002774", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002774", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002774", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002774", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002774", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002774", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002774", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002774", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002774", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002774", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002774", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002774", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002774", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002774", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002774", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002774", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002774")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002775")
    void case_UTAPI_002775() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002775",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002775", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002775", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002775", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002775", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002775", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002775", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002775", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002775", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002775", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002775", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002775", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002775", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002775", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002775", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002775", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002775", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002775", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002775", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002775")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002776")
    void case_UTAPI_002776() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002776",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002776", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002776", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002776", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002776", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002776", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002776", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002776", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002776", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002776", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002776", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002776", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002776", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002776", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002776", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002776", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002776", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002776", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002776", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002776")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002777")
    void case_UTAPI_002777() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002777",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002777", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002777", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002777", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002777", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002777", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002777", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002777", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002777", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002777", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002777", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002777", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002777", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002777", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002777", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002777", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002777", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002777", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002777", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002777")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002778")
    void case_UTAPI_002778() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002778",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002778", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002778", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002778", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002778", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002778", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002778", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002778", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002778", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002778", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002778", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002778", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002778", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002778", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002778", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002778", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002778", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002778", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002778", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002778")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002779")
    void case_UTAPI_002779() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002779",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002779", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002779", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002779", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002779", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002779", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002779", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002779", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002779", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002779", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002779", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002779", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002779", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002779", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002779", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002779", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002779", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002779", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002779", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002779")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002780")
    void case_UTAPI_002780() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002780",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002780", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002780", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002780", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002780", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002780", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002780", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002780", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002780", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002780", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002780", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002780", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002780", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002780", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002780", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002780", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002780", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002780", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002780", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002780")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002781")
    void case_UTAPI_002781() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002781",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002781", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002781", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002781", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002781", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002781", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002781", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002781", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002781", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002781", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002781", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002781", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002781", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002781", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002781", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002781", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002781", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002781", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002781", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002781")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002782")
    void case_UTAPI_002782() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002782",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002782", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002782", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002782", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002782", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002782", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002782", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002782", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002782", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002782", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002782", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002782", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002782", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002782", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002782", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002782", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002782", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002782", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002782", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002782")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002783")
    void case_UTAPI_002783() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002783",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002783", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002783", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002783", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002783", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002783", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002783", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002783", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002783", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002783", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002783", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002783", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002783", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002783", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002783", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002783", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002783", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002783", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002783", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002783")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002784")
    void case_UTAPI_002784() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002784",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002784", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002784", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002784", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002784", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002784", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002784", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002784", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002784", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002784", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002784", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002784", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002784", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002784", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002784", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002784", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002784", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002784", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002784", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002784")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002785")
    void case_UTAPI_002785() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002785",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002785", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002785", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002785", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002785", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002785", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002785", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002785", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002785", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002785", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002785", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002785", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002785", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002785", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002785", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002785", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002785", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002785", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002785", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002785")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002786")
    void case_UTAPI_002786() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002786",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002786", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002786", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002786", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002786", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002786", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002786", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002786", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002786", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002786", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002786", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002786", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002786", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002786", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002786", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002786", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002786", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002786", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002786", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002786")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002787")
    void case_UTAPI_002787() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002787",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002787", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002787", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002787", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002787", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002787", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002787", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002787", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002787", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002787", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002787", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002787", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002787", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002787", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002787", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002787", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002787", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002787", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002787", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002787")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002788")
    void case_UTAPI_002788() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002788",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002788", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002788", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002788", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002788", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002788", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002788", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002788", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002788", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002788", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002788", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002788", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002788", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002788", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002788", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002788", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002788", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002788", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002788", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002788")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002789")
    void case_UTAPI_002789() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002789",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002789", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002789", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002789", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002789", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002789", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002789", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002789", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002789", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002789", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002789", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002789", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002789", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002789", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002789", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002789", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002789", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002789", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002789", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002789")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002790")
    void case_UTAPI_002790() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002790",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002790", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002790", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002790", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002790", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002790", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002790", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002790", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002790", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002790", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002790", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002790", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002790", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002790", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002790", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002790", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002790", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002790", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002790", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002790")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002791")
    void case_UTAPI_002791() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002791",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002791", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002791", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002791", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002791", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002791", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002791", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002791", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002791", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002791", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002791", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002791", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002791", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002791", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002791", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002791", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002791", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002791", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002791", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002791")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002792")
    void case_UTAPI_002792() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002792",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002792", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002792", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002792", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002792", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002792", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002792", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002792", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002792", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002792", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002792", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002792", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002792", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002792", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002792", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002792", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002792", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002792", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002792", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002792")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002793")
    void case_UTAPI_002793() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002793",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002793", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002793", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002793", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002793", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002793", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002793", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002793", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002793", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002793", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002793", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002793", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002793", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002793", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002793", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002793", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002793", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002793", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002793", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002793")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002794")
    void case_UTAPI_002794() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002794",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002794", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002794", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002794", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002794", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002794", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002794", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002794", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002794", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002794", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002794", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002794", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002794", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002794", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002794", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002794", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002794", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002794", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002794", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002794")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002795")
    void case_UTAPI_002795() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002795",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002795", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002795", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002795", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002795", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002795", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002795", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002795", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002795", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002795", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002795", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002795", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002795", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002795", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002795", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002795", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002795", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002795", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002795", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002795")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002796")
    void case_UTAPI_002796() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002796",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002796", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002796", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002796", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002796", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002796", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002796", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002796", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002796", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002796", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002796", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002796", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002796", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002796", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002796", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002796", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002796", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002796", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002796", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002796")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002797")
    void case_UTAPI_002797() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002797",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002797", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002797", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002797", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002797", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002797", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002797", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002797", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002797", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002797", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002797", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002797", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002797", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002797", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002797", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002797", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002797", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002797", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002797", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002797")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002798")
    void case_UTAPI_002798() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002798",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002798", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002798", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002798", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002798", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002798", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002798", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002798", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002798", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002798", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002798", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002798", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002798", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002798", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002798", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002798", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002798", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002798", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002798", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002798")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002799")
    void case_UTAPI_002799() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002799",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002799", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002799", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002799", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002799", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002799", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002799", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002799", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002799", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002799", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002799", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002799", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002799", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002799", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002799", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002799", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002799", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002799", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002799", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002799")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002800")
    void case_UTAPI_002800() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002800",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002800", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002800", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002800", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002800", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002800", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002800", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002800", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002800", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002800", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002800", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002800", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002800", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002800", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002800", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002800", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002800", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002800", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002800", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002800")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002801")
    void case_UTAPI_002801() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002801",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002801", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002801", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002801", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002801", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002801", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002801", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002801", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002801", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002801", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002801", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002801", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002801", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002801", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002801", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002801", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002801", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002801", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002801", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002801")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002802")
    void case_UTAPI_002802() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002802",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002802", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002802", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002802", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002802", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002802", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002802", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002802", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002802", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002802", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002802", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002802", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002802", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002802", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002802", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002802", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002802", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002802", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002802", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002802")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002803")
    void case_UTAPI_002803() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002803",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002803", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002803", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002803", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002803", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002803", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002803", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002803", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002803", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002803", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002803", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002803", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002803", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002803", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002803", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002803", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002803", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002803", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002803", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002803")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002804")
    void case_UTAPI_002804() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002804",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002804", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002804", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002804", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002804", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002804", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002804", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002804", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002804", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002804", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002804", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002804", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002804", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002804", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002804", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002804", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002804", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002804", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002804", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002804")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002805")
    void case_UTAPI_002805() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002805",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002805", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002805", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002805", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002805", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002805", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002805", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002805", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002805", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002805", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002805", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002805", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002805", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002805", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002805", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002805", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002805", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002805", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002805", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002805")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002806")
    void case_UTAPI_002806() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002806",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002806", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002806", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002806", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002806", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002806", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002806", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002806", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002806", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002806", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002806", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002806", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002806", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002806", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002806", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002806", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002806", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002806", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002806", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002806")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002807")
    void case_UTAPI_002807() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002807",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002807", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002807", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002807", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002807", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002807", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002807", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002807", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002807", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002807", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002807", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002807", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002807", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002807", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002807", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002807", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002807", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002807", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002807", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002807")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002808")
    void case_UTAPI_002808() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002808",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002808", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002808", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002808", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002808", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002808", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002808", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002808", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002808", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002808", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002808", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002808", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002808", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002808", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002808", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002808", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002808", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002808", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002808", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002808")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002809")
    void case_UTAPI_002809() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002809",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002809", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002809", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002809", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002809", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002809", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002809", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002809", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002809", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002809", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002809", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002809", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002809", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002809", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002809", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002809", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002809", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002809", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002809", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002809")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002810")
    void case_UTAPI_002810() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002810",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002810", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002810", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002810", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002810", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002810", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002810", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002810", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002810", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002810", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002810", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002810", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002810", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002810", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002810", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002810", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002810", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002810", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002810", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002810")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002811")
    void case_UTAPI_002811() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002811",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002811", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002811", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002811", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002811", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002811", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002811", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002811", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002811", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002811", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002811", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002811", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002811", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002811", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002811", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002811", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002811", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002811", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002811", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002811")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002812")
    void case_UTAPI_002812() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002812",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002812", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002812", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002812", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002812", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002812", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002812", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002812", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002812", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002812", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002812", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002812", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002812", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002812", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002812", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002812", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002812", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002812", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002812", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002812")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002813")
    void case_UTAPI_002813() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002813",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002813", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002813", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002813", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002813", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002813", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002813", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002813", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002813", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002813", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002813", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002813", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002813", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002813", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002813", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002813", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002813", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002813", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002813", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002813")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002814")
    void case_UTAPI_002814() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002814",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002814", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002814", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002814", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002814", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002814", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002814", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002814", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002814", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002814", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002814", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002814", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002814", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002814", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002814", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002814", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002814", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002814", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002814", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002814")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002815")
    void case_UTAPI_002815() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002815",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002815", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002815", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002815", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002815", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002815", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002815", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002815", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002815", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002815", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002815", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002815", "columns", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002815", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002815", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002815", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002815", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002815", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002815", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002815", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002815")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::4::-::columns")
                    .mirror("-", "1:length_null", "-")
                    .target("columns", "columns")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for columns reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for columns must reach the executed statement unchanged", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002816")
    void case_UTAPI_002816() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002816",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002816", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002816", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002816", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002816", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002816", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002816", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002816", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002816", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002816", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002816", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002816", "columns", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002816", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002816", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002816", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002816", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002816", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002816", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002816", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002816")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::4::-::columns")
                    .mirror("-", "2:length_empty", "-")
                    .target("columns", "columns")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for columns reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for columns must reach the executed statement unchanged", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002817")
    void case_UTAPI_002817() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002817",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002817", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002817", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002817", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002817", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002817", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002817", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002817", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002817", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002817", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002817", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002817", "columns", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002817", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002817", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002817", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002817", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002817", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002817", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002817", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002817")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::4::-::columns")
                    .mirror("-", "3:length_min", "-")
                    .target("columns", "columns")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for columns reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for columns must reach the executed statement unchanged", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002818")
    void case_UTAPI_002818() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002818",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002818", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002818", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002818", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002818", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002818", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002818", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002818", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002818", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002818", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002818", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002818", "columns", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002818", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002818", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002818", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002818", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002818", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002818", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002818", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002818")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::4::-::columns")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("columns", "columns")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for columns reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for columns must reach the executed statement unchanged", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002819")
    void case_UTAPI_002819() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002819",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002819", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002819", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002819", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002819", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002819", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002819", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002819", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002819", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002819", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002819", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002819", "columns", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002819", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002819", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002819", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002819", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002819", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002819", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002819", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002819")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::4::-::columns")
                    .mirror("-", "5:length_max", "-")
                    .target("columns", "columns")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for columns reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for columns must reach the executed statement unchanged", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002820")
    void case_UTAPI_002820() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002820",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002820", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002820", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002820", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002820", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002820", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002820", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002820", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002820", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002820", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002820", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002820", "columns", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002820", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002820", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002820", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002820", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002820", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002820", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002820", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002820")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::4::-::columns")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("columns", "columns")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for columns reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for columns must reach the executed statement unchanged", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002821")
    void case_UTAPI_002821() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002821",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002821", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002821", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002821", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002821", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002821", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002821", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002821", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002821", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002821", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002821", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002821", "columns", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002821", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002821", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002821", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002821", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002821", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002821", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002821", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002821")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::4::-::columns")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("columns", "columns")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for columns reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for columns must reach the executed statement unchanged", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002822")
    void case_UTAPI_002822() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002822",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002822", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002822", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002822", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002822", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002822", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002822", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002822", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002822", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002822", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002822", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002822", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002822", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002822", "rows", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002822", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002822", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002822", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002822", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002822", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002822")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::5::-::rows")
                    .mirror("-", "1:length_null", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for rows reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the value generated for rows must reach the executed statement unchanged", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002823")
    void case_UTAPI_002823() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002823",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002823", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002823", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002823", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002823", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002823", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002823", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002823", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002823", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002823", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002823", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002823", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002823", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002823", "rows", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002823", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002823", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002823", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002823", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002823", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002823")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::5::-::rows")
                    .mirror("-", "2:length_empty", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for rows reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the value generated for rows must reach the executed statement unchanged", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002824")
    void case_UTAPI_002824() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002824",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002824", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002824", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002824", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002824", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002824", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002824", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002824", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002824", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002824", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002824", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002824", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002824", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002824", "rows", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002824", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002824", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002824", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002824", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002824", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002824")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::5::-::rows")
                    .mirror("-", "3:length_min", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for rows reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the value generated for rows must reach the executed statement unchanged", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002825")
    void case_UTAPI_002825() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002825",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002825", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002825", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002825", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002825", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002825", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002825", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002825", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002825", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002825", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002825", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002825", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002825", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002825", "rows", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002825", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002825", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002825", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002825", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002825", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002825")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::5::-::rows")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for rows reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the value generated for rows must reach the executed statement unchanged", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002826")
    void case_UTAPI_002826() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002826",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002826", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002826", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002826", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002826", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002826", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002826", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002826", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002826", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002826", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002826", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002826", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002826", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002826", "rows", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002826", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002826", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002826", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002826", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002826", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002826")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::5::-::rows")
                    .mirror("-", "5:length_max", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for rows reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the value generated for rows must reach the executed statement unchanged", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002827")
    void case_UTAPI_002827() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002827",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002827", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002827", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002827", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002827", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002827", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002827", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002827", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002827", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002827", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002827", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002827", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002827", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002827", "rows", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002827", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002827", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002827", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002827", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002827", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002827")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::5::-::rows")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for rows reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the value generated for rows must reach the executed statement unchanged", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002828")
    void case_UTAPI_002828() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002828",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002828", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002828", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002828", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002828", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002828", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002828", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002828", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002828", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002828", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002828", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002828", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-002828", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002828", "rows", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-002828", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-002828", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002828", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-002828", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002828", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002828")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::insertIntoCopyTable::2::ARG::5::-::rows")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for rows reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the value generated for rows must reach the executed statement unchanged", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

}

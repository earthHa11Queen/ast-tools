package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SqlExecuteResponseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SqlExecuteResponse#ofSelect.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SqlExecuteResponseOfSelectScenario {

    @Test
    @DisplayName("UTAPI-010396")
    void case_UTAPI_010396() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010396",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofSelect",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010396", "rows", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010396", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010396", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010396", "rows[]{value}", "NORMAL", "OBJECT", "Object")
                },
                OraclePlan.builder("UTAPI-010396")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofSelect::1::ARG::1::-::rows")
                    .mirror("-", "1:length_null", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofSelect")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getRows must carry the supplied rows", "getRows", "data:rows")
                    .check(CheckType.RETURN_FIELD_NULL, "a select result must not carry an error message", "getErrorMessage")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010397")
    void case_UTAPI_010397() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010397",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofSelect",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010397", "rows", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010397", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010397", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010397", "rows[]{value}", "NORMAL", "OBJECT", "Object")
                },
                OraclePlan.builder("UTAPI-010397")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofSelect::1::ARG::1::-::rows")
                    .mirror("-", "2:length_empty", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofSelect")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getRows must carry the supplied rows", "getRows", "data:rows")
                    .check(CheckType.RETURN_FIELD_NULL, "a select result must not carry an error message", "getErrorMessage")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010398")
    void case_UTAPI_010398() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010398",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofSelect",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010398", "rows", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010398", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010398", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010398", "rows[]{value}", "NORMAL", "OBJECT", "Object")
                },
                OraclePlan.builder("UTAPI-010398")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofSelect::1::ARG::1::-::rows")
                    .mirror("-", "3:length_min", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofSelect")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getRows must carry the supplied rows", "getRows", "data:rows")
                    .check(CheckType.RETURN_FIELD_NULL, "a select result must not carry an error message", "getErrorMessage")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010399")
    void case_UTAPI_010399() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010399",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofSelect",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010399", "rows", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010399", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010399", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010399", "rows[]{value}", "NORMAL", "OBJECT", "Object")
                },
                OraclePlan.builder("UTAPI-010399")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofSelect::1::ARG::1::-::rows")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofSelect")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getRows must carry the supplied rows", "getRows", "data:rows")
                    .check(CheckType.RETURN_FIELD_NULL, "a select result must not carry an error message", "getErrorMessage")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010400")
    void case_UTAPI_010400() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010400",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofSelect",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010400", "rows", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010400", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010400", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010400", "rows[]{value}", "NORMAL", "OBJECT", "Object")
                },
                OraclePlan.builder("UTAPI-010400")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofSelect::1::ARG::1::-::rows")
                    .mirror("-", "5:length_max", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofSelect")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getRows must carry the supplied rows", "getRows", "data:rows")
                    .check(CheckType.RETURN_FIELD_NULL, "a select result must not carry an error message", "getErrorMessage")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010401")
    void case_UTAPI_010401() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010401",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofSelect",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010401", "rows", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010401", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010401", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010401", "rows[]{value}", "NORMAL", "OBJECT", "Object")
                },
                OraclePlan.builder("UTAPI-010401")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofSelect::1::ARG::1::-::rows")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofSelect")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getRows must carry the supplied rows", "getRows", "data:rows")
                    .check(CheckType.RETURN_FIELD_NULL, "a select result must not carry an error message", "getErrorMessage")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010402")
    void case_UTAPI_010402() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010402",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofSelect",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010402", "rows", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010402", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010402", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010402", "rows[]{value}", "NORMAL", "OBJECT", "Object")
                },
                OraclePlan.builder("UTAPI-010402")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofSelect::1::ARG::1::-::rows")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofSelect")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getRows must carry the supplied rows", "getRows", "data:rows")
                    .check(CheckType.RETURN_FIELD_NULL, "a select result must not carry an error message", "getErrorMessage")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

}

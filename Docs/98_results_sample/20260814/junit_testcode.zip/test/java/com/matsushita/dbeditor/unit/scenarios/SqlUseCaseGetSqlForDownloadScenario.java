package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SqlUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SqlUseCase#getSqlForDownload.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SqlUseCaseGetSqlForDownloadScenario {

    @Test
    @DisplayName("UTAPI-012893")
    void case_UTAPI_012893() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012893",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "getSqlForDownload",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012893", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012893")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::getSqlForDownload::6::ARG::1::-::n")
                    .mirror("-", "1:length_null", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findById", "savedSqlRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findById must carry the value generated for n", "savedSqlRepository", "findById", "0", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012894")
    void case_UTAPI_012894() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012894",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "getSqlForDownload",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012894", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012894")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::getSqlForDownload::6::ARG::1::-::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findById", "savedSqlRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findById must carry the value generated for n", "savedSqlRepository", "findById", "0", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012895")
    void case_UTAPI_012895() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012895",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "getSqlForDownload",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012895", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012895")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::getSqlForDownload::6::ARG::1::-::n")
                    .mirror("-", "3:length_min", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findById", "savedSqlRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findById must carry the value generated for n", "savedSqlRepository", "findById", "0", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012896")
    void case_UTAPI_012896() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012896",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "getSqlForDownload",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012896", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012896")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::getSqlForDownload::6::ARG::1::-::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findById", "savedSqlRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findById must carry the value generated for n", "savedSqlRepository", "findById", "0", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012897")
    void case_UTAPI_012897() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012897",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "getSqlForDownload",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012897", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012897")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::getSqlForDownload::6::ARG::1::-::n")
                    .mirror("-", "5:length_max", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findById", "savedSqlRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findById must carry the value generated for n", "savedSqlRepository", "findById", "0", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012898")
    void case_UTAPI_012898() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012898",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "getSqlForDownload",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012898", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012898")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::getSqlForDownload::6::ARG::1::-::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findById", "savedSqlRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findById must carry the value generated for n", "savedSqlRepository", "findById", "0", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012899")
    void case_UTAPI_012899() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012899",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "getSqlForDownload",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012899", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012899")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::getSqlForDownload::6::ARG::1::-::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findById", "savedSqlRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findById must carry the value generated for n", "savedSqlRepository", "findById", "0", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012900")
    void case_UTAPI_012900() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012900",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "getSqlForDownload",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012900", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012900")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::getSqlForDownload::6::ARG::1::-::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findById", "savedSqlRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findById must carry the value generated for n", "savedSqlRepository", "findById", "0", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012901")
    void case_UTAPI_012901() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012901",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "getSqlForDownload",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012901", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012901")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::getSqlForDownload::6::ARG::1::-::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findById", "savedSqlRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findById must carry the value generated for n", "savedSqlRepository", "findById", "0", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012902")
    void case_UTAPI_012902() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012902",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "getSqlForDownload",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012902", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012902")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::getSqlForDownload::6::ARG::1::-::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findById", "savedSqlRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findById must carry the value generated for n", "savedSqlRepository", "findById", "0", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012903")
    void case_UTAPI_012903() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012903",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "getSqlForDownload",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012903", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012903")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::getSqlForDownload::6::ARG::1::-::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findById", "savedSqlRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findById must carry the value generated for n", "savedSqlRepository", "findById", "0", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

}

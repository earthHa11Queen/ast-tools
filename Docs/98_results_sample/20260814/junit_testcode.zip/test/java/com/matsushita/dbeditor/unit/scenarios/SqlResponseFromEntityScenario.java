package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SqlResponseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SqlResponse#fromEntity.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SqlResponseFromEntityScenario {

    @Test
    @DisplayName("UTAPI-010403")
    void case_UTAPI_010403() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010403",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010403", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010403", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010403", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010403", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010403", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010403", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010403", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010403")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "1:length_null", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010404")
    void case_UTAPI_010404() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010404",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010404", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010404", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010404", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010404", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010404", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010404", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010404", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010404")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "2:length_empty", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010405")
    void case_UTAPI_010405() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010405",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010405", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010405", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010405", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010405", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010405", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010405", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010405", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010405")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "3:length_min", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010406")
    void case_UTAPI_010406() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010406",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010406", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010406", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010406", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010406", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010406", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010406", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010406", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010406")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010407")
    void case_UTAPI_010407() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010407",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010407", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010407", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010407", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010407", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010407", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010407", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010407", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010407")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "5:length_max", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010408")
    void case_UTAPI_010408() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010408",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010408", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010408", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010408", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010408", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010408", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010408", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010408", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010408")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010409")
    void case_UTAPI_010409() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010409",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010409", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010409", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010409", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010409", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010409", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010409", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010409", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010409")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010410")
    void case_UTAPI_010410() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010410",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010410", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010410", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010410", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010410", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010410", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010410", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010410", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010410")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::contentSql")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010411")
    void case_UTAPI_010411() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010411",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010411", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010411", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010411", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010411", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010411", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010411", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010411", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010411")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::contentSql")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010412")
    void case_UTAPI_010412() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010412",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010412", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010412", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010412", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010412", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010412", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010412", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010412", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010412")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::contentSql")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010413")
    void case_UTAPI_010413() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010413",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010413", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010413", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010413", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010413", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010413", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010413", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010413", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010413")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010414")
    void case_UTAPI_010414() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010414",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010414", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010414", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010414", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010414", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010414", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010414", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010414", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010414")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010415")
    void case_UTAPI_010415() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010415",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010415", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010415", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010415", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010415", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010415", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010415", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010415", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010415")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "56:space")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010416")
    void case_UTAPI_010416() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010416",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010416", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010416", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010416", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010416", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010416", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010416", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010416", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010416")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010417")
    void case_UTAPI_010417() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010417",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010417", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010417", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010417", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010417", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010417", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010417", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010417", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010417")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010418")
    void case_UTAPI_010418() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010418",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010418", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010418", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010418", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010418", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010418", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010418", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010418", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010418")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "59:tab")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010419")
    void case_UTAPI_010419() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010419",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010419", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010419", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010419", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010419", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010419", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010419", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010419", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010419")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "60:control_character_null")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010420")
    void case_UTAPI_010420() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010420",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010420", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010420", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010420", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010420", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010420", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010420", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010420", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010420")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010421")
    void case_UTAPI_010421() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010421",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010421", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010421", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010421", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010421", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010421", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010421", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010421", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010421")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010422")
    void case_UTAPI_010422() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010422",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010422", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010422", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010422", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010422", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010422", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010422", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010422", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010422")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.contentSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010423")
    void case_UTAPI_010423() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010423",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010423", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010423", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010423", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010423", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010423", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010423", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010423", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010423")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010424")
    void case_UTAPI_010424() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010424",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010424", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010424", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010424", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010424", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010424", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010424", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010424", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010424")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010425")
    void case_UTAPI_010425() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010425",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010425", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010425", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010425", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010425", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010425", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010425", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010425", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010425")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010426")
    void case_UTAPI_010426() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010426",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010426", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010426", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010426", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010426", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010426", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010426", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010426", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010426")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010427")
    void case_UTAPI_010427() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010427",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010427", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010427", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010427", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010427", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010427", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010427", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010427", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010427")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010428")
    void case_UTAPI_010428() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010428",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010428", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010428", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010428", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010428", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010428", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010428", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010428", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010428")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010429")
    void case_UTAPI_010429() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010429",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010429", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010429", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010429", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010429", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010429", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010429", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010429", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010429")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010430")
    void case_UTAPI_010430() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010430",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010430", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010430", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010430", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010430", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010430", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010430", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010430", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010430")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010431")
    void case_UTAPI_010431() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010431",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010431", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010431", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010431", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010431", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010431", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010431", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010431", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010431")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010432")
    void case_UTAPI_010432() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010432",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010432", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010432", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010432", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010432", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010432", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010432", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010432", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010432")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010433")
    void case_UTAPI_010433() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010433",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010433", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010433", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010433", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010433", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010433", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010433", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010433", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010433")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010434")
    void case_UTAPI_010434() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010434",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010434", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010434", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010434", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010434", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010434", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010434", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010434", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010434")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010435")
    void case_UTAPI_010435() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010435",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010435", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010435", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010435", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010435", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010435", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010435", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010435", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010435")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010436")
    void case_UTAPI_010436() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010436",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010436", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010436", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010436", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010436", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010436", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010436", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010436", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010436")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010437")
    void case_UTAPI_010437() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010437",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010437", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010437", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010437", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010437", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010437", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010437", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010437", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010437")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010438")
    void case_UTAPI_010438() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010438",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010438", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010438", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010438", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010438", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010438", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010438", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010438", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010438")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010439")
    void case_UTAPI_010439() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010439",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010439", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010439", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010439", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010439", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010439", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010439", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010439", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010439")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010440")
    void case_UTAPI_010440() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010440",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010440", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010440", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010440", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010440", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010440", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010440", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010440", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010440")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010441")
    void case_UTAPI_010441() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010441",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010441", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010441", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010441", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010441", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010441", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010441", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010441", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010441")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.dbConnectionId survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010442")
    void case_UTAPI_010442() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010442",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010442", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010442", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010442", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010442", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010442", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010442", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010442", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010442")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::n")
                    .mirror("-", "1:length_null", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010443")
    void case_UTAPI_010443() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010443",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010443", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010443", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010443", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010443", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010443", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010443", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010443", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010443")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010444")
    void case_UTAPI_010444() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010444",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010444", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010444", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010444", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010444", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010444", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010444", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010444", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010444")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::n")
                    .mirror("-", "3:length_min", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010445")
    void case_UTAPI_010445() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010445",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010445", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010445", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010445", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010445", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010445", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010445", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010445", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010445")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010446")
    void case_UTAPI_010446() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010446",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010446", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010446", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010446", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010446", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010446", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010446", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010446", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010446")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::n")
                    .mirror("-", "5:length_max", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010447")
    void case_UTAPI_010447() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010447",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010447", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010447", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010447", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010447", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010447", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010447", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010447", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010447")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010448")
    void case_UTAPI_010448() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010448",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010448", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010448", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010448", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010448", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010448", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010448", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010448", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010448")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010449")
    void case_UTAPI_010449() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010449",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010449", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010449", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010449", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010449", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010449", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010449", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010449", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010449")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010450")
    void case_UTAPI_010450() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010450",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010450", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010450", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010450", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010450", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010450", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010450", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010450", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010450")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010451")
    void case_UTAPI_010451() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010451",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010451", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010451", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010451", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010451", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010451", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010451", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010451", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010451")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010452")
    void case_UTAPI_010452() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010452",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010452", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010452", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010452", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010452", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010452", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010452", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010452", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010452")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010453")
    void case_UTAPI_010453() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010453",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010453", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010453", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010453", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010453", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010453", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010453", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010453", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010453")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "1:length_null", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010454")
    void case_UTAPI_010454() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010454",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010454", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010454", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010454", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010454", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010454", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010454", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010454", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010454")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "2:length_empty", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010455")
    void case_UTAPI_010455() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010455",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010455", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010455", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010455", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010455", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010455", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010455", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010455", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010455")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "3:length_min", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010456")
    void case_UTAPI_010456() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010456",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010456", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010456", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010456", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010456", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010456", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010456", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010456", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010456")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010457")
    void case_UTAPI_010457() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010457",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010457", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010457", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010457", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010457", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010457", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010457", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010457", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010457")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "5:length_max", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010458")
    void case_UTAPI_010458() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010458",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010458", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010458", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010458", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010458", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010458", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010458", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010458", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010458")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010459")
    void case_UTAPI_010459() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010459",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010459", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010459", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010459", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010459", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010459", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010459", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010459", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010459")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010460")
    void case_UTAPI_010460() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010460",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010460", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010460", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010460", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010460", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010460", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010460", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010460", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010460")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::titleSql")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010461")
    void case_UTAPI_010461() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010461",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010461", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010461", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010461", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010461", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010461", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010461", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010461", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010461")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::titleSql")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010462")
    void case_UTAPI_010462() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010462",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010462", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010462", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010462", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010462", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010462", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010462", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010462", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010462")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::titleSql")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010463")
    void case_UTAPI_010463() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010463",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010463", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010463", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010463", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010463", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010463", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010463", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010463", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010463")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::titleSql")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010464")
    void case_UTAPI_010464() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010464",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010464", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010464", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010464", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010464", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010464", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010464", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010464", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010464")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010465")
    void case_UTAPI_010465() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010465",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010465", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010465", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010465", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010465", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010465", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010465", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010465", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010465")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010466")
    void case_UTAPI_010466() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010466",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010466", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010466", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010466", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010466", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010466", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010466", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010466", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010466")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "56:space")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010467")
    void case_UTAPI_010467() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010467",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010467", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010467", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010467", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010467", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010467", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010467", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010467", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010467")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010468")
    void case_UTAPI_010468() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010468",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010468", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010468", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010468", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010468", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010468", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010468", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010468", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010468")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010469")
    void case_UTAPI_010469() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010469",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010469", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010469", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010469", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010469", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010469", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010469", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010469", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010469")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "59:tab")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010470")
    void case_UTAPI_010470() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010470",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010470", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010470", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010470", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010470", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010470", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010470", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010470", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010470")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "60:control_character_null")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010471")
    void case_UTAPI_010471() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010471",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010471", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010471", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010471", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010471", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010471", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010471", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010471", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010471")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010472")
    void case_UTAPI_010472() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010472",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010472", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010472", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010472", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010472", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010472", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010472", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010472", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010472")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010473")
    void case_UTAPI_010473() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010473",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010473", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010473", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010473", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010473", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010473", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010473", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010473", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010473")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.titleSql survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010474")
    void case_UTAPI_010474() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010474",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010474", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010474", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010474", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010474", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010474", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010474", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010474", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010474")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose updatedTimestamp", "getUpdatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010475")
    void case_UTAPI_010475() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010475",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010475", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010475", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010475", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010475", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010475", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010475", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010475", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010475")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose updatedTimestamp", "getUpdatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010476")
    void case_UTAPI_010476() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010476",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010476", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010476", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010476", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010476", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010476", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010476", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010476", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010476")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose updatedTimestamp", "getUpdatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010477")
    void case_UTAPI_010477() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010477",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010477", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010477", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010477", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010477", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010477", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010477", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010477", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010477")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose updatedTimestamp", "getUpdatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010478")
    void case_UTAPI_010478() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010478",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010478", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010478", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010478", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010478", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010478", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010478", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010478", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010478")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose updatedTimestamp", "getUpdatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010479")
    void case_UTAPI_010479() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010479",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010479", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010479", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010479", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010479", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010479", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010479", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010479", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010479")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose updatedTimestamp", "getUpdatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010480")
    void case_UTAPI_010480() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010480",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010480", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010480", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010480", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010480", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010480", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010480", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010480", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010480")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose updatedTimestamp", "getUpdatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010481")
    void case_UTAPI_010481() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010481",
                "com.matsushita.dbeditor.dto.outdto.SqlResponse",
                "fromEntity",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010481", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-010481", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010481", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010481", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010481", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010481", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010481", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-010481")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlResponse.java::SqlResponse::fromEntity::1::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by SqlResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for sql.updatedTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry sql.n", "getN", "data:sql.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry sql.dbConnectionId", "getConnectionId", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry sql.titleSql", "getTitle", "data:sql.titleSql")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry sql.contentSql", "getContent", "data:sql.contentSql")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose updatedTimestamp", "getUpdatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new SqlResponseWrapper());
    }

}

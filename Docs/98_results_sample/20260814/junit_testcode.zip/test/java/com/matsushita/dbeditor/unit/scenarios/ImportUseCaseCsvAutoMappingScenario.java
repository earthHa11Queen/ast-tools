package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ImportUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ImportUseCase#csvAutoMapping.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ImportUseCaseCsvAutoMappingScenario {

    @Test
    @DisplayName("UTAPI-012401")
    void case_UTAPI_012401() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012401",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012401", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012401", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012401", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012401", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012401")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012402")
    void case_UTAPI_012402() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012402",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012402", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012402", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012402", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012402", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012402")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012403")
    void case_UTAPI_012403() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012403",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012403", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012403", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012403", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012403", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012403")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012404")
    void case_UTAPI_012404() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012404",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012404", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012404", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012404", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012404", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012404")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012405")
    void case_UTAPI_012405() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012405",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012405", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012405", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012405", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012405", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012405")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012406")
    void case_UTAPI_012406() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012406",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012406", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012406", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012406", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012406", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012406")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012407")
    void case_UTAPI_012407() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012407",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012407", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012407", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012407", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012407", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012407")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012408")
    void case_UTAPI_012408() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012408",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012408", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012408", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012408", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012408", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012408")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012409")
    void case_UTAPI_012409() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012409",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012409", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012409", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012409", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012409", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012409")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012410")
    void case_UTAPI_012410() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012410",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012410", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012410", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012410", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012410", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012410")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012411")
    void case_UTAPI_012411() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012411",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012411", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012411", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012411", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012411", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012411")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012412")
    void case_UTAPI_012412() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012412",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012412", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012412", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012412", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012412", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012412")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::2::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012413")
    void case_UTAPI_012413() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012413",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012413", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012413", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012413", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012413", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012413")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::2::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012414")
    void case_UTAPI_012414() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012414",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012414", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012414", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012414", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012414", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012414")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::2::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012415")
    void case_UTAPI_012415() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012415",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012415", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012415", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012415", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012415", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012415")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::2::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012416")
    void case_UTAPI_012416() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012416",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012416", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012416", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012416", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012416", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012416")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::2::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012417")
    void case_UTAPI_012417() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012417",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012417", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012417", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012417", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012417", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012417")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::2::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012418")
    void case_UTAPI_012418() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012418",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012418", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012418", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012418", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012418", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012418")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::2::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012419")
    void case_UTAPI_012419() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012419",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012419", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012419", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012419", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012419", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012419")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::2::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012420")
    void case_UTAPI_012420() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012420",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012420", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012420", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012420", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012420", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012420")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::2::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012421")
    void case_UTAPI_012421() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012421",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012421", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012421", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012421", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012421", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012421")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::2::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012422")
    void case_UTAPI_012422() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012422",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012422", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012422", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012422", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012422", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012422")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::2::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012423")
    void case_UTAPI_012423() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012423",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012423", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012423", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012423", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012423", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012423")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::2::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012424")
    void case_UTAPI_012424() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012424",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012424", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012424", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012424", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012424", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012424")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::2::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012425")
    void case_UTAPI_012425() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012425",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012425", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012425", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012425", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012425", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012425")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::2::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012426")
    void case_UTAPI_012426() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012426",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012426", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012426", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012426", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012426", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012426")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::2::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012427")
    void case_UTAPI_012427() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012427",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012427", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012427", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012427", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012427", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012427")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::2::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012428")
    void case_UTAPI_012428() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012428",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012428", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012428", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012428", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012428", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012428")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::2::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012429")
    void case_UTAPI_012429() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012429",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012429", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012429", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012429", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012429", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012429")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::2::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012430")
    void case_UTAPI_012430() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012430",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012430", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012430", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012430", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012430", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012430")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::2::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012431")
    void case_UTAPI_012431() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012431",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012431", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012431", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012431", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012431", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012431")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::2::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012432")
    void case_UTAPI_012432() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012432",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012432", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012432", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012432", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012432", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012432")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::2::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012433")
    void case_UTAPI_012433() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012433",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012433", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012433", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012433", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012433", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012433")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::3::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012434")
    void case_UTAPI_012434() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012434",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012434", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012434", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012434", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012434", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012434")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::3::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012435")
    void case_UTAPI_012435() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012435",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012435", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012435", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012435", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012435", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012435")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::3::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012436")
    void case_UTAPI_012436() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012436",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012436", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012436", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012436", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012436", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012436")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::3::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012437")
    void case_UTAPI_012437() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012437",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012437", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012437", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012437", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012437", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012437")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::3::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012438")
    void case_UTAPI_012438() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012438",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012438", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012438", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012438", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012438", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012438")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::3::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012439")
    void case_UTAPI_012439() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012439",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012439", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012439", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012439", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012439", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012439")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::3::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012440")
    void case_UTAPI_012440() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012440",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012440", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012440", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012440", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012440", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012440")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::3::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012441")
    void case_UTAPI_012441() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012441",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012441", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012441", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012441", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012441", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012441")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::3::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012442")
    void case_UTAPI_012442() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012442",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012442", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012442", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012442", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012442", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012442")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::3::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012443")
    void case_UTAPI_012443() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012443",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012443", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012443", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012443", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012443", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012443")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::3::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012444")
    void case_UTAPI_012444() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012444",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012444", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012444", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012444", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012444", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012444")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::3::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012445")
    void case_UTAPI_012445() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012445",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012445", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012445", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012445", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012445", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012445")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::3::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012446")
    void case_UTAPI_012446() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012446",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012446", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012446", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012446", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012446", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012446")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::3::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012447")
    void case_UTAPI_012447() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012447",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012447", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012447", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012447", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012447", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012447")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::3::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012448")
    void case_UTAPI_012448() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012448",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012448", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012448", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012448", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012448", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012448")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::3::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012449")
    void case_UTAPI_012449() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012449",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012449", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012449", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012449", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012449", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012449")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::3::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012450")
    void case_UTAPI_012450() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012450",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012450", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012450", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012450", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012450", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012450")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::3::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012451")
    void case_UTAPI_012451() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012451",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012451", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012451", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012451", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012451", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012451")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::3::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012452")
    void case_UTAPI_012452() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012452",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012452", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012452", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012452", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012452", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012452")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::3::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012453")
    void case_UTAPI_012453() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012453",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012453", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012453", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012453", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012453", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012453")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::3::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the proposal must report the header of the uploaded document", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012454")
    void case_UTAPI_012454() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012454",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012454", "file", "TARGET", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012454", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012454", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012454", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012454")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::4::-::file")
                    .mirror("-", "1:length_null", "-")
                    .target("file", "file")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for file is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_REQUIRED, "an absent upload cannot be processed", "java.lang.RuntimeException", "data:file")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012455")
    void case_UTAPI_012455() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012455",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "csvAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012455", "file", "TARGET", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012455", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012455", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012455", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012455")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::csvAutoMapping::1::ARG::4::-::file")
                    .mirror("-", "2:length_empty", "-")
                    .target("file", "file")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for file is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SAME, "the uploaded document must be handed on as it was received", "connectionSettingRepository", "findById", "0", "data:file")
                    .build()),
            new ImportUseCaseWrapper());
    }

}

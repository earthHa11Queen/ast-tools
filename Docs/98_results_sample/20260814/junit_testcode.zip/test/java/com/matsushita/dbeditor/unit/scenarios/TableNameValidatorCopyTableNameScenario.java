package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableNameValidatorWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableNameValidator#copyTableName.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableNameValidatorCopyTableNameScenario {

    @Test
    @DisplayName("UTAPI-010767")
    void case_UTAPI_010767() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010767",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "copyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010767", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010767")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::copyTableName::4::ARG::1::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by copyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010768")
    void case_UTAPI_010768() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010768",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "copyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010768", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010768")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::copyTableName::4::ARG::1::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by copyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010769")
    void case_UTAPI_010769() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010769",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "copyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010769", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010769")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::copyTableName::4::ARG::1::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by copyTableName")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010770")
    void case_UTAPI_010770() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010770",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "copyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010770", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010770")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::copyTableName::4::ARG::1::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by copyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010771")
    void case_UTAPI_010771() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010771",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "copyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010771", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010771")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::copyTableName::4::ARG::1::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by copyTableName")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010772")
    void case_UTAPI_010772() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010772",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "copyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010772", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010772")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::copyTableName::4::ARG::1::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by copyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010773")
    void case_UTAPI_010773() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010773",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "copyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010773", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010773")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::copyTableName::4::ARG::1::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by copyTableName")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010774")
    void case_UTAPI_010774() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010774",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "copyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010774", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010774")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::copyTableName::4::ARG::1::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by copyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010775")
    void case_UTAPI_010775() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010775",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "copyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010775", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010775")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::copyTableName::4::ARG::1::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by copyTableName")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010776")
    void case_UTAPI_010776() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010776",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "copyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010776", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010776")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::copyTableName::4::ARG::1::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by copyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010777")
    void case_UTAPI_010777() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010777",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "copyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010777", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010777")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::copyTableName::4::ARG::1::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by copyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010778")
    void case_UTAPI_010778() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010778",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "copyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010778", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010778")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::copyTableName::4::ARG::1::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by copyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010779")
    void case_UTAPI_010779() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010779",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "copyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010779", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010779")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::copyTableName::4::ARG::1::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by copyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010780")
    void case_UTAPI_010780() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010780",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "copyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010780", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010780")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::copyTableName::4::ARG::1::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by copyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010781")
    void case_UTAPI_010781() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010781",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "copyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010781", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010781")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::copyTableName::4::ARG::1::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by copyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010782")
    void case_UTAPI_010782() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010782",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "copyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010782", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010782")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::copyTableName::4::ARG::1::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by copyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010783")
    void case_UTAPI_010783() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010783",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "copyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010783", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010783")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::copyTableName::4::ARG::1::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by copyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010784")
    void case_UTAPI_010784() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010784",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "copyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010784", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010784")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::copyTableName::4::ARG::1::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by copyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010785")
    void case_UTAPI_010785() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010785",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "copyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010785", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010785")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::copyTableName::4::ARG::1::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by copyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010786")
    void case_UTAPI_010786() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010786",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "copyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010786", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010786")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::copyTableName::4::ARG::1::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by copyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010787")
    void case_UTAPI_010787() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010787",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "copyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010787", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010787")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::copyTableName::4::ARG::1::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by copyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SqlExecuteResponseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SqlExecuteResponse#ofDml.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SqlExecuteResponseOfDmlScenario {

    @Test
    @DisplayName("UTAPI-010364")
    void case_UTAPI_010364() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010364",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofDml",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("affectedRows", "int", "affectedRows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010364", "affectedRows", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010364")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofDml::2::ARG::1::-::affectedRows")
                    .mirror("-", "1:length_null", "-")
                    .target("affectedRows", "affectedRows")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofDml")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getAffectedRows must carry the supplied count", "getAffectedRows", "data:affectedRows")
                    .check(CheckType.RETURN_FIELD_NULL, "a DML result must not carry an error message", "getErrorMessage")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010365")
    void case_UTAPI_010365() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010365",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofDml",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("affectedRows", "int", "affectedRows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010365", "affectedRows", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010365")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofDml::2::ARG::1::-::affectedRows")
                    .mirror("-", "2:length_empty", "-")
                    .target("affectedRows", "affectedRows")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofDml")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getAffectedRows must carry the supplied count", "getAffectedRows", "data:affectedRows")
                    .check(CheckType.RETURN_FIELD_NULL, "a DML result must not carry an error message", "getErrorMessage")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010366")
    void case_UTAPI_010366() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010366",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofDml",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("affectedRows", "int", "affectedRows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010366", "affectedRows", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010366")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofDml::2::ARG::1::-::affectedRows")
                    .mirror("-", "3:length_min", "-")
                    .target("affectedRows", "affectedRows")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofDml")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getAffectedRows must carry the supplied count", "getAffectedRows", "data:affectedRows")
                    .check(CheckType.RETURN_FIELD_NULL, "a DML result must not carry an error message", "getErrorMessage")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010367")
    void case_UTAPI_010367() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010367",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofDml",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("affectedRows", "int", "affectedRows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010367", "affectedRows", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010367")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofDml::2::ARG::1::-::affectedRows")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("affectedRows", "affectedRows")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofDml")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getAffectedRows must carry the supplied count", "getAffectedRows", "data:affectedRows")
                    .check(CheckType.RETURN_FIELD_NULL, "a DML result must not carry an error message", "getErrorMessage")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010368")
    void case_UTAPI_010368() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010368",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofDml",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("affectedRows", "int", "affectedRows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010368", "affectedRows", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010368")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofDml::2::ARG::1::-::affectedRows")
                    .mirror("-", "5:length_max", "-")
                    .target("affectedRows", "affectedRows")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofDml")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getAffectedRows must carry the supplied count", "getAffectedRows", "data:affectedRows")
                    .check(CheckType.RETURN_FIELD_NULL, "a DML result must not carry an error message", "getErrorMessage")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010369")
    void case_UTAPI_010369() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010369",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofDml",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("affectedRows", "int", "affectedRows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010369", "affectedRows", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010369")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofDml::2::ARG::1::-::affectedRows")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("affectedRows", "affectedRows")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofDml")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getAffectedRows must carry the supplied count", "getAffectedRows", "data:affectedRows")
                    .check(CheckType.RETURN_FIELD_NULL, "a DML result must not carry an error message", "getErrorMessage")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010370")
    void case_UTAPI_010370() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010370",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofDml",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("affectedRows", "int", "affectedRows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010370", "affectedRows", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010370")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofDml::2::ARG::1::-::affectedRows")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("affectedRows", "affectedRows")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofDml")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getAffectedRows must carry the supplied count", "getAffectedRows", "data:affectedRows")
                    .check(CheckType.RETURN_FIELD_NULL, "a DML result must not carry an error message", "getErrorMessage")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010371")
    void case_UTAPI_010371() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010371",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofDml",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("affectedRows", "int", "affectedRows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010371", "affectedRows", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010371")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofDml::2::ARG::1::-::affectedRows")
                    .mirror("46:hw_integer", "-", "-")
                    .target("affectedRows", "affectedRows")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofDml")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getAffectedRows must carry the supplied count", "getAffectedRows", "data:affectedRows")
                    .check(CheckType.RETURN_FIELD_NULL, "a DML result must not carry an error message", "getErrorMessage")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010372")
    void case_UTAPI_010372() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010372",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofDml",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("affectedRows", "int", "affectedRows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010372", "affectedRows", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010372")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofDml::2::ARG::1::-::affectedRows")
                    .mirror("-", "-", "12:integer_positive")
                    .target("affectedRows", "affectedRows")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofDml")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getAffectedRows must carry the supplied count", "getAffectedRows", "data:affectedRows")
                    .check(CheckType.RETURN_FIELD_NULL, "a DML result must not carry an error message", "getErrorMessage")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010373")
    void case_UTAPI_010373() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010373",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofDml",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("affectedRows", "int", "affectedRows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010373", "affectedRows", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010373")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofDml::2::ARG::1::-::affectedRows")
                    .mirror("-", "-", "13:integer_negative")
                    .target("affectedRows", "affectedRows")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofDml")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getAffectedRows must carry the supplied count", "getAffectedRows", "data:affectedRows")
                    .check(CheckType.RETURN_FIELD_NULL, "a DML result must not carry an error message", "getErrorMessage")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010374")
    void case_UTAPI_010374() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010374",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofDml",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("affectedRows", "int", "affectedRows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010374", "affectedRows", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010374")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofDml::2::ARG::1::-::affectedRows")
                    .mirror("-", "-", "14:integer_zero")
                    .target("affectedRows", "affectedRows")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofDml")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getAffectedRows must carry the supplied count", "getAffectedRows", "data:affectedRows")
                    .check(CheckType.RETURN_FIELD_NULL, "a DML result must not carry an error message", "getErrorMessage")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

}

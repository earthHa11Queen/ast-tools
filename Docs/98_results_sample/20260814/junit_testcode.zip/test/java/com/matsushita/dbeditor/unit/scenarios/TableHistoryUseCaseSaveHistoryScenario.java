package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableHistoryUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableHistoryUseCase#saveHistory.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableHistoryUseCaseSaveHistoryScenario {

    @Test
    @DisplayName("UTAPI-013209")
    void case_UTAPI_013209() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013209",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013209", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013209", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013209", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013209", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013209", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013209", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013209", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013209")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013210")
    void case_UTAPI_013210() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013210",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013210", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013210", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013210", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013210", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013210", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013210", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013210", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013210")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013211")
    void case_UTAPI_013211() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013211",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013211", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013211", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013211", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013211", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013211", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013211", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013211", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013211")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013212")
    void case_UTAPI_013212() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013212",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013212", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013212", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013212", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013212", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013212", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013212", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013212", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013212")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013213")
    void case_UTAPI_013213() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013213",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013213", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013213", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013213", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013213", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013213", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013213", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013213", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013213")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013214")
    void case_UTAPI_013214() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013214",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013214", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013214", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013214", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013214", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013214", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013214", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013214", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013214")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013215")
    void case_UTAPI_013215() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013215",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013215", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013215", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013215", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013215", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013215", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013215", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013215", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013215")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013216")
    void case_UTAPI_013216() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013216",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013216", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013216", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013216", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013216", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013216", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013216", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013216", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013216")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013217")
    void case_UTAPI_013217() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013217",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013217", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013217", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013217", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013217", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013217", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013217", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013217", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013217")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013218")
    void case_UTAPI_013218() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013218",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013218", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013218", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013218", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013218", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013218", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013218", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013218", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013218")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013219")
    void case_UTAPI_013219() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013219",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013219", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013219", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013219", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013219", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013219", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013219", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013219", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013219")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013220")
    void case_UTAPI_013220() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013220",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013220", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013220", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013220", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013220", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013220", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013220", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013220", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013220")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013221")
    void case_UTAPI_013221() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013221",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013221", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013221", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013221", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013221", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013221", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013221", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013221", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013221")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013222")
    void case_UTAPI_013222() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013222",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013222", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013222", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013222", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013222", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013222", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013222", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013222", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013222")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013223")
    void case_UTAPI_013223() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013223",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013223", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013223", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013223", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013223", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013223", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013223", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013223", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013223")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013224")
    void case_UTAPI_013224() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013224",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013224", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013224", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013224", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013224", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013224", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013224", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013224", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013224")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013225")
    void case_UTAPI_013225() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013225",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013225", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013225", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013225", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013225", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013225", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013225", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013225", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013225")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013226")
    void case_UTAPI_013226() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013226",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013226", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013226", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013226", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013226", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013226", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013226", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013226", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013226")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013227")
    void case_UTAPI_013227() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013227",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013227", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013227", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013227", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013227", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013227", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013227", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013227", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013227")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013228")
    void case_UTAPI_013228() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013228",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013228", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013228", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013228", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013228", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013228", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013228", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013228", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013228")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013229")
    void case_UTAPI_013229() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013229",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013229", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013229", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013229", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013229", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013229", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013229", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013229", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013229")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013230")
    void case_UTAPI_013230() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013230",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013230", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013230", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013230", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013230", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013230", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013230", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013230", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013230")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013231")
    void case_UTAPI_013231() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013231",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013231", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013231", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013231", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013231", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013231", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013231", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013231", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013231")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013232")
    void case_UTAPI_013232() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013232",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013232", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013232", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013232", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013232", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013232", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013232", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013232", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013232")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013233")
    void case_UTAPI_013233() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013233",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013233", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013233", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013233", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013233", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013233", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013233", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013233", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013233")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013234")
    void case_UTAPI_013234() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013234",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013234", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013234", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013234", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013234", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013234", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013234", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013234", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013234")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013235")
    void case_UTAPI_013235() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013235",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013235", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013235", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013235", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013235", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013235", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013235", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013235", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013235")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013236")
    void case_UTAPI_013236() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013236",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013236", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013236", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013236", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013236", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013236", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013236", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013236", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013236")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013237")
    void case_UTAPI_013237() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013237",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013237", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013237", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013237", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013237", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013237", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013237", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013237", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013237")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013238")
    void case_UTAPI_013238() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013238",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013238", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013238", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013238", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013238", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013238", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013238", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013238", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013238")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013239")
    void case_UTAPI_013239() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013239",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013239", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013239", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013239", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013239", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013239", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013239", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013239", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013239")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013240")
    void case_UTAPI_013240() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013240",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013240", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013240", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013240", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013240", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013240", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013240", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013240", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013240")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013241")
    void case_UTAPI_013241() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013241",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013241", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013241", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013241", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013241", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013241", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013241", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013241", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013241")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013242")
    void case_UTAPI_013242() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013242",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013242", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013242", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013242", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013242", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013242", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013242", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013242", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013242")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013243")
    void case_UTAPI_013243() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013243",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013243", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013243", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013243", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013243", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013243", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013243", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013243", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013243")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013244")
    void case_UTAPI_013244() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013244",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013244", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013244", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013244", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013244", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013244", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013244", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013244", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013244")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013245")
    void case_UTAPI_013245() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013245",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013245", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013245", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013245", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013245", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013245", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013245", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013245", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013245")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013246")
    void case_UTAPI_013246() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013246",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013246", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013246", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013246", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013246", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013246", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013246", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013246", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013246")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013247")
    void case_UTAPI_013247() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013247",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013247", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013247", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013247", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013247", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013247", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013247", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013247", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013247")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013248")
    void case_UTAPI_013248() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013248",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013248", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013248", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013248", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013248", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013248", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013248", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013248", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013248")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013249")
    void case_UTAPI_013249() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013249",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013249", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013249", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013249", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013249", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013249", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013249", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013249", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013249")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013250")
    void case_UTAPI_013250() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013250",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013250", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013250", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013250", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013250", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013250", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013250", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013250", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013250")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013251")
    void case_UTAPI_013251() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013251",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013251", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013251", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013251", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013251", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013251", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013251", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013251", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013251")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013252")
    void case_UTAPI_013252() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013252",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013252", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013252", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013252", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013252", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013252", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013252", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013252", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013252")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013253")
    void case_UTAPI_013253() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013253",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013253", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013253", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013253", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013253", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013253", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013253", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013253", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013253")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013254")
    void case_UTAPI_013254() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013254",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013254", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013254", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013254", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013254", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013254", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013254", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013254", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013254")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013255")
    void case_UTAPI_013255() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013255",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013255", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013255", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013255", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013255", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013255", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013255", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013255", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013255")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013256")
    void case_UTAPI_013256() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013256",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013256", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013256", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013256", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013256", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013256", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013256", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013256", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013256")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013257")
    void case_UTAPI_013257() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013257",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013257", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013257", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013257", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013257", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013257", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013257", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013257", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013257")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013258")
    void case_UTAPI_013258() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013258",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013258", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013258", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013258", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013258", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013258", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013258", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013258", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013258")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013259")
    void case_UTAPI_013259() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013259",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013259", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013259", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013259", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013259", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013259", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013259", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013259", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013259")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013260")
    void case_UTAPI_013260() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013260",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013260", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013260", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013260", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013260", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013260", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013260", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013260", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013260")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013261")
    void case_UTAPI_013261() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013261",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013261", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013261", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013261", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013261", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013261", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013261", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013261", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013261")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013262")
    void case_UTAPI_013262() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013262",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013262", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013262", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013262", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013262", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013262", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013262", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013262", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013262")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::4::-::records")
                    .mirror("-", "1:length_null", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for records is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013263")
    void case_UTAPI_013263() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013263",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013263", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013263", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013263", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013263", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013263", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013263", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013263", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013263")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::4::-::records")
                    .mirror("-", "2:length_empty", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for records is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013264")
    void case_UTAPI_013264() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013264",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013264", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013264", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013264", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013264", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013264", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013264", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013264", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013264")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::4::-::records")
                    .mirror("-", "3:length_min", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for records is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013265")
    void case_UTAPI_013265() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013265",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013265", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013265", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013265", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013265", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013265", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013265", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013265", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013265")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::4::-::records")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for records is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013266")
    void case_UTAPI_013266() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013266",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013266", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013266", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013266", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013266", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013266", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013266", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013266", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013266")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::4::-::records")
                    .mirror("-", "5:length_max", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for records is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013267")
    void case_UTAPI_013267() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013267",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013267", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013267", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013267", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013267", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013267", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013267", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013267", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013267")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::4::-::records")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for records is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013268")
    void case_UTAPI_013268() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013268",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013268", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013268", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013268", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013268", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013268", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013268", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013268", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013268")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::saveHistory::1::ARG::4::-::records")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.saveHistory")
                    .expected("the value generated for records is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.saveHistory", "tableHistoryRepository", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.saveHistory must carry the value generated for schemaName", "tableHistoryRepository", "saveHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.saveHistory must carry the value generated for tableName", "tableHistoryRepository", "saveHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.saveHistory must carry the value generated for records", "tableHistoryRepository", "saveHistory", "3", "data:records")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableHistoryRepository.saveHistory", "stub:tableHistoryRepository#saveHistory")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

}

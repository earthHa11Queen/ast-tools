package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ConnectionControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ConnectionController#delete.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ConnectionControllerDeleteScenario {

    @Test
    @DisplayName("UTAPI-000116")
    void case_UTAPI_000116() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000116",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "delete",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000116", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000116")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::delete::5::ARG::1::-::id")
                    .mirror("-", "1:length_null", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.delete")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.delete", "connectionUseCase", "delete")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.delete must carry the value generated for id", "connectionUseCase", "delete", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000117")
    void case_UTAPI_000117() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000117",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "delete",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000117", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000117")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::delete::5::ARG::1::-::id")
                    .mirror("-", "2:length_empty", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.delete")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.delete", "connectionUseCase", "delete")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.delete must carry the value generated for id", "connectionUseCase", "delete", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000118")
    void case_UTAPI_000118() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000118",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "delete",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000118", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000118")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::delete::5::ARG::1::-::id")
                    .mirror("-", "3:length_min", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.delete")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.delete", "connectionUseCase", "delete")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.delete must carry the value generated for id", "connectionUseCase", "delete", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000119")
    void case_UTAPI_000119() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000119",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "delete",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000119", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000119")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::delete::5::ARG::1::-::id")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.delete")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.delete", "connectionUseCase", "delete")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.delete must carry the value generated for id", "connectionUseCase", "delete", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000120")
    void case_UTAPI_000120() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000120",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "delete",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000120", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000120")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::delete::5::ARG::1::-::id")
                    .mirror("-", "5:length_max", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.delete")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.delete", "connectionUseCase", "delete")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.delete must carry the value generated for id", "connectionUseCase", "delete", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000121")
    void case_UTAPI_000121() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000121",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "delete",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000121", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000121")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::delete::5::ARG::1::-::id")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.delete")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.delete", "connectionUseCase", "delete")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.delete must carry the value generated for id", "connectionUseCase", "delete", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000122")
    void case_UTAPI_000122() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000122",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "delete",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000122", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000122")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::delete::5::ARG::1::-::id")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.delete")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.delete", "connectionUseCase", "delete")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.delete must carry the value generated for id", "connectionUseCase", "delete", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000123")
    void case_UTAPI_000123() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000123",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "delete",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000123", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000123")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::delete::5::ARG::1::-::id")
                    .mirror("46:hw_integer", "-", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.delete")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.delete", "connectionUseCase", "delete")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.delete must carry the value generated for id", "connectionUseCase", "delete", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000124")
    void case_UTAPI_000124() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000124",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "delete",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000124", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000124")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::delete::5::ARG::1::-::id")
                    .mirror("-", "-", "12:integer_positive")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.delete")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.delete", "connectionUseCase", "delete")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.delete must carry the value generated for id", "connectionUseCase", "delete", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000125")
    void case_UTAPI_000125() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000125",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "delete",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000125", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000125")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::delete::5::ARG::1::-::id")
                    .mirror("-", "-", "13:integer_negative")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.delete")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.delete", "connectionUseCase", "delete")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.delete must carry the value generated for id", "connectionUseCase", "delete", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000126")
    void case_UTAPI_000126() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000126",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "delete",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000126", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000126")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::delete::5::ARG::1::-::id")
                    .mirror("-", "-", "14:integer_zero")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.delete")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.delete", "connectionUseCase", "delete")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.delete must carry the value generated for id", "connectionUseCase", "delete", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

}

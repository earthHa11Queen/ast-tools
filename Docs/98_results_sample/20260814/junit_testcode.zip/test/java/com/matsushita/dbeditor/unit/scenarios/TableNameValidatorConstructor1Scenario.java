package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableNameValidatorWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableNameValidator#Constructor1.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableNameValidatorConstructor1Scenario {

    @Test
    @DisplayName("UTAPI-010745")
    void case_UTAPI_010745() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010745",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "Constructor1",
                "-",
                new ParamSpec[] {},
                new DataRef[] {},
                OraclePlan.builder("UTAPI-010745")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::Constructor1::1::METHOD::-1::-::-")
                    .mirror("-", "-", "-")
                    .target("-", "-")
                    .kind(OracleKind.UTILITY_CLASS_CONSTRUCTION)
                    .observation("the declared constructors of TableNameValidator")
                    .expected("the utility class only declares a private constructor")
                    .failure("a public or package visible constructor is added, allowing instances of a stateless utility")
                    .assertion("assert every declared constructor is private")
                    .check(CheckType.PRIVATE_CONSTRUCTOR_ONLY, "the identifier utility must not be instantiable from outside")
                    .build()),
            new TableNameValidatorWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TemplateControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TemplateController#saveMemoTemplate.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TemplateControllerSaveMemoTemplateScenario {

    @Test
    @DisplayName("UTAPI-001769")
    void case_UTAPI_001769() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001769",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001769", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001769", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001769", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001769")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::content")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared NotBlank contract of TemplateRequest.content classifies this input condition", "TemplateRequest", "content", "NotBlank", "data:request.content")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001770")
    void case_UTAPI_001770() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001770",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001770", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001770", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001770", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001770")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::content")
                    .mirror("-", "3:length_min", "-")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001771")
    void case_UTAPI_001771() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001771",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001771", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001771", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001771", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001771")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::content")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001772")
    void case_UTAPI_001772() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001772",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001772", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001772", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001772", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001772")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::content")
                    .mirror("-", "5:length_max", "-")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001773")
    void case_UTAPI_001773() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001773",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001773", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001773", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001773", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001773")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::content")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001774")
    void case_UTAPI_001774() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001774",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001774", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001774", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001774", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001774")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::content")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001775")
    void case_UTAPI_001775() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001775",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001775", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001775", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001775", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001775")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::content")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001776")
    void case_UTAPI_001776() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001776",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001776", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001776", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001776", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001776")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::content")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001777")
    void case_UTAPI_001777() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001777",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001777", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001777", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001777", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001777")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::content")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001778")
    void case_UTAPI_001778() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001778",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001778", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001778", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001778", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001778")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::content")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001779")
    void case_UTAPI_001779() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001779",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001779", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001779", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001779", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001779")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::content")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001780")
    void case_UTAPI_001780() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001780",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001780", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001780", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001780", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001780")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::content")
                    .mirror("-", "-", "56:space")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001781")
    void case_UTAPI_001781() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001781",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001781", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001781", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001781", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001781")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::content")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001782")
    void case_UTAPI_001782() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001782",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001782", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001782", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001782", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001782")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::content")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001783")
    void case_UTAPI_001783() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001783",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001783", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001783", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001783", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001783")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::content")
                    .mirror("-", "-", "59:tab")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001784")
    void case_UTAPI_001784() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001784",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001784", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001784", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001784", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001784")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::content")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001785")
    void case_UTAPI_001785() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001785",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001785", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001785", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001785", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001785")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::content")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001786")
    void case_UTAPI_001786() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001786",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001786", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001786", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001786", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001786")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::content")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001787")
    void case_UTAPI_001787() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001787",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001787", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001787", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001787", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001787")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::content")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001788")
    void case_UTAPI_001788() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001788",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001788", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001788", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001788", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001788")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::title")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared NotBlank contract of TemplateRequest.title classifies this input condition", "TemplateRequest", "title", "NotBlank", "data:request.title")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001789")
    void case_UTAPI_001789() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001789",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001789", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001789", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001789", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001789")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::title")
                    .mirror("-", "3:length_min", "-")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001790")
    void case_UTAPI_001790() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001790",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001790", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001790", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001790", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001790")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::title")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001791")
    void case_UTAPI_001791() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001791",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001791", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001791", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001791", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001791")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::title")
                    .mirror("-", "5:length_max", "-")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001792")
    void case_UTAPI_001792() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001792",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001792", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001792", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001792", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001792")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::title")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001793")
    void case_UTAPI_001793() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001793",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001793", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001793", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001793", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001793")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::title")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001794")
    void case_UTAPI_001794() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001794",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001794", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001794", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001794", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001794")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::title")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001795")
    void case_UTAPI_001795() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001795",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001795", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001795", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001795", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001795")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::title")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001796")
    void case_UTAPI_001796() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001796",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001796", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001796", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001796", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001796")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::title")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001797")
    void case_UTAPI_001797() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001797",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001797", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001797", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001797", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001797")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::title")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001798")
    void case_UTAPI_001798() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001798",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001798", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001798", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001798", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001798")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::title")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001799")
    void case_UTAPI_001799() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001799",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001799", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001799", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001799", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001799")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::title")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001800")
    void case_UTAPI_001800() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001800",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001800", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001800", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001800", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001800")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::title")
                    .mirror("-", "-", "56:space")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001801")
    void case_UTAPI_001801() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001801",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001801", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001801", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001801", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001801")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::title")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001802")
    void case_UTAPI_001802() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001802",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001802", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001802", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001802", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001802")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::title")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001803")
    void case_UTAPI_001803() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001803",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001803", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001803", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001803", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001803")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::title")
                    .mirror("-", "-", "59:tab")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001804")
    void case_UTAPI_001804() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001804",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001804", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001804", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001804", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001804")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::title")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001805")
    void case_UTAPI_001805() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001805",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001805", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001805", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001805", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001805")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::title")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001806")
    void case_UTAPI_001806() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001806",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001806", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001806", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001806", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001806")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::title")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001807")
    void case_UTAPI_001807() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001807",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveMemoTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001807", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001807", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001807", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001807")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveMemoTemplate::2::FIELD::1::TemplateRequest::title")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveMemoTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveMemoTemplate", "templateUseCase", "saveMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveMemoTemplate must carry the value generated for request.title", "templateUseCase", "saveMemoTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveMemoTemplate must carry the value generated for request.content", "templateUseCase", "saveMemoTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

}

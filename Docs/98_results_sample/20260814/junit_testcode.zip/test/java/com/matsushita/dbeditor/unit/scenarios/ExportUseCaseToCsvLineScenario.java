package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ExportUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ExportUseCase#toCsvLine.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ExportUseCaseToCsvLineScenario {

    @Test
    @DisplayName("UTAPI-012253")
    void case_UTAPI_012253() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012253",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "toCsvLine",
                "String",
                new ParamSpec[] {
                    new ParamSpec("fields", "List<String>", "fields")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012253", "fields", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012253", "fields[]", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012253")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::toCsvLine::4::ARG::1::-::fields")
                    .mirror("-", "1:length_null", "-")
                    .target("fields", "fields")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.CSV_FIELD_PRESERVATION)
                    .observation("the CSV line produced for the supplied fields")
                    .expected("every supplied field value appears in the produced line")
                    .failure("a field is dropped or truncated while the line is composed")
                    .assertion("assertTrue(line.contains(field)) per supplied field")
                    .check(CheckType.NO_EXCEPTION, "the fields must be rendered for this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "a CSV line must be produced")
                    .check(CheckType.RETURN_CONTAINS_ELEMENTS, "every supplied field must appear in the produced line", "data:fields")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012254")
    void case_UTAPI_012254() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012254",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "toCsvLine",
                "String",
                new ParamSpec[] {
                    new ParamSpec("fields", "List<String>", "fields")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012254", "fields", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012254", "fields[]", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012254")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::toCsvLine::4::ARG::1::-::fields")
                    .mirror("-", "2:length_empty", "-")
                    .target("fields", "fields")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.CSV_FIELD_PRESERVATION)
                    .observation("the CSV line produced for the supplied fields")
                    .expected("every supplied field value appears in the produced line")
                    .failure("a field is dropped or truncated while the line is composed")
                    .assertion("assertTrue(line.contains(field)) per supplied field")
                    .check(CheckType.NO_EXCEPTION, "the fields must be rendered for this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "a CSV line must be produced")
                    .check(CheckType.RETURN_CONTAINS_ELEMENTS, "every supplied field must appear in the produced line", "data:fields")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012255")
    void case_UTAPI_012255() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012255",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "toCsvLine",
                "String",
                new ParamSpec[] {
                    new ParamSpec("fields", "List<String>", "fields")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012255", "fields", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012255", "fields[]", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012255")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::toCsvLine::4::ARG::1::-::fields")
                    .mirror("-", "3:length_min", "-")
                    .target("fields", "fields")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.CSV_FIELD_PRESERVATION)
                    .observation("the CSV line produced for the supplied fields")
                    .expected("every supplied field value appears in the produced line")
                    .failure("a field is dropped or truncated while the line is composed")
                    .assertion("assertTrue(line.contains(field)) per supplied field")
                    .check(CheckType.NO_EXCEPTION, "the fields must be rendered for this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "a CSV line must be produced")
                    .check(CheckType.RETURN_CONTAINS_ELEMENTS, "every supplied field must appear in the produced line", "data:fields")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012256")
    void case_UTAPI_012256() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012256",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "toCsvLine",
                "String",
                new ParamSpec[] {
                    new ParamSpec("fields", "List<String>", "fields")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012256", "fields", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012256", "fields[]", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012256")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::toCsvLine::4::ARG::1::-::fields")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("fields", "fields")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.CSV_FIELD_PRESERVATION)
                    .observation("the CSV line produced for the supplied fields")
                    .expected("every supplied field value appears in the produced line")
                    .failure("a field is dropped or truncated while the line is composed")
                    .assertion("assertTrue(line.contains(field)) per supplied field")
                    .check(CheckType.NO_EXCEPTION, "the fields must be rendered for this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "a CSV line must be produced")
                    .check(CheckType.RETURN_CONTAINS_ELEMENTS, "every supplied field must appear in the produced line", "data:fields")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012257")
    void case_UTAPI_012257() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012257",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "toCsvLine",
                "String",
                new ParamSpec[] {
                    new ParamSpec("fields", "List<String>", "fields")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012257", "fields", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012257", "fields[]", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012257")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::toCsvLine::4::ARG::1::-::fields")
                    .mirror("-", "5:length_max", "-")
                    .target("fields", "fields")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.CSV_FIELD_PRESERVATION)
                    .observation("the CSV line produced for the supplied fields")
                    .expected("every supplied field value appears in the produced line")
                    .failure("a field is dropped or truncated while the line is composed")
                    .assertion("assertTrue(line.contains(field)) per supplied field")
                    .check(CheckType.NO_EXCEPTION, "the fields must be rendered for this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "a CSV line must be produced")
                    .check(CheckType.RETURN_CONTAINS_ELEMENTS, "every supplied field must appear in the produced line", "data:fields")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012258")
    void case_UTAPI_012258() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012258",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "toCsvLine",
                "String",
                new ParamSpec[] {
                    new ParamSpec("fields", "List<String>", "fields")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012258", "fields", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012258", "fields[]", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012258")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::toCsvLine::4::ARG::1::-::fields")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("fields", "fields")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.CSV_FIELD_PRESERVATION)
                    .observation("the CSV line produced for the supplied fields")
                    .expected("every supplied field value appears in the produced line")
                    .failure("a field is dropped or truncated while the line is composed")
                    .assertion("assertTrue(line.contains(field)) per supplied field")
                    .check(CheckType.NO_EXCEPTION, "the fields must be rendered for this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "a CSV line must be produced")
                    .check(CheckType.RETURN_CONTAINS_ELEMENTS, "every supplied field must appear in the produced line", "data:fields")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012259")
    void case_UTAPI_012259() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012259",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "toCsvLine",
                "String",
                new ParamSpec[] {
                    new ParamSpec("fields", "List<String>", "fields")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012259", "fields", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012259", "fields[]", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012259")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::toCsvLine::4::ARG::1::-::fields")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("fields", "fields")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.CSV_FIELD_PRESERVATION)
                    .observation("the CSV line produced for the supplied fields")
                    .expected("every supplied field value appears in the produced line")
                    .failure("a field is dropped or truncated while the line is composed")
                    .assertion("assertTrue(line.contains(field)) per supplied field")
                    .check(CheckType.NO_EXCEPTION, "the fields must be rendered for this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "a CSV line must be produced")
                    .check(CheckType.RETURN_CONTAINS_ELEMENTS, "every supplied field must appear in the produced line", "data:fields")
                    .build()),
            new ExportUseCaseWrapper());
    }

}

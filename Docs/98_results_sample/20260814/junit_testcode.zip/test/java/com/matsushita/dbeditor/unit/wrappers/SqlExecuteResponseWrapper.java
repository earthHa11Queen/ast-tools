package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for SqlExecuteResponse.
 */
public final class SqlExecuteResponseWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse";
    private static final String[] DEP_NAMES = new String[] {"rows", "affectedRows", "errorMessage"};
    private static final String[] DEP_TYPES = new String[] {"List<Map<String,Object>>", "Integer", "String"};
    private static final String[] TYPES_ofDml = new String[] {"int"};
    private static final String[] TYPES_ofError = new String[] {"String"};
    private static final String[] TYPES_ofSelect = new String[] {"List<Map<String, Object>>"};

    public SqlExecuteResponseWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, true);
    }

    /** SqlExecuteResponse ofDml(affectedRows) */
    public ExecutionResult ofDml(Object[] args) {
        return invoke("ofDml", TYPES_ofDml, args);
    }

    /** SqlExecuteResponse ofError(message) */
    public ExecutionResult ofError(Object[] args) {
        return invoke("ofError", TYPES_ofError, args);
    }

    /** SqlExecuteResponse ofSelect(rows) */
    public ExecutionResult ofSelect(Object[] args) {
        return invoke("ofSelect", TYPES_ofSelect, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("ofDml".equals(operation)) {
            return ofDml(args);
        } else if ("ofError".equals(operation)) {
            return ofError(args);
        } else if ("ofSelect".equals(operation)) {
            return ofSelect(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

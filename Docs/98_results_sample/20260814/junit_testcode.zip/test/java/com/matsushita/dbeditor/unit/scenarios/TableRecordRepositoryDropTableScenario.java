package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableRecordRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableRecordRepository#dropTable.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableRecordRepositoryDropTableScenario {

    @Test
    @DisplayName("UTAPI-009211")
    void case_UTAPI_009211() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009211",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009211", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009211", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009211", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009211", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009211", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009211", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009211", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009211", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009211", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009211", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009211", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009211", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009211")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009212")
    void case_UTAPI_009212() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009212",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009212", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009212", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009212", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009212", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009212", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009212", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009212", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009212", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009212", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009212", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009212", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009212", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009212")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009213")
    void case_UTAPI_009213() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009213",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009213", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009213", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009213", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009213", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009213", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009213", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009213", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009213", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009213", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009213", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009213", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009213", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009213")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009214")
    void case_UTAPI_009214() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009214",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009214", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009214", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009214", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009214", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009214", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009214", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009214", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009214", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009214", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009214", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009214", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009214", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009214")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009215")
    void case_UTAPI_009215() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009215",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009215", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009215", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009215", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009215", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009215", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009215", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009215", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009215", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009215", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009215", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009215", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009215", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009215")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009216")
    void case_UTAPI_009216() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009216",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009216", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009216", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009216", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009216", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009216", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009216", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009216", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009216", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009216", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009216", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009216", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009216", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009216")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009217")
    void case_UTAPI_009217() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009217",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009217", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009217", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009217", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009217", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009217", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009217", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009217", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009217", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009217", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009217", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009217", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009217", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009217")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009218")
    void case_UTAPI_009218() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009218",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009218", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009218", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009218", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009218", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009218", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009218", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009218", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009218", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009218", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009218", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009218", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009218", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009218")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009219")
    void case_UTAPI_009219() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009219",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009219", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009219", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009219", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009219", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009219", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009219", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009219", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009219", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009219", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009219", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009219", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009219", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009219")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009220")
    void case_UTAPI_009220() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009220",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009220", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009220", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009220", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009220", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009220", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009220", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009220", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009220", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009220", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009220", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009220", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009220", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009220")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009221")
    void case_UTAPI_009221() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009221",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009221", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009221", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009221", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009221", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009221", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009221", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009221", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009221", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009221", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009221", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009221", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009221", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009221")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009222")
    void case_UTAPI_009222() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009222",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009222", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009222", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009222", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009222", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009222", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009222", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009222", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009222", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009222", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009222", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009222", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009222", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009222")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009223")
    void case_UTAPI_009223() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009223",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009223", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009223", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009223", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009223", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009223", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009223", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009223", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009223", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009223", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009223", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009223", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009223", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009223")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009224")
    void case_UTAPI_009224() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009224",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009224", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009224", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009224", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009224", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009224", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009224", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009224", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009224", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009224", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009224", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009224", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009224", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009224")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009225")
    void case_UTAPI_009225() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009225",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009225", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009225", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009225", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009225", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009225", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009225", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009225", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009225", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009225", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009225", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009225", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009225", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009225")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009226")
    void case_UTAPI_009226() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009226",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009226", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009226", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009226", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009226", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009226", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009226", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009226", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009226", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009226", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009226", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009226", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009226", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009226")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009227")
    void case_UTAPI_009227() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009227",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009227", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009227", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009227", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009227", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009227", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009227", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009227", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009227", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009227", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009227", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009227", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009227", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009227")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009228")
    void case_UTAPI_009228() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009228",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009228", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009228", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009228", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009228", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009228", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009228", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009228", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009228", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009228", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009228", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009228", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009228", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009228")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009229")
    void case_UTAPI_009229() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009229",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009229", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009229", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009229", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009229", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009229", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009229", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009229", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009229", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009229", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009229", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009229", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009229", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009229")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009230")
    void case_UTAPI_009230() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009230",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009230", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009230", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009230", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009230", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009230", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009230", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009230", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009230", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009230", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009230", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009230", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009230", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009230")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009231")
    void case_UTAPI_009231() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009231",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009231", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009231", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009231", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009231", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009231", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009231", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009231", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009231", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009231", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009231", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009231", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009231", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009231")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009232")
    void case_UTAPI_009232() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009232",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009232", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009232", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009232", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009232", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009232", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009232", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009232", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009232", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009232", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009232", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009232", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009232", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009232")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009233")
    void case_UTAPI_009233() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009233",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009233", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009233", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009233", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009233", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009233", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009233", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009233", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009233", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009233", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009233", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009233", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009233", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009233")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009234")
    void case_UTAPI_009234() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009234",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009234", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009234", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009234", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009234", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009234", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009234", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009234", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009234", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009234", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009234", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009234", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009234", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009234")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009235")
    void case_UTAPI_009235() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009235",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009235", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009235", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009235", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009235", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009235", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009235", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009235", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009235", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009235", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009235", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009235", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009235", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009235")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009236")
    void case_UTAPI_009236() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009236",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009236", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009236", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009236", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009236", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009236", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009236", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009236", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009236", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009236", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009236", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009236", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009236", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009236")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009237")
    void case_UTAPI_009237() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009237",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009237", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009237", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009237", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009237", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009237", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009237", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009237", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009237", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009237", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009237", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009237", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009237", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009237")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009238")
    void case_UTAPI_009238() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009238",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009238", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009238", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009238", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009238", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009238", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009238", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009238", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009238", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009238", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009238", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009238", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009238", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009238")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009239")
    void case_UTAPI_009239() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009239",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009239", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009239", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009239", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009239", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009239", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009239", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009239", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009239", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009239", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009239", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009239", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009239", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009239")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009240")
    void case_UTAPI_009240() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009240",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009240", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009240", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009240", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009240", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009240", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009240", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009240", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009240", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009240", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009240", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009240", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009240", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009240")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009241")
    void case_UTAPI_009241() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009241",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009241", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009241", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009241", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009241", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009241", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009241", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009241", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009241", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009241", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009241", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009241", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009241", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009241")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009242")
    void case_UTAPI_009242() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009242",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009242", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009242", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009242", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009242", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009242", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009242", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009242", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009242", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009242", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009242", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009242", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009242", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009242")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009243")
    void case_UTAPI_009243() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009243",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009243", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009243", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009243", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009243", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009243", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009243", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009243", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009243", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009243", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009243", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009243", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009243", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009243")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009244")
    void case_UTAPI_009244() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009244",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009244", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009244", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009244", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009244", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009244", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009244", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009244", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009244", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009244", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009244", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009244", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009244", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009244")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009245")
    void case_UTAPI_009245() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009245",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009245", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009245", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009245", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009245", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009245", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009245", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009245", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009245", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009245", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009245", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009245", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009245", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009245")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009246")
    void case_UTAPI_009246() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009246",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009246", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009246", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009246", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009246", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009246", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009246", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009246", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009246", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009246", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009246", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009246", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009246", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009246")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009247")
    void case_UTAPI_009247() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009247",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009247", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009247", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009247", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009247", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009247", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009247", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009247", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009247", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009247", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009247", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009247", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009247", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009247")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009248")
    void case_UTAPI_009248() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009248",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009248", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009248", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009248", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009248", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009248", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009248", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009248", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009248", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009248", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009248", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009248", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009248", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009248")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009249")
    void case_UTAPI_009249() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009249",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009249", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009249", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009249", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009249", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009249", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009249", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009249", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009249", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009249", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009249", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009249", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009249", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009249")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009250")
    void case_UTAPI_009250() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009250",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009250", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009250", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009250", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009250", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009250", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009250", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009250", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009250", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009250", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009250", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009250", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009250", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009250")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009251")
    void case_UTAPI_009251() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009251",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009251", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009251", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009251", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009251", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009251", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009251", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009251", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009251", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009251", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009251", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009251", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009251", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009251")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009252")
    void case_UTAPI_009252() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009252",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009252", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009252", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009252", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009252", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009252", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009252", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009252", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009252", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009252", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009252", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009252", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009252", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009252")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009253")
    void case_UTAPI_009253() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009253",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009253", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009253", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009253", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009253", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009253", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009253", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009253", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009253", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009253", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009253", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009253", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009253", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009253")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009254")
    void case_UTAPI_009254() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009254",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009254", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009254", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009254", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009254", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009254", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009254", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009254", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009254", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009254", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009254", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009254", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009254", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009254")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009255")
    void case_UTAPI_009255() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009255",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009255", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009255", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009255", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009255", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009255", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009255", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009255", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009255", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009255", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009255", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009255", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009255", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009255")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009256")
    void case_UTAPI_009256() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009256",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009256", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009256", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009256", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009256", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009256", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009256", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009256", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009256", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009256", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009256", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009256", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009256", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009256")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009257")
    void case_UTAPI_009257() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009257",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009257", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009257", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009257", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009257", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009257", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009257", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009257", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009257", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009257", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009257", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009257", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009257", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009257")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009258")
    void case_UTAPI_009258() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009258",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009258", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009258", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009258", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009258", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009258", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009258", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009258", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009258", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009258", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009258", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009258", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009258", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009258")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009259")
    void case_UTAPI_009259() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009259",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009259", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009259", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009259", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009259", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009259", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009259", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009259", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009259", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009259", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009259", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009259", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009259", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009259")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009260")
    void case_UTAPI_009260() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009260",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009260", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009260", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009260", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009260", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009260", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009260", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009260", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009260", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009260", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009260", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009260", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009260", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009260")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009261")
    void case_UTAPI_009261() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009261",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009261", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009261", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009261", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009261", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009261", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009261", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009261", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009261", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009261", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009261", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009261", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009261", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009261")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009262")
    void case_UTAPI_009262() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009262",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009262", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009262", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009262", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009262", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009262", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009262", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009262", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009262", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009262", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009262", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009262", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009262", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009262")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009263")
    void case_UTAPI_009263() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009263",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009263", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009263", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009263", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009263", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009263", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009263", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009263", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009263", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009263", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009263", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009263", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009263", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009263")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009264")
    void case_UTAPI_009264() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009264",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009264", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009264", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009264", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009264", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009264", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009264", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009264", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009264", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009264", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009264", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009264", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009264", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009264")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009265")
    void case_UTAPI_009265() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009265",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009265", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009265", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009265", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009265", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009265", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009265", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009265", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009265", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009265", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009265", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009265", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009265", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009265")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009266")
    void case_UTAPI_009266() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009266",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009266", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009266", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009266", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009266", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009266", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009266", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009266", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009266", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009266", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009266", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009266", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009266", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009266")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009267")
    void case_UTAPI_009267() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009267",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009267", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009267", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009267", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009267", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009267", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009267", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009267", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009267", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009267", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009267", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009267", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009267", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009267")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009268")
    void case_UTAPI_009268() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009268",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009268", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009268", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009268", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009268", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009268", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009268", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009268", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009268", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009268", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009268", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009268", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009268", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009268")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009269")
    void case_UTAPI_009269() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009269",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009269", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009269", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009269", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009269", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009269", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009269", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009269", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009269", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009269", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009269", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009269", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009269", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009269")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009270")
    void case_UTAPI_009270() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009270",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009270", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009270", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009270", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009270", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009270", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009270", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009270", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009270", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009270", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009270", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009270", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009270", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009270")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009271")
    void case_UTAPI_009271() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009271",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009271", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009271", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009271", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009271", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009271", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009271", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009271", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009271", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009271", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009271", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009271", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009271", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009271")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009272")
    void case_UTAPI_009272() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009272",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009272", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009272", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009272", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009272", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009272", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009272", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009272", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009272", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009272", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009272", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009272", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009272", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009272")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009273")
    void case_UTAPI_009273() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009273",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009273", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009273", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009273", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009273", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009273", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009273", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009273", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009273", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009273", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009273", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009273", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009273", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009273")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009274")
    void case_UTAPI_009274() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009274",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009274", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009274", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009274", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009274", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009274", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009274", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009274", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009274", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009274", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009274", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009274", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009274", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009274")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009275")
    void case_UTAPI_009275() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009275",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009275", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009275", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009275", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009275", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009275", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009275", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009275", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009275", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009275", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009275", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009275", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009275", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009275")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009276")
    void case_UTAPI_009276() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009276",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009276", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009276", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009276", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009276", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009276", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009276", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009276", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009276", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009276", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009276", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009276", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009276", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009276")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009277")
    void case_UTAPI_009277() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009277",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009277", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009277", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009277", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009277", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009277", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009277", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009277", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009277", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009277", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009277", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009277", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009277", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009277")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009278")
    void case_UTAPI_009278() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009278",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009278", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009278", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009278", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009278", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009278", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009278", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009278", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009278", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009278", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009278", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009278", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009278", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009278")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009279")
    void case_UTAPI_009279() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009279",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009279", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009279", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009279", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009279", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009279", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009279", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009279", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009279", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009279", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009279", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009279", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009279", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009279")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009280")
    void case_UTAPI_009280() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009280",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009280", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009280", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009280", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009280", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009280", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009280", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009280", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009280", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009280", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009280", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009280", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009280", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009280")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009281")
    void case_UTAPI_009281() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009281",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009281", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009281", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009281", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009281", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009281", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009281", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009281", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009281", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009281", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009281", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009281", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009281", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009281")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009282")
    void case_UTAPI_009282() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009282",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009282", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009282", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009282", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009282", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009282", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009282", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009282", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009282", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009282", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009282", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009282", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009282", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009282")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009283")
    void case_UTAPI_009283() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009283",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009283", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009283", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009283", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009283", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009283", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009283", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009283", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009283", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009283", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009283", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009283", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009283", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009283")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009284")
    void case_UTAPI_009284() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009284",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009284", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009284", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009284", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009284", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009284", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009284", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009284", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009284", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009284", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009284", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009284", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009284", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009284")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009285")
    void case_UTAPI_009285() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009285",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009285", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009285", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009285", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009285", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009285", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009285", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009285", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009285", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009285", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009285", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009285", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009285", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009285")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009286")
    void case_UTAPI_009286() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009286",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009286", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009286", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009286", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009286", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009286", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009286", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009286", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009286", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009286", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009286", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009286", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009286", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009286")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009287")
    void case_UTAPI_009287() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009287",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009287", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009287", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009287", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009287", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009287", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009287", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009287", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009287", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009287", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009287", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009287", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009287", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009287")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009288")
    void case_UTAPI_009288() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009288",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009288", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009288", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009288", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009288", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009288", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009288", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009288", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009288", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009288", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009288", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009288", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009288", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009288")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009289")
    void case_UTAPI_009289() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009289",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009289", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009289", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009289", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009289", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009289", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009289", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009289", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009289", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009289", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009289", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009289", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009289", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009289")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009290")
    void case_UTAPI_009290() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009290",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009290", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009290", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009290", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009290", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009290", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009290", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009290", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009290", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009290", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009290", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009290", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009290", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009290")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009291")
    void case_UTAPI_009291() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009291",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009291", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009291", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009291", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009291", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009291", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009291", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009291", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009291", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009291", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009291", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009291", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009291", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009291")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009292")
    void case_UTAPI_009292() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009292",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009292", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009292", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009292", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009292", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009292", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009292", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009292", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009292", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009292", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009292", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009292", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009292", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009292")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009293")
    void case_UTAPI_009293() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009293",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009293", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009293", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009293", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009293", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009293", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009293", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009293", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009293", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009293", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009293", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009293", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009293", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009293")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009294")
    void case_UTAPI_009294() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009294",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009294", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009294", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009294", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009294", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009294", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009294", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009294", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009294", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009294", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009294", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009294", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009294", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009294")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009295")
    void case_UTAPI_009295() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009295",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009295", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009295", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009295", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009295", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009295", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009295", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009295", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009295", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009295", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009295", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009295", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009295", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009295")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009296")
    void case_UTAPI_009296() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009296",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009296", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009296", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009296", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009296", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009296", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009296", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009296", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009296", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009296", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009296", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009296", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009296", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009296")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009297")
    void case_UTAPI_009297() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009297",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009297", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009297", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009297", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009297", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009297", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009297", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009297", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009297", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009297", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009297", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009297", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009297", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009297")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009298")
    void case_UTAPI_009298() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009298",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009298", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009298", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009298", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009298", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009298", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009298", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009298", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009298", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009298", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009298", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009298", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009298", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009298")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009299")
    void case_UTAPI_009299() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009299",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009299", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009299", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009299", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009299", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009299", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009299", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009299", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009299", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009299", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009299", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009299", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009299", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009299")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009300")
    void case_UTAPI_009300() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009300",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009300", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009300", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009300", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009300", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009300", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009300", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009300", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009300", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009300", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009300", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009300", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009300", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009300")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009301")
    void case_UTAPI_009301() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009301",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009301", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009301", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009301", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009301", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009301", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009301", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009301", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009301", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009301", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009301", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009301", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009301", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009301")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009302")
    void case_UTAPI_009302() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009302",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009302", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009302", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009302", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009302", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009302", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009302", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009302", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009302", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009302", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009302", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009302", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009302", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009302")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009303")
    void case_UTAPI_009303() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009303",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009303", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009303", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009303", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009303", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009303", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009303", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009303", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009303", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009303", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009303", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009303", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009303", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009303")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009304")
    void case_UTAPI_009304() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009304",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009304", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009304", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009304", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009304", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009304", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009304", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009304", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009304", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009304", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009304", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009304", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009304", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009304")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009305")
    void case_UTAPI_009305() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009305",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009305", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009305", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009305", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009305", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009305", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009305", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009305", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009305", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009305", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009305", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009305", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009305", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009305")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009306")
    void case_UTAPI_009306() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009306",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009306", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009306", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009306", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009306", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009306", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009306", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009306", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009306", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009306", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009306", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009306", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009306", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009306")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009307")
    void case_UTAPI_009307() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009307",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009307", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009307", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009307", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009307", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009307", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009307", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009307", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009307", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009307", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009307", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009307", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009307", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009307")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009308")
    void case_UTAPI_009308() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009308",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009308", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009308", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009308", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009308", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009308", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009308", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009308", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009308", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009308", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009308", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009308", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009308", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009308")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009309")
    void case_UTAPI_009309() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009309",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009309", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009309", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009309", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009309", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009309", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009309", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009309", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009309", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009309", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009309", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009309", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009309", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009309")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009310")
    void case_UTAPI_009310() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009310",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009310", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009310", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009310", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009310", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009310", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009310", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009310", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009310", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009310", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009310", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009310", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009310", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009310")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009311")
    void case_UTAPI_009311() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009311",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009311", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009311", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009311", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009311", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009311", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009311", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009311", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009311", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009311", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009311", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009311", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009311", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009311")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009312")
    void case_UTAPI_009312() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009312",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009312", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009312", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009312", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009312", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009312", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009312", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009312", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009312", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009312", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009312", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009312", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009312", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009312")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009313")
    void case_UTAPI_009313() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009313",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009313", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009313", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009313", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009313", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009313", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009313", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009313", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009313", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009313", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009313", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009313", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009313", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009313")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009314")
    void case_UTAPI_009314() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009314",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009314", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009314", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009314", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009314", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009314", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009314", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009314", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009314", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009314", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009314", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009314", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009314", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009314")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009315")
    void case_UTAPI_009315() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009315",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009315", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009315", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009315", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009315", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009315", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009315", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009315", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009315", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009315", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009315", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009315", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009315", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009315")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009316")
    void case_UTAPI_009316() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009316",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009316", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009316", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009316", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009316", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009316", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009316", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009316", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009316", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009316", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009316", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009316", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009316", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009316")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009317")
    void case_UTAPI_009317() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009317",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009317", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009317", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009317", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009317", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009317", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009317", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009317", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009317", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009317", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009317", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009317", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009317", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009317")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009318")
    void case_UTAPI_009318() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009318",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009318", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009318", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009318", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009318", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009318", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009318", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009318", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009318", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009318", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009318", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009318", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009318", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009318")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009319")
    void case_UTAPI_009319() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009319",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009319", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009319", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009319", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009319", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009319", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009319", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009319", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009319", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009319", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009319", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009319", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009319", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009319")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009320")
    void case_UTAPI_009320() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009320",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009320", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009320", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009320", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009320", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009320", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009320", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009320", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009320", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009320", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009320", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009320", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009320", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009320")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009321")
    void case_UTAPI_009321() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009321",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009321", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009321", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009321", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009321", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009321", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009321", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009321", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009321", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009321", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009321", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009321", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009321", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009321")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009322")
    void case_UTAPI_009322() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009322",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009322", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009322", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009322", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009322", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009322", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009322", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009322", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009322", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009322", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009322", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009322", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009322", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009322")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009323")
    void case_UTAPI_009323() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009323",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009323", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009323", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009323", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009323", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009323", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009323", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009323", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009323", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009323", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009323", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009323", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009323", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009323")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009324")
    void case_UTAPI_009324() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009324",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009324", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009324", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009324", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009324", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009324", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009324", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009324", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009324", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009324", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009324", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009324", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009324", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009324")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009325")
    void case_UTAPI_009325() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009325",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009325", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009325", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009325", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009325", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009325", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009325", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009325", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009325", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009325", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009325", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009325", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009325", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009325")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009326")
    void case_UTAPI_009326() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009326",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009326", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009326", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009326", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009326", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009326", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009326", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009326", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009326", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009326", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009326", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009326", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009326", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009326")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009327")
    void case_UTAPI_009327() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009327",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009327", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009327", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009327", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009327", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009327", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009327", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009327", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009327", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009327", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009327", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009327", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009327", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009327")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009328")
    void case_UTAPI_009328() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009328",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009328", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009328", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009328", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009328", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009328", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009328", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009328", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009328", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009328", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009328", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009328", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009328", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009328")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009329")
    void case_UTAPI_009329() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009329",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009329", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009329", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009329", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009329", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009329", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009329", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009329", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009329", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009329", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009329", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009329", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009329", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009329")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009330")
    void case_UTAPI_009330() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009330",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009330", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009330", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009330", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009330", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009330", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009330", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009330", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009330", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009330", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009330", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009330", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009330", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009330")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009331")
    void case_UTAPI_009331() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009331",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009331", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009331", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009331", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009331", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009331", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009331", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009331", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009331", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009331", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009331", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009331", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009331", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009331")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009332")
    void case_UTAPI_009332() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009332",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009332", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009332", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009332", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009332", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009332", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009332", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009332", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009332", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009332", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009332", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009332", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009332", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009332")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009333")
    void case_UTAPI_009333() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009333",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009333", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009333", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009333", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009333", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009333", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009333", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009333", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009333", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009333", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009333", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009333", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009333", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009333")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009334")
    void case_UTAPI_009334() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009334",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009334", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009334", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009334", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009334", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009334", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009334", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009334", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009334", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009334", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009334", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009334", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009334", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009334")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009335")
    void case_UTAPI_009335() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009335",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009335", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009335", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009335", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009335", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009335", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009335", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009335", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009335", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009335", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009335", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009335", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009335", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009335")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009336")
    void case_UTAPI_009336() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009336",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009336", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009336", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009336", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009336", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009336", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009336", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009336", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009336", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009336", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009336", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009336", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009336", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009336")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009337")
    void case_UTAPI_009337() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009337",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009337", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009337", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009337", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009337", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009337", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009337", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009337", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009337", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009337", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009337", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009337", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009337", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009337")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009338")
    void case_UTAPI_009338() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009338",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009338", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009338", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009338", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009338", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009338", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009338", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009338", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009338", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009338", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009338", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009338", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009338", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009338")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009339")
    void case_UTAPI_009339() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009339",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009339", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009339", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009339", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009339", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009339", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009339", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009339", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009339", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009339", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009339", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009339", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009339", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009339")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009340")
    void case_UTAPI_009340() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009340",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009340", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009340", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009340", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009340", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009340", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009340", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009340", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009340", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009340", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009340", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009340", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009340", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009340")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009341")
    void case_UTAPI_009341() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009341",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009341", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009341", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009341", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009341", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009341", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009341", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009341", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009341", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009341", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009341", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009341", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009341", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009341")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009342")
    void case_UTAPI_009342() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009342",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009342", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009342", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009342", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009342", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009342", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009342", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009342", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009342", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009342", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009342", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009342", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009342", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009342")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009343")
    void case_UTAPI_009343() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009343",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009343", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009343", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009343", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009343", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009343", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009343", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009343", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009343", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009343", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009343", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009343", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009343", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009343")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009344")
    void case_UTAPI_009344() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009344",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009344", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009344", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009344", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009344", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009344", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009344", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009344", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009344", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009344", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009344", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009344", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009344", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009344")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009345")
    void case_UTAPI_009345() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009345",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009345", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009345", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009345", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009345", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009345", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009345", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009345", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009345", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009345", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009345", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009345", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009345", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009345")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009346")
    void case_UTAPI_009346() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009346",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009346", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009346", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009346", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009346", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009346", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009346", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009346", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009346", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009346", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009346", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009346", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009346", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009346")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009347")
    void case_UTAPI_009347() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009347",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009347", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009347", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009347", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009347", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009347", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009347", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009347", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009347", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009347", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009347", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009347", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009347", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009347")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009348")
    void case_UTAPI_009348() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009348",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009348", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009348", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009348", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009348", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009348", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009348", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009348", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009348", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009348", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009348", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009348", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009348", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009348")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009349")
    void case_UTAPI_009349() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009349",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009349", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009349", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009349", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009349", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009349", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009349", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009349", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009349", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009349", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009349", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009349", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009349", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009349")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009350")
    void case_UTAPI_009350() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009350",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009350", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009350", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009350", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009350", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009350", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009350", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009350", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009350", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009350", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009350", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009350", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009350", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009350")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009351")
    void case_UTAPI_009351() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009351",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009351", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009351", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009351", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009351", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009351", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009351", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009351", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009351", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009351", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009351", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009351", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009351", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009351")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009352")
    void case_UTAPI_009352() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009352",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009352", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009352", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009352", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009352", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009352", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009352", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009352", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009352", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009352", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009352", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009352", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009352", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009352")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009353")
    void case_UTAPI_009353() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009353",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009353", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009353", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009353", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009353", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009353", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009353", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009353", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009353", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009353", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009353", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009353", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009353", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009353")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009354")
    void case_UTAPI_009354() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009354",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009354", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009354", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009354", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009354", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009354", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009354", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009354", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009354", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009354", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009354", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009354", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009354", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009354")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009355")
    void case_UTAPI_009355() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009355",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009355", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009355", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009355", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009355", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009355", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009355", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009355", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009355", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009355", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009355", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009355", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009355", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009355")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009356")
    void case_UTAPI_009356() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009356",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009356", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009356", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009356", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009356", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009356", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009356", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009356", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009356", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009356", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009356", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009356", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009356", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009356")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009357")
    void case_UTAPI_009357() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009357",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009357", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009357", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009357", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009357", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009357", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009357", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009357", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009357", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009357", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009357", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009357", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009357", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009357")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009358")
    void case_UTAPI_009358() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009358",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009358", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009358", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009358", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009358", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009358", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009358", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009358", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009358", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009358", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009358", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009358", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009358", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009358")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009359")
    void case_UTAPI_009359() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009359",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009359", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009359", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009359", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009359", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009359", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009359", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009359", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009359", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009359", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009359", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009359", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009359", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009359")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009360")
    void case_UTAPI_009360() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009360",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009360", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009360", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009360", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009360", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009360", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009360", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009360", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009360", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009360", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009360", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009360", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009360", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009360")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009361")
    void case_UTAPI_009361() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009361",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009361", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009361", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009361", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009361", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009361", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009361", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009361", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009361", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009361", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009361", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009361", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009361", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009361")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009362")
    void case_UTAPI_009362() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009362",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009362", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009362", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009362", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009362", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009362", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009362", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009362", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009362", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009362", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009362", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009362", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009362", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009362")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009363")
    void case_UTAPI_009363() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009363",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009363", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009363", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009363", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009363", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009363", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009363", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009363", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009363", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009363", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009363", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009363", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009363", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009363")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009364")
    void case_UTAPI_009364() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009364",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009364", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009364", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009364", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009364", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009364", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009364", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009364", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009364", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009364", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009364", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009364", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009364", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009364")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009365")
    void case_UTAPI_009365() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009365",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009365", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009365", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009365", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009365", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009365", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009365", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009365", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009365", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009365", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009365", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009365", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009365", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009365")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009366")
    void case_UTAPI_009366() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009366",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009366", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009366", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009366", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009366", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009366", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009366", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009366", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009366", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009366", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009366", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009366", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009366", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009366")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009367")
    void case_UTAPI_009367() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009367",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009367", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009367", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009367", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009367", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009367", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009367", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009367", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009367", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009367", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009367", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009367", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009367", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009367")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009368")
    void case_UTAPI_009368() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009368",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009368", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009368", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009368", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009368", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009368", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009368", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009368", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009368", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009368", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009368", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009368", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009368", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009368")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009369")
    void case_UTAPI_009369() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009369",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009369", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009369", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009369", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009369", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009369", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009369", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009369", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009369", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009369", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009369", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009369", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009369", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009369")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009370")
    void case_UTAPI_009370() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009370",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009370", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009370", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009370", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009370", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009370", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009370", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009370", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009370", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009370", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009370", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009370", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009370", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009370")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009371")
    void case_UTAPI_009371() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009371",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009371", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009371", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009371", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009371", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009371", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009371", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009371", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009371", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009371", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009371", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009371", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009371", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009371")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009372")
    void case_UTAPI_009372() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009372",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009372", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009372", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009372", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009372", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009372", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009372", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009372", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009372", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009372", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009372", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009372", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009372", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009372")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009373")
    void case_UTAPI_009373() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009373",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009373", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009373", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009373", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009373", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009373", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009373", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009373", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009373", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009373", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009373", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009373", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009373", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009373")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009374")
    void case_UTAPI_009374() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009374",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009374", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009374", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009374", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009374", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009374", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009374", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009374", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009374", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009374", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009374", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009374", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009374", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009374")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009375")
    void case_UTAPI_009375() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009375",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009375", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009375", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009375", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009375", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009375", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009375", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009375", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009375", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009375", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009375", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009375", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009375", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009375")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009376")
    void case_UTAPI_009376() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009376",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009376", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009376", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009376", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009376", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009376", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009376", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009376", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009376", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009376", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009376", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009376", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009376", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009376")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009377")
    void case_UTAPI_009377() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009377",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009377", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009377", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009377", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009377", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009377", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009377", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009377", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009377", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009377", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009377", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009377", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009377", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009377")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009378")
    void case_UTAPI_009378() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009378",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009378", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009378", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009378", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009378", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009378", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009378", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009378", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009378", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009378", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009378", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009378", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009378", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009378")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009379")
    void case_UTAPI_009379() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009379",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009379", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009379", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009379", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009379", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009379", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009379", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009379", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009379", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009379", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009379", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009379", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009379", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009379")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009380")
    void case_UTAPI_009380() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009380",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009380", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009380", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009380", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009380", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009380", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009380", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009380", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009380", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009380", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009380", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009380", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009380", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009380")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009381")
    void case_UTAPI_009381() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009381",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009381", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009381", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009381", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009381", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009381", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009381", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009381", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009381", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009381", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009381", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009381", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009381", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009381")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009382")
    void case_UTAPI_009382() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009382",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009382", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009382", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009382", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009382", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009382", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009382", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009382", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009382", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009382", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009382", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009382", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009382", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009382")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009383")
    void case_UTAPI_009383() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009383",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009383", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009383", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009383", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009383", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009383", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009383", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009383", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009383", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009383", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009383", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009383", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009383", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009383")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009384")
    void case_UTAPI_009384() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009384",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009384", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009384", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009384", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009384", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009384", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009384", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009384", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009384", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009384", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009384", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009384", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009384", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009384")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009385")
    void case_UTAPI_009385() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009385",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009385", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009385", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009385", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009385", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009385", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009385", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009385", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009385", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009385", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009385", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009385", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009385", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009385")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009386")
    void case_UTAPI_009386() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009386",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009386", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009386", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009386", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009386", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009386", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009386", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009386", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009386", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009386", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009386", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009386", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009386", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009386")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009387")
    void case_UTAPI_009387() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009387",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009387", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009387", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009387", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009387", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009387", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009387", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009387", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009387", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009387", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009387", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009387", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009387", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009387")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009388")
    void case_UTAPI_009388() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009388",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009388", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009388", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009388", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009388", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009388", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009388", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009388", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009388", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009388", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009388", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009388", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009388", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009388")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009389")
    void case_UTAPI_009389() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009389",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009389", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009389", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009389", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009389", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009389", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009389", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009389", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009389", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009389", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009389", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009389", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009389", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009389")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009390")
    void case_UTAPI_009390() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009390",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009390", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009390", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009390", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009390", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009390", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009390", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009390", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009390", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009390", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009390", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009390", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009390", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009390")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009391")
    void case_UTAPI_009391() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009391",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009391", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009391", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009391", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009391", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009391", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009391", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009391", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009391", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009391", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009391", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009391", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009391", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009391")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009392")
    void case_UTAPI_009392() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009392",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009392", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009392", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009392", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009392", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009392", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009392", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009392", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009392", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009392", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009392", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009392", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009392", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009392")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009393")
    void case_UTAPI_009393() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009393",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009393", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009393", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009393", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009393", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009393", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009393", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009393", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009393", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009393", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009393", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009393", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009393", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009393")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SqlExecuteResponseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SqlExecuteResponse#ofError.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SqlExecuteResponseOfErrorScenario {

    @Test
    @DisplayName("UTAPI-010375")
    void case_UTAPI_010375() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010375",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofError",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("message", "String", "message")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010375", "message", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010375")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofError::3::ARG::1::-::message")
                    .mirror("-", "1:length_null", "-")
                    .target("message", "message")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofError")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getErrorMessage must carry the supplied message", "getErrorMessage", "data:message")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010376")
    void case_UTAPI_010376() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010376",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofError",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("message", "String", "message")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010376", "message", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010376")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofError::3::ARG::1::-::message")
                    .mirror("-", "2:length_empty", "-")
                    .target("message", "message")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofError")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getErrorMessage must carry the supplied message", "getErrorMessage", "data:message")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010377")
    void case_UTAPI_010377() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010377",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofError",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("message", "String", "message")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010377", "message", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010377")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofError::3::ARG::1::-::message")
                    .mirror("-", "3:length_min", "-")
                    .target("message", "message")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofError")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getErrorMessage must carry the supplied message", "getErrorMessage", "data:message")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010378")
    void case_UTAPI_010378() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010378",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofError",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("message", "String", "message")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010378", "message", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010378")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofError::3::ARG::1::-::message")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("message", "message")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofError")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getErrorMessage must carry the supplied message", "getErrorMessage", "data:message")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010379")
    void case_UTAPI_010379() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010379",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofError",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("message", "String", "message")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010379", "message", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010379")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofError::3::ARG::1::-::message")
                    .mirror("-", "5:length_max", "-")
                    .target("message", "message")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofError")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getErrorMessage must carry the supplied message", "getErrorMessage", "data:message")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010380")
    void case_UTAPI_010380() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010380",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofError",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("message", "String", "message")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010380", "message", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010380")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofError::3::ARG::1::-::message")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("message", "message")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofError")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getErrorMessage must carry the supplied message", "getErrorMessage", "data:message")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010381")
    void case_UTAPI_010381() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010381",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofError",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("message", "String", "message")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010381", "message", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010381")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofError::3::ARG::1::-::message")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("message", "message")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofError")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getErrorMessage must carry the supplied message", "getErrorMessage", "data:message")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010382")
    void case_UTAPI_010382() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010382",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofError",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("message", "String", "message")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010382", "message", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010382")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofError::3::ARG::1::-::message")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("message", "message")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofError")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getErrorMessage must carry the supplied message", "getErrorMessage", "data:message")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010383")
    void case_UTAPI_010383() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010383",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofError",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("message", "String", "message")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010383", "message", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010383")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofError::3::ARG::1::-::message")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("message", "message")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofError")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getErrorMessage must carry the supplied message", "getErrorMessage", "data:message")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010384")
    void case_UTAPI_010384() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010384",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofError",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("message", "String", "message")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010384", "message", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010384")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofError::3::ARG::1::-::message")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("message", "message")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofError")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getErrorMessage must carry the supplied message", "getErrorMessage", "data:message")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010385")
    void case_UTAPI_010385() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010385",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofError",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("message", "String", "message")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010385", "message", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010385")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofError::3::ARG::1::-::message")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("message", "message")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofError")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getErrorMessage must carry the supplied message", "getErrorMessage", "data:message")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010386")
    void case_UTAPI_010386() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010386",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofError",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("message", "String", "message")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010386", "message", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010386")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofError::3::ARG::1::-::message")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("message", "message")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofError")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getErrorMessage must carry the supplied message", "getErrorMessage", "data:message")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010387")
    void case_UTAPI_010387() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010387",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofError",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("message", "String", "message")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010387", "message", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010387")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofError::3::ARG::1::-::message")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("message", "message")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofError")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getErrorMessage must carry the supplied message", "getErrorMessage", "data:message")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010388")
    void case_UTAPI_010388() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010388",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofError",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("message", "String", "message")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010388", "message", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010388")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofError::3::ARG::1::-::message")
                    .mirror("-", "-", "56:space")
                    .target("message", "message")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofError")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getErrorMessage must carry the supplied message", "getErrorMessage", "data:message")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010389")
    void case_UTAPI_010389() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010389",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofError",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("message", "String", "message")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010389", "message", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010389")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofError::3::ARG::1::-::message")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("message", "message")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofError")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getErrorMessage must carry the supplied message", "getErrorMessage", "data:message")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010390")
    void case_UTAPI_010390() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010390",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofError",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("message", "String", "message")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010390", "message", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010390")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofError::3::ARG::1::-::message")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("message", "message")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofError")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getErrorMessage must carry the supplied message", "getErrorMessage", "data:message")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010391")
    void case_UTAPI_010391() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010391",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofError",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("message", "String", "message")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010391", "message", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010391")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofError::3::ARG::1::-::message")
                    .mirror("-", "-", "59:tab")
                    .target("message", "message")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofError")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getErrorMessage must carry the supplied message", "getErrorMessage", "data:message")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010392")
    void case_UTAPI_010392() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010392",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofError",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("message", "String", "message")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010392", "message", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010392")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofError::3::ARG::1::-::message")
                    .mirror("-", "-", "60:control_character_null")
                    .target("message", "message")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofError")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getErrorMessage must carry the supplied message", "getErrorMessage", "data:message")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010393")
    void case_UTAPI_010393() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010393",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofError",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("message", "String", "message")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010393", "message", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010393")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofError::3::ARG::1::-::message")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("message", "message")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofError")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getErrorMessage must carry the supplied message", "getErrorMessage", "data:message")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010394")
    void case_UTAPI_010394() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010394",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofError",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("message", "String", "message")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010394", "message", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010394")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofError::3::ARG::1::-::message")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("message", "message")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofError")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getErrorMessage must carry the supplied message", "getErrorMessage", "data:message")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010395")
    void case_UTAPI_010395() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010395",
                "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse",
                "ofError",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("message", "String", "message")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010395", "message", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010395")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/SqlExecuteResponse.java::SqlExecuteResponse::ofError::3::ARG::1::-::message")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("message", "message")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the SqlExecuteResponse produced by ofError")
                    .expected("the supplied value is carried onto the field that matches the factory semantics and the fields of the other result shapes stay unset")
                    .failure("the value is dropped or written to the field of another result shape")
                    .assertion("assertEquals on the carried field and assertNull on the field of the other result shape")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getErrorMessage must carry the supplied message", "getErrorMessage", "data:message")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new SqlExecuteResponseWrapper());
    }

}

package com.matsushita.dbeditor.fixtures;

import java.io.ByteArrayInputStream;
import java.lang.reflect.Method;

import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.matsushita.dbeditor.utils.HarnessException;
import com.matsushita.dbeditor.utils.ProjectTypes;

/**
 * Builds the non project objects that a target method declares as a parameter
 * (uploaded file, JdbcTemplate handle, CORS registry, streams, exceptions).
 * TestDataRuntime is not responsible for arbitrary object graphs, so the generated
 * test side code assembles them, honouring the Mirror condition of the target row.
 */
public final class FrameworkObjects {

    private FrameworkObjects() {
    }

    public static final String EXCEPTION_MESSAGE = "SENTINEL-EXCEPTION-MESSAGE";

    public static boolean handles(String referenceType) {
        return "MultipartFile".equals(referenceType) || "JdbcTemplate".equals(referenceType)
                || "CorsRegistry".equals(referenceType) || "InputStream".equals(referenceType)
                || "IllegalArgumentException".equals(referenceType) || "RuntimeException".equals(referenceType);
    }

    public static Object build(String referenceType, String mirrorY, boolean excelFlavour,
            SentinelRegistry registry) {
        boolean isNull = mirrorY != null && mirrorY.contains("length_null");
        boolean isEmpty = mirrorY != null && mirrorY.contains("length_empty");
        if (isNull) {
            return null;
        }
        if ("MultipartFile".equals(referenceType)) {
            byte[] content;
            if (isEmpty) {
                content = FileFixtures.emptyBytes();
            } else if (excelFlavour) {
                content = FileFixtures.xlsxBytes();
            } else {
                content = FileFixtures.csvBytes();
            }
            return multipartFile(content, excelFlavour);
        }
        if ("InputStream".equals(referenceType)) {
            if (isEmpty) {
                return new ByteArrayInputStream(FileFixtures.emptyBytes());
            }
            return new ByteArrayInputStream(FileFixtures.csvBytes());
        }
        if ("IllegalArgumentException".equals(referenceType)) {
            return new IllegalArgumentException(isEmpty ? "" : EXCEPTION_MESSAGE);
        }
        if ("RuntimeException".equals(referenceType)) {
            return new RuntimeException(isEmpty ? "" : EXCEPTION_MESSAGE);
        }
        Class<?> type = ProjectTypes.loadOrNull(referenceType);
        if (type == null) {
            throw new HarnessException("Unsupported framework reference type " + referenceType);
        }
        return org.mockito.Mockito.mock(type, org.mockito.Mockito.withSettings()
                .defaultAnswer(new SentinelAnswer(registry)));
    }

    private static Object multipartFile(final byte[] content, final boolean excelFlavour) {
        Class<?> type = ProjectTypes.load("MultipartFile");
        return org.mockito.Mockito.mock(type, org.mockito.Mockito.withSettings().defaultAnswer(new Answer<Object>() {
            @Override
            public Object answer(InvocationOnMock invocation) throws Throwable {
                Method m = invocation.getMethod();
                String name = m.getName();
                if ("getInputStream".equals(name)) {
                    return new ByteArrayInputStream(content);
                }
                if ("getBytes".equals(name)) {
                    return content.clone();
                }
                if ("getOriginalFilename".equals(name)) {
                    return excelFlavour ? "fixture.xlsx" : "fixture.csv";
                }
                if ("getName".equals(name)) {
                    return "file";
                }
                if ("getContentType".equals(name)) {
                    return excelFlavour
                            ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            : "text/csv";
                }
                if ("getSize".equals(name)) {
                    return Long.valueOf(content.length);
                }
                if ("isEmpty".equals(name)) {
                    return Boolean.valueOf(content.length == 0);
                }
                if ("getResource".equals(name)) {
                    return null;
                }
                Class<?> ret = m.getReturnType();
                if (ret == void.class) {
                    return null;
                }
                if (ret == boolean.class) {
                    return Boolean.FALSE;
                }
                if (ret == long.class) {
                    return Long.valueOf(0L);
                }
                if (ret == int.class) {
                    return Integer.valueOf(0);
                }
                return null;
            }
        }));
    }
}

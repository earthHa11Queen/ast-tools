package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableController#applyToReal.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableControllerApplyToRealScenario {

    @Test
    @DisplayName("UTAPI-001108")
    void case_UTAPI_001108() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001108",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001108", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001108", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001108", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001108", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001108")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::ARG::1::-::name")
                    .mirror("-", "1:length_null", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001109")
    void case_UTAPI_001109() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001109",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001109", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001109", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001109", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001109", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001109")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::ARG::1::-::name")
                    .mirror("-", "2:length_empty", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001110")
    void case_UTAPI_001110() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001110",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001110", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001110", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001110", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001110", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001110")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::ARG::1::-::name")
                    .mirror("-", "3:length_min", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001111")
    void case_UTAPI_001111() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001111",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001111", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001111", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001111", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001111", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001111")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::ARG::1::-::name")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001112")
    void case_UTAPI_001112() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001112",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001112", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001112", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001112", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001112", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001112")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::ARG::1::-::name")
                    .mirror("-", "5:length_max", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001113")
    void case_UTAPI_001113() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001113",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001113", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001113", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001113", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001113", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001113")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::ARG::1::-::name")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001114")
    void case_UTAPI_001114() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001114",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001114", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001114", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001114", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001114", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001114")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::ARG::1::-::name")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001115")
    void case_UTAPI_001115() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001115",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001115", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001115", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001115", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001115", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001115")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::ARG::1::-::name")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001116")
    void case_UTAPI_001116() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001116",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001116", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001116", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001116", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001116", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001116")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::ARG::1::-::name")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001117")
    void case_UTAPI_001117() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001117",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001117", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001117", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001117", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001117", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001117")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::ARG::1::-::name")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001118")
    void case_UTAPI_001118() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001118",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001118", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001118", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001118", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001118", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001118")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::ARG::1::-::name")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001119")
    void case_UTAPI_001119() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001119",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001119", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001119", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001119", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001119", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001119")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::ARG::1::-::name")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001120")
    void case_UTAPI_001120() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001120",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001120", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001120", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001120", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001120", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001120")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::ARG::1::-::name")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001121")
    void case_UTAPI_001121() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001121",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001121", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001121", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001121", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001121", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001121")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::ARG::1::-::name")
                    .mirror("-", "-", "56:space")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001122")
    void case_UTAPI_001122() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001122",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001122", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001122", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001122", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001122", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001122")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::ARG::1::-::name")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001123")
    void case_UTAPI_001123() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001123",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001123", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001123", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001123", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001123", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001123")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::ARG::1::-::name")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001124")
    void case_UTAPI_001124() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001124",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001124", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001124", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001124", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001124", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001124")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::ARG::1::-::name")
                    .mirror("-", "-", "59:tab")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001125")
    void case_UTAPI_001125() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001125",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001125", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001125", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001125", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001125", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001125")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::ARG::1::-::name")
                    .mirror("-", "-", "60:control_character_null")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001126")
    void case_UTAPI_001126() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001126",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001126", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001126", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001126", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001126", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001126")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::ARG::1::-::name")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001127")
    void case_UTAPI_001127() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001127",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001127", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001127", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001127", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001127", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001127")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::ARG::1::-::name")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001128")
    void case_UTAPI_001128() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001128",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001128", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001128", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001128", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001128", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001128")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::ARG::1::-::name")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001129")
    void case_UTAPI_001129() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001129",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001129", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001129", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001129", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001129", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001129")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConflictCheckRequest.connectionId classifies this input condition", "ConflictCheckRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001130")
    void case_UTAPI_001130() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001130",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001130", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001130", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001130", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001130", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001130")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConflictCheckRequest.connectionId classifies this input condition", "ConflictCheckRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001131")
    void case_UTAPI_001131() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001131",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001131", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001131", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001131", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001131", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001131")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConflictCheckRequest.connectionId classifies this input condition", "ConflictCheckRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001132")
    void case_UTAPI_001132() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001132",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001132", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001132", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001132", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001132", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001132")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConflictCheckRequest.connectionId classifies this input condition", "ConflictCheckRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001133")
    void case_UTAPI_001133() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001133",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001133", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001133", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001133", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001133", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001133")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConflictCheckRequest.connectionId classifies this input condition", "ConflictCheckRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001134")
    void case_UTAPI_001134() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001134",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001134", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001134", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001134", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001134", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001134")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConflictCheckRequest.connectionId classifies this input condition", "ConflictCheckRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001135")
    void case_UTAPI_001135() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001135",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001135", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001135", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001135", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001135", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001135")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001136")
    void case_UTAPI_001136() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001136",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001136", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001136", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001136", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001136", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001136")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001137")
    void case_UTAPI_001137() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001137",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001137", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001137", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001137", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001137", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001137")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001138")
    void case_UTAPI_001138() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001138",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001138", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001138", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001138", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001138", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001138")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001139")
    void case_UTAPI_001139() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001139",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001139", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001139", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001139", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001139", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001139")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001140")
    void case_UTAPI_001140() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001140",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001140", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001140", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001140", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001140", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001140")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001141")
    void case_UTAPI_001141() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001141",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001141", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001141", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001141", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001141", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001141")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001142")
    void case_UTAPI_001142() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001142",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001142", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001142", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001142", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001142", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001142")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001143")
    void case_UTAPI_001143() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001143",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001143", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001143", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001143", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001143", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001143")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001144")
    void case_UTAPI_001144() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001144",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001144", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001144", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001144", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001144", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001144")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001145")
    void case_UTAPI_001145() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001145",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001145", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001145", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001145", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001145", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001145")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001146")
    void case_UTAPI_001146() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001146",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001146", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001146", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001146", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001146", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001146")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001147")
    void case_UTAPI_001147() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001147",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001147", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001147", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001147", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001147", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001147")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001148")
    void case_UTAPI_001148() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001148",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001148", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001148", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001148", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001148", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001148")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001149")
    void case_UTAPI_001149() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001149",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001149", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001149", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001149", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001149", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001149")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001150")
    void case_UTAPI_001150() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001150",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001150", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001150", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001150", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001150", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001150")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001151")
    void case_UTAPI_001151() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001151",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001151", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001151", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001151", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001151", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001151")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001152")
    void case_UTAPI_001152() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001152",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001152", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001152", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001152", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001152", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001152")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001153")
    void case_UTAPI_001153() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001153",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001153", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001153", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001153", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001153", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001153")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001154")
    void case_UTAPI_001154() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001154",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001154", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001154", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001154", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001154", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001154")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001155")
    void case_UTAPI_001155() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001155",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001155", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001155", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001155", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001155", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001155")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001156")
    void case_UTAPI_001156() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001156",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001156", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001156", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001156", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001156", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001156")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001157")
    void case_UTAPI_001157() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001157",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001157", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001157", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001157", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001157", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001157")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001158")
    void case_UTAPI_001158() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001158",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001158", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001158", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001158", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001158", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001158")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001159")
    void case_UTAPI_001159() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001159",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "applyToReal",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001159", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001159", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001159", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001159", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001159")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::applyToReal::13::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.applyToReal")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.applyToReal", "conflictUseCase", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.applyToReal must carry the value generated for request.connectionId", "conflictUseCase", "applyToReal", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.applyToReal must carry the value generated for request.schemaName", "conflictUseCase", "applyToReal", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.applyToReal must carry the value generated for name", "conflictUseCase", "applyToReal", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

}

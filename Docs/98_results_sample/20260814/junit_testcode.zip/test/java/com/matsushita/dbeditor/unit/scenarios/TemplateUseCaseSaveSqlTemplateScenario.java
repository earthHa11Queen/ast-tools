package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TemplateUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TemplateUseCase#saveSqlTemplate.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TemplateUseCaseSaveSqlTemplateScenario {

    @Test
    @DisplayName("UTAPI-012810")
    void case_UTAPI_012810() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012810",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012810", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012810", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012810")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::1::-::title")
                    .mirror("-", "1:length_null", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012811")
    void case_UTAPI_012811() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012811",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012811", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012811", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012811")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::1::-::title")
                    .mirror("-", "2:length_empty", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012812")
    void case_UTAPI_012812() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012812",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012812", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012812", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012812")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::1::-::title")
                    .mirror("-", "3:length_min", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012813")
    void case_UTAPI_012813() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012813",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012813", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012813", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012813")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::1::-::title")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012814")
    void case_UTAPI_012814() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012814",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012814", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012814", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012814")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::1::-::title")
                    .mirror("-", "5:length_max", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012815")
    void case_UTAPI_012815() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012815",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012815", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012815", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012815")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::1::-::title")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012816")
    void case_UTAPI_012816() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012816",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012816", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012816", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012816")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::1::-::title")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012817")
    void case_UTAPI_012817() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012817",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012817", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012817", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012817")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::1::-::title")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012818")
    void case_UTAPI_012818() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012818",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012818", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012818", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012818")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::1::-::title")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012819")
    void case_UTAPI_012819() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012819",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012819", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012819", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012819")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::1::-::title")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012820")
    void case_UTAPI_012820() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012820",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012820", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012820", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012820")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::1::-::title")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012821")
    void case_UTAPI_012821() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012821",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012821", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012821", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012821")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::1::-::title")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012822")
    void case_UTAPI_012822() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012822",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012822", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012822", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012822")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::1::-::title")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012823")
    void case_UTAPI_012823() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012823",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012823", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012823", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012823")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::1::-::title")
                    .mirror("-", "-", "56:space")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012824")
    void case_UTAPI_012824() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012824",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012824", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012824", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012824")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::1::-::title")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012825")
    void case_UTAPI_012825() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012825",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012825", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012825", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012825")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::1::-::title")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012826")
    void case_UTAPI_012826() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012826",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012826", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012826", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012826")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::1::-::title")
                    .mirror("-", "-", "59:tab")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012827")
    void case_UTAPI_012827() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012827",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012827", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012827", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012827")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::1::-::title")
                    .mirror("-", "-", "60:control_character_null")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012828")
    void case_UTAPI_012828() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012828",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012828", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012828", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012828")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::1::-::title")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012829")
    void case_UTAPI_012829() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012829",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012829", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012829", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012829")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::1::-::title")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012830")
    void case_UTAPI_012830() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012830",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012830", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012830", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012830")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::1::-::title")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012831")
    void case_UTAPI_012831() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012831",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012831", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012831", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012831")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::2::-::content")
                    .mirror("-", "1:length_null", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012832")
    void case_UTAPI_012832() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012832",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012832", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012832", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012832")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::2::-::content")
                    .mirror("-", "2:length_empty", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012833")
    void case_UTAPI_012833() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012833",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012833", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012833", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012833")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::2::-::content")
                    .mirror("-", "3:length_min", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012834")
    void case_UTAPI_012834() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012834",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012834", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012834", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012834")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::2::-::content")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012835")
    void case_UTAPI_012835() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012835",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012835", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012835", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012835")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::2::-::content")
                    .mirror("-", "5:length_max", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012836")
    void case_UTAPI_012836() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012836",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012836", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012836", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012836")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::2::-::content")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012837")
    void case_UTAPI_012837() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012837",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012837", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012837", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012837")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::2::-::content")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012838")
    void case_UTAPI_012838() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012838",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012838", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012838", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012838")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::2::-::content")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012839")
    void case_UTAPI_012839() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012839",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012839", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012839", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012839")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::2::-::content")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012840")
    void case_UTAPI_012840() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012840",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012840", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012840", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012840")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::2::-::content")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012841")
    void case_UTAPI_012841() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012841",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012841", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012841", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012841")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::2::-::content")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012842")
    void case_UTAPI_012842() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012842",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012842", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012842", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012842")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::2::-::content")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012843")
    void case_UTAPI_012843() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012843",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012843", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012843", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012843")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::2::-::content")
                    .mirror("-", "-", "56:space")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012844")
    void case_UTAPI_012844() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012844",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012844", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012844", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012844")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::2::-::content")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012845")
    void case_UTAPI_012845() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012845",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012845", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012845", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012845")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::2::-::content")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012846")
    void case_UTAPI_012846() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012846",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012846", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012846", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012846")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::2::-::content")
                    .mirror("-", "-", "59:tab")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012847")
    void case_UTAPI_012847() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012847",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012847", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012847", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012847")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::2::-::content")
                    .mirror("-", "-", "60:control_character_null")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012848")
    void case_UTAPI_012848() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012848",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012848", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012848", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012848")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::2::-::content")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012849")
    void case_UTAPI_012849() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012849",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012849", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012849", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012849")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::2::-::content")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012850")
    void case_UTAPI_012850() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012850",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveSqlTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012850", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012850", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012850")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveSqlTemplate::5::ARG::2::-::content")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.save", "sqlTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to sqlTemplateRepository.save must carry title", "sqlTemplateRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to sqlTemplateRepository.save must carry content", "sqlTemplateRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

}

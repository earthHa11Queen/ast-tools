package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableRecordUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableRecordUseCase#createCopy.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableRecordUseCaseCreateCopyScenario {

    @Test
    @DisplayName("UTAPI-013269")
    void case_UTAPI_013269() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013269",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013269", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013269", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013269", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013269")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013270")
    void case_UTAPI_013270() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013270",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013270", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013270", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013270", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013270")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013271")
    void case_UTAPI_013271() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013271",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013271", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013271", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013271", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013271")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013272")
    void case_UTAPI_013272() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013272",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013272", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013272", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013272", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013272")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013273")
    void case_UTAPI_013273() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013273",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013273", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013273", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013273", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013273")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013274")
    void case_UTAPI_013274() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013274",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013274", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013274", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013274", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013274")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013275")
    void case_UTAPI_013275() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013275",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013275", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013275", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013275", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013275")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013276")
    void case_UTAPI_013276() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013276",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013276", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013276", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013276", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013276")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013277")
    void case_UTAPI_013277() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013277",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013277", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013277", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013277", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013277")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013278")
    void case_UTAPI_013278() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013278",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013278", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013278", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013278", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013278")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013279")
    void case_UTAPI_013279() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013279",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013279", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013279", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013279", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013279")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013280")
    void case_UTAPI_013280() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013280",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013280", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013280", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013280", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013280")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013281")
    void case_UTAPI_013281() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013281",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013281", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013281", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013281", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013281")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013282")
    void case_UTAPI_013282() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013282",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013282", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013282", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013282", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013282")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013283")
    void case_UTAPI_013283() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013283",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013283", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013283", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013283", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013283")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013284")
    void case_UTAPI_013284() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013284",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013284", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013284", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013284", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013284")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013285")
    void case_UTAPI_013285() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013285",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013285", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013285", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013285", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013285")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013286")
    void case_UTAPI_013286() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013286",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013286", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013286", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013286", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013286")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013287")
    void case_UTAPI_013287() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013287",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013287", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013287", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013287", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013287")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013288")
    void case_UTAPI_013288() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013288",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013288", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013288", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013288", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013288")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013289")
    void case_UTAPI_013289() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013289",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013289", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013289", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013289", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013289")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013290")
    void case_UTAPI_013290() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013290",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013290", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013290", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013290", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013290")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013291")
    void case_UTAPI_013291() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013291",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013291", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013291", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013291", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013291")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013292")
    void case_UTAPI_013292() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013292",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013292", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013292", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013292", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013292")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013293")
    void case_UTAPI_013293() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013293",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013293", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013293", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013293", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013293")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013294")
    void case_UTAPI_013294() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013294",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013294", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013294", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013294", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013294")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013295")
    void case_UTAPI_013295() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013295",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013295", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013295", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013295", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013295")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013296")
    void case_UTAPI_013296() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013296",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013296", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013296", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013296", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013296")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013297")
    void case_UTAPI_013297() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013297",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013297", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013297", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013297", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013297")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013298")
    void case_UTAPI_013298() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013298",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013298", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013298", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013298", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013298")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013299")
    void case_UTAPI_013299() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013299",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013299", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013299", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013299", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013299")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013300")
    void case_UTAPI_013300() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013300",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013300", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013300", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013300", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013300")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013301")
    void case_UTAPI_013301() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013301",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013301", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013301", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013301", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013301")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013302")
    void case_UTAPI_013302() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013302",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013302", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013302", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013302", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013302")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013303")
    void case_UTAPI_013303() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013303",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013303", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013303", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013303", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013303")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013304")
    void case_UTAPI_013304() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013304",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013304", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013304", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013304", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013304")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013305")
    void case_UTAPI_013305() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013305",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013305", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013305", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013305", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013305")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013306")
    void case_UTAPI_013306() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013306",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013306", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013306", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013306", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013306")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013307")
    void case_UTAPI_013307() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013307",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013307", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013307", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013307", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013307")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013308")
    void case_UTAPI_013308() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013308",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013308", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013308", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013308", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013308")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013309")
    void case_UTAPI_013309() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013309",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013309", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013309", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013309", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013309")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013310")
    void case_UTAPI_013310() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013310",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013310", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013310", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013310", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013310")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013311")
    void case_UTAPI_013311() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013311",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013311", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013311", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013311", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013311")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013312")
    void case_UTAPI_013312() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013312",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013312", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013312", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013312", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013312")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013313")
    void case_UTAPI_013313() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013313",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013313", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013313", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013313", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013313")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013314")
    void case_UTAPI_013314() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013314",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013314", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013314", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013314", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013314")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013315")
    void case_UTAPI_013315() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013315",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013315", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013315", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013315", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013315")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013316")
    void case_UTAPI_013316() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013316",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013316", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013316", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013316", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013316")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013317")
    void case_UTAPI_013317() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013317",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013317", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013317", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013317", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013317")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013318")
    void case_UTAPI_013318() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013318",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013318", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013318", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013318", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013318")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013319")
    void case_UTAPI_013319() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013319",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013319", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013319", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013319", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013319")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013320")
    void case_UTAPI_013320() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013320",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013320", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013320", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013320", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013320")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013321")
    void case_UTAPI_013321() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013321",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "createCopy",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013321", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013321", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013321", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013321")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::createCopy::2::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.createCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.createCopyTable", "tableRecordRepository", "createCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.createCopyTable must carry the value generated for schemaName", "tableRecordRepository", "createCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.createCopyTable must carry the value generated for tableName", "tableRecordRepository", "createCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

}

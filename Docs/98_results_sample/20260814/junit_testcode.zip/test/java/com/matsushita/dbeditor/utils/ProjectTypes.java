package com.matsushita.dbeditor.utils;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Simple name to fully qualified name mapping taken from AST Source File Level.
 * Generated JUnit code references production classes by name only.
 */
public final class ProjectTypes {

    private ProjectTypes() {
    }

    private static final Map<String, String> FQCN;

    static {
        Map<String, String> m = new HashMap<String, String>();
        m.put("AutoMappingResponse", "com.matsushita.dbeditor.dto.outdto.AutoMappingResponse");
        m.put("ConflictCheckRequest", "com.matsushita.dbeditor.dto.indto.ConflictCheckRequest");
        m.put("ConflictCheckResponse", "com.matsushita.dbeditor.dto.outdto.ConflictCheckResponse");
        m.put("ConflictUseCase", "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase");
        m.put("ConnectionController", "com.matsushita.dbeditor.adapter.controller.ConnectionController");
        m.put("ConnectionSetting", "com.matsushita.dbeditor.domain.entity.ConnectionSetting");
        m.put("ConnectionSettingGateway", "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway");
        m.put("ConnectionSettingRepository", "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository");
        m.put("ConnectionSettingRequest", "com.matsushita.dbeditor.dto.indto.ConnectionSettingRequest");
        m.put("ConnectionSettingResponse", "com.matsushita.dbeditor.dto.outdto.ConnectionSettingResponse");
        m.put("ConnectionTestRequest", "com.matsushita.dbeditor.dto.indto.ConnectionTestRequest");
        m.put("ConnectionTestResponse", "com.matsushita.dbeditor.dto.outdto.ConnectionTestResponse");
        m.put("ConnectionUseCase", "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase");
        m.put("DbEditorApplication", "com.matsushita.dbeditor.DbEditorApplication");
        m.put("ExportController", "com.matsushita.dbeditor.adapter.controller.ExportController");
        m.put("ExportUseCase", "com.matsushita.dbeditor.usecase.file.ExportUseCase");
        m.put("GetTableListUseCase", "com.matsushita.dbeditor.usecase.table.GetTableListUseCase");
        m.put("GlobalExceptionHandler", "com.matsushita.dbeditor.infrastructure.exception.GlobalExceptionHandler");
        m.put("HealthController", "com.matsushita.dbeditor.adapter.controller.HealthController");
        m.put("ImportController", "com.matsushita.dbeditor.adapter.controller.ImportController");
        m.put("ImportGateway", "com.matsushita.dbeditor.adapter.gateway.ImportGateway");
        m.put("ImportRepository", "com.matsushita.dbeditor.domain.repository.ImportRepository");
        m.put("ImportUseCase", "com.matsushita.dbeditor.usecase.file.ImportUseCase");
        m.put("MappingApplyRequest", "com.matsushita.dbeditor.dto.indto.MappingApplyRequest");
        m.put("MemoController", "com.matsushita.dbeditor.adapter.controller.MemoController");
        m.put("MemoResponse", "com.matsushita.dbeditor.dto.outdto.MemoResponse");
        m.put("MemoSaveRequest", "com.matsushita.dbeditor.dto.indto.MemoSaveRequest");
        m.put("MemoTemplate", "com.matsushita.dbeditor.domain.entity.MemoTemplate");
        m.put("MemoTemplateGateway", "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway");
        m.put("MemoTemplateRepository", "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository");
        m.put("MemoUseCase", "com.matsushita.dbeditor.usecase.file.MemoUseCase");
        m.put("NewTableImportRequest", "com.matsushita.dbeditor.dto.indto.NewTableImportRequest");
        m.put("SavedSql", "com.matsushita.dbeditor.domain.entity.SavedSql");
        m.put("SavedSqlGateway", "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway");
        m.put("SavedSqlRepository", "com.matsushita.dbeditor.domain.repository.SavedSqlRepository");
        m.put("SqlController", "com.matsushita.dbeditor.adapter.controller.SqlController");
        m.put("SqlExecuteRequest", "com.matsushita.dbeditor.dto.indto.SqlExecuteRequest");
        m.put("SqlExecuteResponse", "com.matsushita.dbeditor.dto.outdto.SqlExecuteResponse");
        m.put("SqlResponse", "com.matsushita.dbeditor.dto.outdto.SqlResponse");
        m.put("SqlSaveRequest", "com.matsushita.dbeditor.dto.indto.SqlSaveRequest");
        m.put("SqlTemplate", "com.matsushita.dbeditor.domain.entity.SqlTemplate");
        m.put("SqlTemplateGateway", "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway");
        m.put("SqlTemplateRepository", "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository");
        m.put("SqlUseCase", "com.matsushita.dbeditor.usecase.sql.SqlUseCase");
        m.put("TableConflictGateway", "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway");
        m.put("TableConflictRepository", "com.matsushita.dbeditor.domain.repository.TableConflictRepository");
        m.put("TableController", "com.matsushita.dbeditor.adapter.controller.TableController");
        m.put("TableHistoryGateway", "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway");
        m.put("TableHistoryRepository", "com.matsushita.dbeditor.domain.repository.TableHistoryRepository");
        m.put("TableHistoryResponse", "com.matsushita.dbeditor.dto.outdto.TableHistoryResponse");
        m.put("TableHistorySaveRequest", "com.matsushita.dbeditor.dto.indto.TableHistorySaveRequest");
        m.put("TableHistoryUseCase", "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase");
        m.put("TableMemo", "com.matsushita.dbeditor.domain.entity.TableMemo");
        m.put("TableMemoGateway", "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway");
        m.put("TableMemoRepository", "com.matsushita.dbeditor.domain.repository.TableMemoRepository");
        m.put("TableMetadata", "com.matsushita.dbeditor.domain.entity.TableMetadata");
        m.put("TableMetadataGateway", "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway");
        m.put("TableMetadataRepository", "com.matsushita.dbeditor.domain.repository.TableMetadataRepository");
        m.put("TableMetadataResponse", "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse");
        m.put("TableNameValidator", "com.matsushita.dbeditor.infrastructure.database.TableNameValidator");
        m.put("TableRecordGateway", "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway");
        m.put("TableRecordRepository", "com.matsushita.dbeditor.domain.repository.TableRecordRepository");
        m.put("TableRecordUpdateRequest", "com.matsushita.dbeditor.dto.indto.TableRecordUpdateRequest");
        m.put("TableRecordUseCase", "com.matsushita.dbeditor.usecase.table.TableRecordUseCase");
        m.put("TargetDatabaseConnector", "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector");
        m.put("TemplateController", "com.matsushita.dbeditor.adapter.controller.TemplateController");
        m.put("TemplateRequest", "com.matsushita.dbeditor.dto.indto.TemplateRequest");
        m.put("TemplateResponse", "com.matsushita.dbeditor.dto.outdto.TemplateResponse");
        m.put("TemplateUseCase", "com.matsushita.dbeditor.usecase.file.TemplateUseCase");
        m.put("WebConfig", "com.matsushita.dbeditor.infrastructure.config.WebConfig");
        m.put("CorsRegistry", "org.springframework.web.servlet.config.annotation.CorsRegistry");
        m.put("DataSource", "javax.sql.DataSource");
        m.put("DriverManagerDataSource", "org.springframework.jdbc.datasource.DriverManagerDataSource");
        m.put("HttpHeaders", "org.springframework.http.HttpHeaders");
        m.put("IllegalArgumentException", "java.lang.IllegalArgumentException");
        m.put("InputStream", "java.io.InputStream");
        m.put("JdbcTemplate", "org.springframework.jdbc.core.JdbcTemplate");
        m.put("LocalDateTime", "java.time.LocalDateTime");
        m.put("MultipartFile", "org.springframework.web.multipart.MultipartFile");
        m.put("ResponseEntity", "org.springframework.http.ResponseEntity");
        m.put("RowMapper", "org.springframework.jdbc.core.RowMapper");
        m.put("RuntimeException", "java.lang.RuntimeException");
        m.put("SpringApplication", "org.springframework.boot.SpringApplication");
        FQCN = Collections.unmodifiableMap(m);
    }

    public static boolean isProjectType(String simpleName) {
        return FQCN.containsKey(simpleName);
    }

    public static String fqcn(String simpleName) {
        String v = FQCN.get(simpleName);
        if (v == null) {
            return simpleName;
        }
        return v;
    }

    public static Class<?> load(String simpleOrFqcn) {
        String name = fqcn(simpleOrFqcn);
        try {
            return Class.forName(name);
        } catch (ClassNotFoundException e) {
            throw new HarnessException("Class not found: " + name, e);
        }
    }

    public static Class<?> loadOrNull(String simpleOrFqcn) {
        try {
            return Class.forName(fqcn(simpleOrFqcn));
        } catch (Throwable t) {
            return null;
        }
    }
}

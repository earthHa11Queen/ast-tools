package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableController#getStaleTables.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableControllerGetStaleTablesScenario {

    @Test
    @DisplayName("UTAPI-001524")
    void case_UTAPI_001524() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001524",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001524", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001524", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001524")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001525")
    void case_UTAPI_001525() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001525",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001525", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001525", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001525")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001526")
    void case_UTAPI_001526() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001526",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001526", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001526", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001526")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001527")
    void case_UTAPI_001527() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001527",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001527", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001527", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001527")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001528")
    void case_UTAPI_001528() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001528",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001528", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001528", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001528")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001529")
    void case_UTAPI_001529() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001529",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001529", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001529", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001529")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001530")
    void case_UTAPI_001530() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001530",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001530", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001530", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001530")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001531")
    void case_UTAPI_001531() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001531",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001531", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001531", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001531")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001532")
    void case_UTAPI_001532() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001532",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001532", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001532", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001532")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001533")
    void case_UTAPI_001533() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001533",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001533", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001533", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001533")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001534")
    void case_UTAPI_001534() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001534",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001534", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001534", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001534")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001535")
    void case_UTAPI_001535() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001535",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001535", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001535", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001535")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::2::-::schema")
                    .mirror("-", "1:length_null", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001536")
    void case_UTAPI_001536() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001536",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001536", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001536", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001536")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::2::-::schema")
                    .mirror("-", "2:length_empty", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001537")
    void case_UTAPI_001537() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001537",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001537", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001537", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001537")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::2::-::schema")
                    .mirror("-", "3:length_min", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001538")
    void case_UTAPI_001538() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001538",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001538", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001538", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001538")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::2::-::schema")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001539")
    void case_UTAPI_001539() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001539",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001539", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001539", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001539")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::2::-::schema")
                    .mirror("-", "5:length_max", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001540")
    void case_UTAPI_001540() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001540",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001540", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001540", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001540")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::2::-::schema")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001541")
    void case_UTAPI_001541() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001541",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001541", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001541", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001541")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::2::-::schema")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001542")
    void case_UTAPI_001542() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001542",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001542", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001542", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001542")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::2::-::schema")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001543")
    void case_UTAPI_001543() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001543",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001543", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001543", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001543")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::2::-::schema")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001544")
    void case_UTAPI_001544() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001544",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001544", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001544", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001544")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::2::-::schema")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001545")
    void case_UTAPI_001545() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001545",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001545", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001545", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001545")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::2::-::schema")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001546")
    void case_UTAPI_001546() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001546",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001546", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001546", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001546")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::2::-::schema")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001547")
    void case_UTAPI_001547() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001547",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001547", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001547", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001547")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::2::-::schema")
                    .mirror("-", "-", "56:space")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001548")
    void case_UTAPI_001548() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001548",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001548", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001548", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001548")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::2::-::schema")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001549")
    void case_UTAPI_001549() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001549",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001549", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001549", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001549")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::2::-::schema")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001550")
    void case_UTAPI_001550() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001550",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001550", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001550", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001550")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::2::-::schema")
                    .mirror("-", "-", "59:tab")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001551")
    void case_UTAPI_001551() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001551",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001551", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001551", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001551")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::2::-::schema")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001552")
    void case_UTAPI_001552() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001552",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001552", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001552", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001552")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::2::-::schema")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001553")
    void case_UTAPI_001553() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001553",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001553", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001553", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001553")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::2::-::schema")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001554")
    void case_UTAPI_001554() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001554",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getStaleTables",
                "ResponseEntity<List<String>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001554", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001554", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001554")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getStaleTables::1::ARG::2::-::schema")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getStaleTables")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getStaleTables", "tableRecordUseCase", "getStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getStaleTables must carry the value generated for connectionId", "tableRecordUseCase", "getStaleTables", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getStaleTables must carry the value generated for schema", "tableRecordUseCase", "getStaleTables", "1", "data:schema")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

}

package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for ExportUseCase.
 */
public final class ExportUseCaseWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.usecase.file.ExportUseCase";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.usecase.file.ExportUseCase";
    private static final String[] DEP_NAMES = new String[] {"tableRecordUseCase"};
    private static final String[] DEP_TYPES = new String[] {"TableRecordUseCase"};
    private static final String[] TYPES_exportCsv = new String[] {"Integer", "String", "String"};
    private static final String[] TYPES_exportExcel = new String[] {"Integer", "String", "String"};
    private static final String[] TYPES_exportMarkdown = new String[] {"Integer", "String", "String"};
    private static final String[] TYPES_toCsvLine = new String[] {"List<String>"};

    public ExportUseCaseWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, false);
    }

    /** byte[] exportCsv(connectionId, schemaName, tableName) */
    public ExecutionResult exportCsv(Object[] args) {
        return invoke("exportCsv", TYPES_exportCsv, args);
    }

    /** byte[] exportExcel(connectionId, schemaName, tableName) */
    public ExecutionResult exportExcel(Object[] args) {
        return invoke("exportExcel", TYPES_exportExcel, args);
    }

    /** byte[] exportMarkdown(connectionId, schemaName, tableName) */
    public ExecutionResult exportMarkdown(Object[] args) {
        return invoke("exportMarkdown", TYPES_exportMarkdown, args);
    }

    /** String toCsvLine(fields) */
    public ExecutionResult toCsvLine(Object[] args) {
        return invoke("toCsvLine", TYPES_toCsvLine, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("exportCsv".equals(operation)) {
            return exportCsv(args);
        } else if ("exportExcel".equals(operation)) {
            return exportExcel(args);
        } else if ("exportMarkdown".equals(operation)) {
            return exportMarkdown(args);
        } else if ("toCsvLine".equals(operation)) {
            return toCsvLine(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

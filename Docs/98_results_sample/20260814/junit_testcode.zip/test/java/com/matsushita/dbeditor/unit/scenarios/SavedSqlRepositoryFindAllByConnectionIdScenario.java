package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SavedSqlRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SavedSqlRepository#findAllByConnectionId.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SavedSqlRepositoryFindAllByConnectionIdScenario {

    @Test
    @DisplayName("UTAPI-007099")
    void case_UTAPI_007099() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007099",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "findAllByConnectionId",
                "List<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007099", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007099")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::findAllByConnectionId::1::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the listing must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007100")
    void case_UTAPI_007100() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007100",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "findAllByConnectionId",
                "List<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007100", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007100")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::findAllByConnectionId::1::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the listing must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007101")
    void case_UTAPI_007101() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007101",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "findAllByConnectionId",
                "List<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007101", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007101")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::findAllByConnectionId::1::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the listing must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007102")
    void case_UTAPI_007102() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007102",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "findAllByConnectionId",
                "List<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007102", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007102")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::findAllByConnectionId::1::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the listing must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007103")
    void case_UTAPI_007103() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007103",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "findAllByConnectionId",
                "List<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007103", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007103")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::findAllByConnectionId::1::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the listing must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007104")
    void case_UTAPI_007104() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007104",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "findAllByConnectionId",
                "List<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007104", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007104")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::findAllByConnectionId::1::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the listing must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007105")
    void case_UTAPI_007105() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007105",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "findAllByConnectionId",
                "List<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007105", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007105")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::findAllByConnectionId::1::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the listing must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007106")
    void case_UTAPI_007106() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007106",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "findAllByConnectionId",
                "List<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007106", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007106")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::findAllByConnectionId::1::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the listing must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007107")
    void case_UTAPI_007107() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007107",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "findAllByConnectionId",
                "List<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007107", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007107")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::findAllByConnectionId::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the listing must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007108")
    void case_UTAPI_007108() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007108",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "findAllByConnectionId",
                "List<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007108", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007108")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::findAllByConnectionId::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the listing must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007109")
    void case_UTAPI_007109() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007109",
                "com.matsushita.dbeditor.domain.repository.SavedSqlRepository",
                "findAllByConnectionId",
                "List<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007109", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007109")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SavedSqlRepository.java::SavedSqlRepository::findAllByConnectionId::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the listing must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlRepositoryWrapper());
    }

}

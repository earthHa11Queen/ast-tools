package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ConnectionSettingGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ConnectionSettingGateway#update.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ConnectionSettingGatewayUpdateScenario {

    @Test
    @DisplayName("UTAPI-002104")
    void case_UTAPI_002104() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002104",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002104", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002104", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002104", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002104", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002104", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002104", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002104", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002104", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002104", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002104", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002104")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.INPUT_FIELD_UNCHANGED, "an update must not rewrite the creation time of the supplied record", "setting", "getCreatedTimestamp", "data:setting.createdTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002105")
    void case_UTAPI_002105() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002105",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002105", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002105", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002105", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002105", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002105", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002105", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002105", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002105", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002105", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002105", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002105")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.INPUT_FIELD_UNCHANGED, "an update must not rewrite the creation time of the supplied record", "setting", "getCreatedTimestamp", "data:setting.createdTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002106")
    void case_UTAPI_002106() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002106",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002106", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002106", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002106", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002106", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002106", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002106", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002106", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002106", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002106", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002106", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002106")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.INPUT_FIELD_UNCHANGED, "an update must not rewrite the creation time of the supplied record", "setting", "getCreatedTimestamp", "data:setting.createdTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002107")
    void case_UTAPI_002107() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002107",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002107", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002107", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002107", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002107", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002107", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002107", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002107", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002107", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002107", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002107", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002107")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.INPUT_FIELD_UNCHANGED, "an update must not rewrite the creation time of the supplied record", "setting", "getCreatedTimestamp", "data:setting.createdTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002108")
    void case_UTAPI_002108() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002108",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002108", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002108", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002108", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002108", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002108", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002108", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002108", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002108", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002108", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002108", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002108")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.INPUT_FIELD_UNCHANGED, "an update must not rewrite the creation time of the supplied record", "setting", "getCreatedTimestamp", "data:setting.createdTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002109")
    void case_UTAPI_002109() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002109",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002109", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002109", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002109", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002109", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002109", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002109", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002109", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002109", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002109", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002109", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002109")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.INPUT_FIELD_UNCHANGED, "an update must not rewrite the creation time of the supplied record", "setting", "getCreatedTimestamp", "data:setting.createdTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002110")
    void case_UTAPI_002110() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002110",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002110", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002110", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002110", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002110", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002110", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002110", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002110", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002110", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002110", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002110", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002110")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.INPUT_FIELD_UNCHANGED, "an update must not rewrite the creation time of the supplied record", "setting", "getCreatedTimestamp", "data:setting.createdTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002111")
    void case_UTAPI_002111() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002111",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002111", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002111", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002111", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002111", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002111", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002111", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002111", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002111", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002111", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002111", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002111")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.INPUT_FIELD_UNCHANGED, "an update must not rewrite the creation time of the supplied record", "setting", "getCreatedTimestamp", "data:setting.createdTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002112")
    void case_UTAPI_002112() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002112",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002112", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002112", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002112", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002112", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002112", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002112", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002112", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002112", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002112", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002112", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002112")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002113")
    void case_UTAPI_002113() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002113",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002113", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002113", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002113", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002113", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002113", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002113", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002113", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002113", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002113", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002113", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002113")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002114")
    void case_UTAPI_002114() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002114",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002114", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002114", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002114", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002114", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002114", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002114", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002114", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002114", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002114", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002114", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002114")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002115")
    void case_UTAPI_002115() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002115",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002115", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002115", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002115", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002115", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002115", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002115", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002115", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002115", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002115", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002115", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002115")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002116")
    void case_UTAPI_002116() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002116",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002116", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002116", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002116", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002116", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002116", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002116", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002116", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002116", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002116", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002116", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002116")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002117")
    void case_UTAPI_002117() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002117",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002117", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002117", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002117", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002117", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002117", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002117", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002117", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002117", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002117", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002117", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002117")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002118")
    void case_UTAPI_002118() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002118",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002118", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002118", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002118", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002118", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002118", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002118", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002118", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002118", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002118", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002118", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002118")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002119")
    void case_UTAPI_002119() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002119",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002119", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002119", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002119", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002119", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002119", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002119", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002119", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002119", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002119", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002119", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002119")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002120")
    void case_UTAPI_002120() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002120",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002120", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002120", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002120", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002120", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002120", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002120", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002120", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002120", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002120", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002120", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002120")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002121")
    void case_UTAPI_002121() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002121",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002121", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002121", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002121", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002121", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002121", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002121", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002121", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002121", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002121", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002121", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002121")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002122")
    void case_UTAPI_002122() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002122",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002122", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002122", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002122", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002122", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002122", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002122", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002122", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002122", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002122", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002122", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002122")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002123")
    void case_UTAPI_002123() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002123",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002123", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002123", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002123", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002123", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002123", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002123", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002123", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002123", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002123", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002123", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002123")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002124")
    void case_UTAPI_002124() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002124",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002124", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002124", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002124", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002124", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002124", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002124", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002124", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002124", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002124", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002124", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002124")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002125")
    void case_UTAPI_002125() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002125",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002125", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002125", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002125", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002125", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002125", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002125", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002125", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002125", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002125", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002125", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002125")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002126")
    void case_UTAPI_002126() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002126",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002126", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002126", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002126", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002126", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002126", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002126", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002126", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002126", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002126", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002126", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002126")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002127")
    void case_UTAPI_002127() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002127",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002127", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002127", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002127", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002127", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002127", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002127", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002127", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002127", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002127", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002127", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002127")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002128")
    void case_UTAPI_002128() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002128",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002128", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002128", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002128", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002128", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002128", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002128", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002128", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002128", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002128", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002128", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002128")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002129")
    void case_UTAPI_002129() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002129",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002129", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002129", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002129", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002129", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002129", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002129", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002129", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002129", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002129", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002129", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002129")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002130")
    void case_UTAPI_002130() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002130",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002130", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002130", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002130", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002130", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002130", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002130", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002130", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002130", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002130", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002130", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002130")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002131")
    void case_UTAPI_002131() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002131",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002131", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002131", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002131", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002131", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002131", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002131", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002131", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002131", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002131", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002131", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002131")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002132")
    void case_UTAPI_002132() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002132",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002132", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002132", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002132", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002132", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002132", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002132", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002132", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002132", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002132", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002132", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002132")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002133")
    void case_UTAPI_002133() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002133",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002133", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002133", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002133", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002133", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002133", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002133", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002133", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002133", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002133", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002133", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002133")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002134")
    void case_UTAPI_002134() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002134",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002134", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002134", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002134", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002134", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002134", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002134", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002134", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002134", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002134", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002134", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002134")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002135")
    void case_UTAPI_002135() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002135",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002135", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002135", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002135", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002135", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002135", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002135", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002135", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002135", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002135", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002135", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002135")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002136")
    void case_UTAPI_002136() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002136",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002136", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002136", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002136", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002136", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002136", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002136", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002136", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002136", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002136", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002136", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002136")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002137")
    void case_UTAPI_002137() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002137",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002137", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002137", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002137", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002137", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002137", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002137", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002137", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002137", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002137", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002137", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002137")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002138")
    void case_UTAPI_002138() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002138",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002138", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002138", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002138", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002138", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002138", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002138", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002138", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002138", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002138", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002138", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002138")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002139")
    void case_UTAPI_002139() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002139",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002139", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002139", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002139", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002139", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002139", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002139", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002139", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002139", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002139", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002139", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002139")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002140")
    void case_UTAPI_002140() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002140",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002140", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002140", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002140", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002140", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002140", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002140", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002140", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002140", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002140", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002140", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002140")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002141")
    void case_UTAPI_002141() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002141",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002141", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002141", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002141", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002141", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002141", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002141", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002141", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002141", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002141", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002141", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002141")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002142")
    void case_UTAPI_002142() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002142",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002142", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002142", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002142", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002142", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002142", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002142", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002142", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002142", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002142", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002142", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002142")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002143")
    void case_UTAPI_002143() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002143",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002143", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002143", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002143", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002143", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002143", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002143", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002143", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002143", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002143", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002143", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002143")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002144")
    void case_UTAPI_002144() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002144",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002144", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002144", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002144", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002144", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002144", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002144", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002144", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002144", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002144", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002144", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002144")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002145")
    void case_UTAPI_002145() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002145",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002145", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002145", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002145", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002145", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002145", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002145", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002145", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002145", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002145", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002145", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002145")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002146")
    void case_UTAPI_002146() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002146",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002146", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002146", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002146", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002146", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002146", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002146", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002146", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002146", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002146", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002146", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002146")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002147")
    void case_UTAPI_002147() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002147",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002147", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002147", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002147", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002147", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002147", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002147", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002147", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002147", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002147", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002147", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002147")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002148")
    void case_UTAPI_002148() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002148",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002148", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002148", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002148", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002148", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002148", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002148", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002148", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002148", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002148", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002148", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002148")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002149")
    void case_UTAPI_002149() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002149",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002149", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002149", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002149", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002149", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002149", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002149", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002149", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002149", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002149", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002149", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002149")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002150")
    void case_UTAPI_002150() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002150",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002150", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002150", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002150", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002150", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002150", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002150", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002150", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002150", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002150", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002150", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002150")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002151")
    void case_UTAPI_002151() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002151",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002151", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002151", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002151", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002151", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002151", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002151", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002151", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002151", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002151", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002151", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002151")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002152")
    void case_UTAPI_002152() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002152",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002152", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002152", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002152", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002152", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002152", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002152", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002152", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002152", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002152", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002152", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002152")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002153")
    void case_UTAPI_002153() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002153",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002153", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002153", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002153", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002153", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002153", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002153", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002153", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002153", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002153", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002153", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002153")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002154")
    void case_UTAPI_002154() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002154",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002154", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002154", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002154", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002154", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002154", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002154", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002154", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002154", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002154", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002154", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002154")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002155")
    void case_UTAPI_002155() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002155",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002155", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002155", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002155", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002155", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002155", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002155", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002155", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002155", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002155", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002155", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002155")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002156")
    void case_UTAPI_002156() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002156",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002156", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002156", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002156", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002156", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002156", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002156", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002156", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002156", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002156", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002156", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002156")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002157")
    void case_UTAPI_002157() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002157",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002157", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002157", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002157", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002157", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002157", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002157", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002157", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002157", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002157", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002157", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002157")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002158")
    void case_UTAPI_002158() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002158",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002158", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002158", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002158", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002158", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002158", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002158", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002158", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002158", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002158", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002158", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002158")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002159")
    void case_UTAPI_002159() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002159",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002159", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002159", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002159", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002159", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002159", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002159", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002159", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002159", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002159", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002159", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002159")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002160")
    void case_UTAPI_002160() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002160",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002160", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002160", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002160", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002160", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002160", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002160", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002160", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002160", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002160", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002160", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002160")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002161")
    void case_UTAPI_002161() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002161",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002161", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002161", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002161", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002161", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002161", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002161", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002161", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002161", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002161", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002161", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002161")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002162")
    void case_UTAPI_002162() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002162",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002162", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002162", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002162", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002162", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002162", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002162", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002162", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002162", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002162", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002162", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002162")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002163")
    void case_UTAPI_002163() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002163",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002163", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002163", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002163", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002163", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002163", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002163", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002163", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002163", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002163", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002163", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002163")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002164")
    void case_UTAPI_002164() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002164",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002164", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002164", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002164", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002164", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002164", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002164", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002164", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002164", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002164", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002164", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002164")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002165")
    void case_UTAPI_002165() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002165",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002165", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002165", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002165", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002165", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002165", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002165", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002165", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002165", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002165", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002165", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002165")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002166")
    void case_UTAPI_002166() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002166",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002166", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002166", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002166", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002166", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002166", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002166", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002166", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002166", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002166", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002166", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002166")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002167")
    void case_UTAPI_002167() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002167",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002167", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002167", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002167", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002167", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002167", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002167", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002167", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002167", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002167", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002167", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002167")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002168")
    void case_UTAPI_002168() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002168",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002168", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002168", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002168", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002168", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002168", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002168", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002168", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002168", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002168", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002168", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002168")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002169")
    void case_UTAPI_002169() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002169",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002169", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002169", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002169", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002169", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002169", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002169", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002169", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002169", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002169", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002169", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002169")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002170")
    void case_UTAPI_002170() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002170",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002170", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002170", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002170", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002170", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002170", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002170", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002170", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002170", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002170", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002170", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002170")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002171")
    void case_UTAPI_002171() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002171",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002171", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002171", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002171", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002171", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002171", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002171", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002171", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002171", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002171", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002171", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002171")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002172")
    void case_UTAPI_002172() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002172",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002172", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002172", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002172", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002172", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002172", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002172", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002172", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002172", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002172", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002172", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002172")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002173")
    void case_UTAPI_002173() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002173",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002173", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002173", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002173", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002173", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002173", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002173", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002173", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002173", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002173", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002173", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002173")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002174")
    void case_UTAPI_002174() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002174",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002174", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002174", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002174", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002174", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002174", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002174", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002174", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002174", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002174", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002174", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002174")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002175")
    void case_UTAPI_002175() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002175",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002175", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002175", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002175", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002175", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002175", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002175", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002175", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002175", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002175", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002175", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002175")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002176")
    void case_UTAPI_002176() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002176",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002176", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002176", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002176", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002176", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002176", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002176", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002176", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002176", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002176", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002176", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002176")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002177")
    void case_UTAPI_002177() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002177",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002177", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002177", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002177", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002177", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002177", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002177", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002177", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002177", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002177", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002177", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002177")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002178")
    void case_UTAPI_002178() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002178",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002178", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002178", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002178", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002178", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002178", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002178", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002178", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002178", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002178", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002178", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002178")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002179")
    void case_UTAPI_002179() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002179",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002179", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002179", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002179", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002179", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002179", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002179", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002179", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002179", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002179", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002179", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002179")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002180")
    void case_UTAPI_002180() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002180",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002180", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002180", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002180", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002180", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002180", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002180", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002180", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002180", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002180", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002180", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002180")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002181")
    void case_UTAPI_002181() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002181",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002181", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002181", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002181", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002181", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002181", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002181", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002181", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002181", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002181", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002181", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002181")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002182")
    void case_UTAPI_002182() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002182",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002182", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002182", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002182", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002182", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002182", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002182", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002182", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002182", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002182", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002182", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002182")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002183")
    void case_UTAPI_002183() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002183",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002183", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002183", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002183", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002183", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002183", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002183", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002183", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002183", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002183", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002183", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002183")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002184")
    void case_UTAPI_002184() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002184",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002184", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002184", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002184", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002184", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002184", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002184", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002184", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002184", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002184", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002184", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002184")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002185")
    void case_UTAPI_002185() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002185",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002185", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002185", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002185", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002185", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002185", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002185", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002185", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002185", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002185", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002185", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002185")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002186")
    void case_UTAPI_002186() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002186",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002186", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002186", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002186", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002186", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002186", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002186", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002186", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002186", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002186", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002186", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002186")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002187")
    void case_UTAPI_002187() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002187",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002187", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002187", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002187", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002187", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002187", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002187", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002187", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002187", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002187", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002187", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002187")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002188")
    void case_UTAPI_002188() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002188",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002188", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002188", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002188", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002188", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002188", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002188", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002188", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002188", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002188", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002188", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002188")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002189")
    void case_UTAPI_002189() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002189",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002189", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002189", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002189", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002189", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002189", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002189", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002189", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002189", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002189", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002189", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002189")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002190")
    void case_UTAPI_002190() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002190",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002190", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002190", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002190", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002190", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002190", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002190", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002190", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002190", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002190", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002190", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002190")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002191")
    void case_UTAPI_002191() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002191",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002191", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002191", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002191", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002191", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002191", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002191", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002191", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002191", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002191", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002191", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002191")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002192")
    void case_UTAPI_002192() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002192",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002192", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002192", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002192", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002192", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002192", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002192", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002192", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002192", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002192", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002192", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002192")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002193")
    void case_UTAPI_002193() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002193",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002193", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002193", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002193", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002193", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002193", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002193", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002193", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002193", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002193", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002193", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002193")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002194")
    void case_UTAPI_002194() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002194",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002194", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002194", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002194", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002194", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002194", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002194", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002194", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002194", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002194", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002194", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002194")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002195")
    void case_UTAPI_002195() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002195",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002195", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002195", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002195", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002195", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002195", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002195", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002195", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002195", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002195", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002195", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002195")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002196")
    void case_UTAPI_002196() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002196",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002196", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002196", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002196", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002196", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002196", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002196", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002196", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002196", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002196", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002196", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002196")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002197")
    void case_UTAPI_002197() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002197",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002197", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002197", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002197", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002197", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002197", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002197", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002197", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002197", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002197", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002197", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002197")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002198")
    void case_UTAPI_002198() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002198",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002198", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002198", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002198", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002198", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002198", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002198", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002198", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002198", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002198", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002198", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002198")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002199")
    void case_UTAPI_002199() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002199",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002199", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002199", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002199", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002199", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002199", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002199", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002199", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002199", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002199", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002199", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002199")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002200")
    void case_UTAPI_002200() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002200",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002200", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002200", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002200", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002200", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002200", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002200", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002200", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002200", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002200", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002200", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002200")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002201")
    void case_UTAPI_002201() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002201",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002201", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002201", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002201", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002201", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002201", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002201", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002201", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002201", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002201", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002201", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002201")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002202")
    void case_UTAPI_002202() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002202",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002202", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002202", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002202", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002202", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002202", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002202", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002202", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002202", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002202", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002202", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002202")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002203")
    void case_UTAPI_002203() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002203",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002203", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002203", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002203", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002203", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002203", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002203", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002203", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002203", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002203", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002203", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002203")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002204")
    void case_UTAPI_002204() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002204",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002204", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002204", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002204", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002204", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002204", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002204", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002204", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002204", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002204", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002204", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002204")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002205")
    void case_UTAPI_002205() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002205",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002205", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002205", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002205", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002205", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002205", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002205", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002205", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002205", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002205", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002205", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002205")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002206")
    void case_UTAPI_002206() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002206",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002206", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002206", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002206", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002206", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002206", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002206", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002206", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002206", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002206", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002206", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002206")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002207")
    void case_UTAPI_002207() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002207",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002207", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002207", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002207", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002207", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002207", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002207", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002207", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002207", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002207", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002207", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002207")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002208")
    void case_UTAPI_002208() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002208",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002208", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002208", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002208", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002208", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002208", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002208", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002208", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002208", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002208", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002208", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002208")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002209")
    void case_UTAPI_002209() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002209",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002209", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002209", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002209", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002209", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002209", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002209", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002209", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002209", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002209", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002209", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002209")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002210")
    void case_UTAPI_002210() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002210",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002210", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002210", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002210", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002210", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002210", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002210", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002210", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002210", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002210", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002210", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002210")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002211")
    void case_UTAPI_002211() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002211",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002211", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002211", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002211", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002211", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002211", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002211", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002211", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002211", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002211", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002211", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002211")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002212")
    void case_UTAPI_002212() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002212",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002212", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002212", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002212", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002212", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002212", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002212", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002212", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002212", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002212", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002212", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002212")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002213")
    void case_UTAPI_002213() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002213",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002213", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002213", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002213", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002213", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002213", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002213", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002213", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002213", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002213", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002213", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002213")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002214")
    void case_UTAPI_002214() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002214",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002214", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002214", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002214", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002214", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002214", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002214", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002214", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002214", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002214", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002214", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002214")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002215")
    void case_UTAPI_002215() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002215",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002215", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002215", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002215", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002215", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002215", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002215", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002215", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002215", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002215", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002215", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002215")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002216")
    void case_UTAPI_002216() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002216",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002216", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002216", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002216", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002216", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002216", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002216", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002216", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002216", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002216", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002216", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002216")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002217")
    void case_UTAPI_002217() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002217",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002217", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002217", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002217", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002217", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002217", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002217", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002217", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002217", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002217", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002217", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002217")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002218")
    void case_UTAPI_002218() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002218",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002218", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002218", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002218", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002218", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002218", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002218", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002218", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002218", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002218", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002218", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002218")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002219")
    void case_UTAPI_002219() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002219",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002219", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002219", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002219", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002219", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002219", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002219", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002219", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002219", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002219", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002219", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002219")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002220")
    void case_UTAPI_002220() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002220",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002220", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002220", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002220", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002220", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002220", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002220", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002220", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002220", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002220", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002220", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002220")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002221")
    void case_UTAPI_002221() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002221",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002221", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002221", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002221", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002221", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002221", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002221", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002221", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002221", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002221", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002221", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002221")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002222")
    void case_UTAPI_002222() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002222",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002222", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002222", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002222", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002222", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002222", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002222", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002222", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002222", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002222", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002222", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002222")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002223")
    void case_UTAPI_002223() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002223",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002223", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002223", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002223", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002223", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002223", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002223", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002223", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002223", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002223", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002223", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002223")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002224")
    void case_UTAPI_002224() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002224",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002224", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002224", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002224", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002224", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002224", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002224", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002224", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002224", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002224", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002224", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002224")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002225")
    void case_UTAPI_002225() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002225",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002225", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002225", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002225", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002225", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002225", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002225", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002225", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002225", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002225", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002225", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002225")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002226")
    void case_UTAPI_002226() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002226",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002226", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002226", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002226", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002226", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002226", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002226", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002226", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002226", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002226", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002226", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002226")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:setting.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002227")
    void case_UTAPI_002227() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002227",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002227", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002227", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002227", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002227", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002227", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002227", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002227", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002227", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002227", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002227", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002227")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:setting.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002228")
    void case_UTAPI_002228() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002228",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002228", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002228", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002228", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002228", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002228", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002228", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002228", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002228", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002228", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002228", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002228")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:setting.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002229")
    void case_UTAPI_002229() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002229",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002229", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002229", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002229", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002229", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002229", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002229", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002229", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002229", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002229", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002229", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002229")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:setting.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002230")
    void case_UTAPI_002230() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002230",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002230", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002230", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002230", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002230", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002230", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002230", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002230", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002230", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002230", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002230", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002230")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:setting.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002231")
    void case_UTAPI_002231() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002231",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002231", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002231", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002231", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002231", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002231", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002231", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002231", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002231", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002231", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002231", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002231")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:setting.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002232")
    void case_UTAPI_002232() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002232",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002232", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002232", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002232", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002232", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002232", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002232", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002232", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002232", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002232", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002232", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002232")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:setting.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002233")
    void case_UTAPI_002233() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002233",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002233", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002233", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002233", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002233", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002233", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002233", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002233", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002233", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002233", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002233", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002233")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:setting.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002234")
    void case_UTAPI_002234() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002234",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002234", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002234", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002234", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002234", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002234", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002234", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002234", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002234", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002234", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002234", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002234")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:setting.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002235")
    void case_UTAPI_002235() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002235",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002235", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002235", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002235", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002235", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002235", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002235", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002235", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002235", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002235", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002235", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002235")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:setting.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002236")
    void case_UTAPI_002236() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002236",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002236", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002236", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002236", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002236", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002236", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002236", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002236", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002236", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002236", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002236", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002236")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:setting.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002237")
    void case_UTAPI_002237() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002237",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002237", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002237", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002237", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002237", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002237", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002237", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002237", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002237", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002237", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002237", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002237")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002238")
    void case_UTAPI_002238() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002238",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002238", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002238", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002238", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002238", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002238", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002238", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002238", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002238", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002238", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002238", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002238")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002239")
    void case_UTAPI_002239() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002239",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002239", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002239", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002239", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002239", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002239", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002239", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002239", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002239", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002239", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002239", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002239")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002240")
    void case_UTAPI_002240() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002240",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002240", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002240", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002240", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002240", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002240", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002240", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002240", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002240", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002240", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002240", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002240")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002241")
    void case_UTAPI_002241() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002241",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002241", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002241", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002241", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002241", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002241", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002241", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002241", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002241", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002241", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002241", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002241")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002242")
    void case_UTAPI_002242() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002242",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002242", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002242", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002242", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002242", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002242", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002242", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002242", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002242", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002242", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002242", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002242")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002243")
    void case_UTAPI_002243() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002243",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002243", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002243", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002243", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002243", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002243", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002243", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002243", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002243", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002243", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002243", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002243")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002244")
    void case_UTAPI_002244() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002244",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002244", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002244", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002244", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002244", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002244", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002244", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002244", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002244", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002244", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002244", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002244")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::update::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

}

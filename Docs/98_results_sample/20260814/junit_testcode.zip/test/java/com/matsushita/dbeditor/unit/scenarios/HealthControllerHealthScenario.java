package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.HealthControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for HealthController#health.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class HealthControllerHealthScenario {

    @Test
    @DisplayName("UTAPI-000548")
    void case_UTAPI_000548() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000548",
                "com.matsushita.dbeditor.adapter.controller.HealthController",
                "health",
                "ResponseEntity<Map<String,String>>",
                new ParamSpec[] {},
                new DataRef[] {},
                OraclePlan.builder("UTAPI-000548")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/HealthController.java::HealthController::health::1::METHOD::-1::-::-")
                    .mirror("-", "-", "-")
                    .target("-", "-")
                    .kind(OracleKind.HEALTH_RESPONSE)
                    .observation("the response returned by the health endpoint")
                    .expected("a success status with a non empty payload")
                    .failure("the endpoint fails, answers with an error status or returns no payload")
                    .assertion("assert the success status and assertNotNull on the body")
                    .check(CheckType.RETURN_NOT_NULL, "the health endpoint must answer")
                    .check(CheckType.RETURN_STATUS_2XX, "a healthy application must answer with a success status")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the answer must carry the health payload")
                    .check(CheckType.RETURN_BODY_NOT_EMPTY, "the health payload must actually report a state")
                    .check(CheckType.NO_EXCEPTION, "the health endpoint must not fail")
                    .build()),
            new HealthControllerWrapper());
    }

}

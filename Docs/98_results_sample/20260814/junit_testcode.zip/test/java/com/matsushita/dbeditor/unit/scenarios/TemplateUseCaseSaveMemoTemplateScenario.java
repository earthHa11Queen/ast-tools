package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TemplateUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TemplateUseCase#saveMemoTemplate.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TemplateUseCaseSaveMemoTemplateScenario {

    @Test
    @DisplayName("UTAPI-012769")
    void case_UTAPI_012769() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012769",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012769", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012769", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012769")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::1::-::title")
                    .mirror("-", "1:length_null", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012770")
    void case_UTAPI_012770() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012770",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012770", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012770", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012770")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::1::-::title")
                    .mirror("-", "2:length_empty", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012771")
    void case_UTAPI_012771() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012771",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012771", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012771", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012771")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::1::-::title")
                    .mirror("-", "3:length_min", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012772")
    void case_UTAPI_012772() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012772",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012772", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012772", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012772")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::1::-::title")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012773")
    void case_UTAPI_012773() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012773",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012773", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012773", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012773")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::1::-::title")
                    .mirror("-", "5:length_max", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012774")
    void case_UTAPI_012774() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012774",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012774", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012774", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012774")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::1::-::title")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012775")
    void case_UTAPI_012775() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012775",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012775", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012775", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012775")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::1::-::title")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012776")
    void case_UTAPI_012776() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012776",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012776", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012776", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012776")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::1::-::title")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012777")
    void case_UTAPI_012777() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012777",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012777", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012777", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012777")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::1::-::title")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012778")
    void case_UTAPI_012778() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012778",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012778", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012778", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012778")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::1::-::title")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012779")
    void case_UTAPI_012779() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012779",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012779", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012779", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012779")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::1::-::title")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012780")
    void case_UTAPI_012780() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012780",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012780", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012780", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012780")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::1::-::title")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012781")
    void case_UTAPI_012781() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012781",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012781", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012781", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012781")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::1::-::title")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012782")
    void case_UTAPI_012782() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012782",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012782", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012782", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012782")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::1::-::title")
                    .mirror("-", "-", "56:space")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012783")
    void case_UTAPI_012783() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012783",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012783", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012783", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012783")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::1::-::title")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012784")
    void case_UTAPI_012784() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012784",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012784", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012784", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012784")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::1::-::title")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012785")
    void case_UTAPI_012785() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012785",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012785", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012785", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012785")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::1::-::title")
                    .mirror("-", "-", "59:tab")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012786")
    void case_UTAPI_012786() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012786",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012786", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012786", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012786")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::1::-::title")
                    .mirror("-", "-", "60:control_character_null")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012787")
    void case_UTAPI_012787() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012787",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012787", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012787", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012787")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::1::-::title")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012788")
    void case_UTAPI_012788() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012788",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012788", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012788", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012788")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::1::-::title")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012789")
    void case_UTAPI_012789() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012789",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012789", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012789", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012789")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::1::-::title")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012790")
    void case_UTAPI_012790() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012790",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012790", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012790", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012790")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::2::-::content")
                    .mirror("-", "1:length_null", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012791")
    void case_UTAPI_012791() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012791",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012791", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012791", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012791")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::2::-::content")
                    .mirror("-", "2:length_empty", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012792")
    void case_UTAPI_012792() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012792",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012792", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012792", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012792")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::2::-::content")
                    .mirror("-", "3:length_min", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012793")
    void case_UTAPI_012793() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012793",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012793", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012793", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012793")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::2::-::content")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012794")
    void case_UTAPI_012794() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012794",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012794", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012794", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012794")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::2::-::content")
                    .mirror("-", "5:length_max", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012795")
    void case_UTAPI_012795() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012795",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012795", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012795", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012795")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::2::-::content")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012796")
    void case_UTAPI_012796() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012796",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012796", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012796", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012796")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::2::-::content")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012797")
    void case_UTAPI_012797() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012797",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012797", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012797", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012797")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::2::-::content")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012798")
    void case_UTAPI_012798() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012798",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012798", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012798", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012798")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::2::-::content")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012799")
    void case_UTAPI_012799() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012799",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012799", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012799", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012799")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::2::-::content")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012800")
    void case_UTAPI_012800() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012800",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012800", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012800", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012800")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::2::-::content")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012801")
    void case_UTAPI_012801() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012801",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012801", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012801", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012801")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::2::-::content")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012802")
    void case_UTAPI_012802() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012802",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012802", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012802", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012802")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::2::-::content")
                    .mirror("-", "-", "56:space")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012803")
    void case_UTAPI_012803() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012803",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012803", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012803", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012803")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::2::-::content")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012804")
    void case_UTAPI_012804() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012804",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012804", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012804", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012804")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::2::-::content")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012805")
    void case_UTAPI_012805() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012805",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012805", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012805", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012805")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::2::-::content")
                    .mirror("-", "-", "59:tab")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012806")
    void case_UTAPI_012806() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012806",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012806", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012806", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012806")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::2::-::content")
                    .mirror("-", "-", "60:control_character_null")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012807")
    void case_UTAPI_012807() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012807",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012807", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012807", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012807")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::2::-::content")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012808")
    void case_UTAPI_012808() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012808",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012808", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012808", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012808")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::2::-::content")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012809")
    void case_UTAPI_012809() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012809",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "saveMemoTemplate",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012809", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012809", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012809")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::saveMemoTemplate::2::ARG::2::-::content")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.save", "memoTemplateRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleMemo of the object handed to memoTemplateRepository.save must carry title", "memoTemplateRepository", "save", "0", "getTitleMemo", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to memoTemplateRepository.save must carry content", "memoTemplateRepository", "save", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

}

package com.matsushita.dbeditor.fixtures;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.matsushita.dbeditor.utils.HarnessException;
import com.matsushita.dbeditor.utils.ProjectTypes;
import com.matsushita.dbeditor.utils.TypeSupport;

/**
 * Deterministic collaborator results used while a single CaseNo executes.
 *
 * <p>These values are not test input values. They are the results the declared
 * collaborators return, so the Oracle can decide whether the SUT really produced its
 * result through the declared collaborator instead of fabricating one. Test input
 * values always come from TestDataRuntime.</p>
 */
public final class SentinelRegistry {

    public static final String SENTINEL_TEXT = "SENTINEL-COLLABORATOR-RESULT";
    public static final int SENTINEL_INT = 424242;

    private final Map<String, Object> byKey = new LinkedHashMap<String, Object>();
    private final Map<String, Object> createdMocks = new LinkedHashMap<String, Object>();
    private String genericHint;

    /** Declared row type of the SUT row mapper, used when a generic collaborator result is requested. */
    public void setGenericHint(String typeName) {
        this.genericHint = typeName;
    }

    public Map<String, Object> createdMocks() {
        return createdMocks;
    }

    /** Stable sentinel for one collaborator operation. */
    public Object forOperation(String key, String declaredReturnType, Class<?> rawReturnType, Object hint) {
        if (byKey.containsKey(key)) {
            return byKey.get(key);
        }
        Object value;
        if (declaredReturnType != null && !"-".equals(declaredReturnType)) {
            value = build(declaredReturnType, key);
        } else {
            value = buildFromRaw(rawReturnType, hint, key);
        }
        byKey.put(key, value);
        return value;
    }

    public Object peek(String key) {
        return byKey.get(key);
    }

    public boolean has(String key) {
        return byKey.containsKey(key);
    }

    public void put(String key, Object value) {
        byKey.put(key, value);
    }

    private Object buildFromRaw(Class<?> raw, Object hint, String key) {
        if (raw == null || raw == void.class || raw == Void.class) {
            return null;
        }
        if (raw == Object.class && hint instanceof Class) {
            return build(((Class<?>) hint).getSimpleName(), key);
        }
        if (raw == Object.class && genericHint != null) {
            return build(genericHint, key);
        }
        if (raw.isPrimitive() || Number.class.isAssignableFrom(raw) || raw == Boolean.class || raw == String.class) {
            return build(raw.getSimpleName(), key);
        }
        if (List.class.isAssignableFrom(raw) || Collection.class.isAssignableFrom(raw)) {
            return build("List<Map<String, Object>>", key);
        }
        if (Map.class.isAssignableFrom(raw)) {
            return build("Map<String, Object>", key);
        }
        if (Optional.class.isAssignableFrom(raw)) {
            return Optional.of(build("Map<String, Object>", key + "#opt"));
        }
        if (raw.isArray()) {
            return java.lang.reflect.Array.newInstance(raw.getComponentType(), 0);
        }
        return mockOf(raw, key);
    }

    /** Builds a deterministic value for a declared type expression such as List&lt;SavedSql&gt;. */
    public Object build(String declared, String key) {
        String t = declared == null ? "" : declared.trim();
        if (t.isEmpty() || "void".equals(t) || "-".equals(t)) {
            return null;
        }
        String rawName = TypeSupport.raw(t);
        String generic = genericOf(t);
        if ("List".equals(rawName) || "Collection".equals(rawName) || "Queue".equals(rawName)
                || "Deque".equals(rawName) || "Iterable".equals(rawName)) {
            List<Object> list = new ArrayList<Object>();
            list.add(build(generic == null ? "Map<String, Object>" : generic, key + "#e"));
            return list;
        }
        if ("Set".equals(rawName)) {
            LinkedHashSet<Object> set = new LinkedHashSet<Object>();
            set.add(build(generic == null ? "String" : generic, key + "#e"));
            return set;
        }
        if ("Map".equals(rawName)) {
            LinkedHashMap<Object, Object> map = new LinkedHashMap<Object, Object>();
            String k = "String";
            String v = "Object";
            if (generic != null) {
                int comma = topLevelComma(generic);
                if (comma > 0) {
                    k = generic.substring(0, comma).trim();
                    v = generic.substring(comma + 1).trim();
                }
            }
            map.put(build(k, key + "#k"), build(v, key + "#v"));
            return map;
        }
        if ("Optional".equals(rawName)) {
            return Optional.ofNullable(build(generic == null ? "Object" : generic, key + "#o"));
        }
        if (rawName.endsWith("[]")) {
            String base = rawName.substring(0, rawName.length() - 2);
            if ("byte".equals(base)) {
                return SENTINEL_TEXT.getBytes(java.nio.charset.StandardCharsets.UTF_8);
            }
            if ("String".equals(base)) {
                return new String[] { SENTINEL_TEXT };
            }
            Class<?> comp = ProjectTypes.loadOrNull(base);
            if (comp == null) {
                comp = Object.class;
            }
            Object arr = java.lang.reflect.Array.newInstance(comp, 1);
            java.lang.reflect.Array.set(arr, 0, build(base, key + "#a"));
            return arr;
        }
        if ("String".equals(rawName)) {
            return SENTINEL_TEXT;
        }
        if ("Integer".equals(rawName) || "int".equals(rawName)) {
            return Integer.valueOf(SENTINEL_INT);
        }
        if ("Long".equals(rawName) || "long".equals(rawName)) {
            return Long.valueOf(SENTINEL_INT);
        }
        if ("Double".equals(rawName) || "double".equals(rawName)) {
            return Double.valueOf(SENTINEL_INT);
        }
        if ("Float".equals(rawName) || "float".equals(rawName)) {
            return Float.valueOf(SENTINEL_INT);
        }
        if ("Short".equals(rawName) || "short".equals(rawName)) {
            return Short.valueOf((short) 42);
        }
        if ("Byte".equals(rawName) || "byte".equals(rawName)) {
            return Byte.valueOf((byte) 42);
        }
        if ("Boolean".equals(rawName) || "boolean".equals(rawName)) {
            return Boolean.TRUE;
        }
        if ("BigDecimal".equals(rawName)) {
            return new java.math.BigDecimal(SENTINEL_INT);
        }
        if ("LocalDateTime".equals(rawName)) {
            return LocalDateTime.of(2024, 1, 2, 3, 4, 5);
        }
        if ("LocalDate".equals(rawName)) {
            return LocalDate.of(2024, 1, 2);
        }
        if ("Object".equals(rawName)) {
            return SENTINEL_TEXT;
        }
        Class<?> type = ProjectTypes.loadOrNull(rawName);
        if (type == null) {
            return null;
        }
        Object bean = newBean(type);
        if (bean != null) {
            return bean;
        }
        return mockOf(type, key);
    }

    private Object mockOf(Class<?> type, String key) {
        if (type.isInterface() || !Modifier.isFinal(type.getModifiers())) {
            try {
                Object mock = org.mockito.Mockito.mock(type, org.mockito.Mockito.RETURNS_DEFAULTS);
                createdMocks.put("stub:" + type.getSimpleName() + ":" + key, mock);
                return mock;
            } catch (Throwable t) {
                return null;
            }
        }
        return null;
    }

    private Object newBean(Class<?> type) {
        if (type.isInterface() || Modifier.isAbstract(type.getModifiers())) {
            return null;
        }
        Object instance = null;
        try {
            java.lang.reflect.Constructor<?> ctor = type.getDeclaredConstructor();
            ctor.setAccessible(true);
            instance = ctor.newInstance();
        } catch (Throwable t) {
            instance = newByLongestConstructor(type);
        }
        if (instance == null) {
            return null;
        }
        fillFields(type, instance);
        return instance;
    }

    private Object newByLongestConstructor(Class<?> type) {
        java.lang.reflect.Constructor<?>[] ctors = type.getDeclaredConstructors();
        java.lang.reflect.Constructor<?> best = null;
        for (int i = 0; i < ctors.length; i++) {
            if (best == null || ctors[i].getParameterCount() > best.getParameterCount()) {
                best = ctors[i];
            }
        }
        if (best == null) {
            return null;
        }
        try {
            best.setAccessible(true);
            Class<?>[] types = best.getParameterTypes();
            Object[] args = new Object[types.length];
            for (int i = 0; i < types.length; i++) {
                args[i] = build(types[i].getSimpleName(), type.getSimpleName() + "#c" + i);
                if (args[i] == null && types[i].isPrimitive()) {
                    args[i] = defaultPrimitive(types[i]);
                }
            }
            return best.newInstance(args);
        } catch (Throwable t) {
            return null;
        }
    }

    private Object defaultPrimitive(Class<?> type) {
        if (type == boolean.class) {
            return Boolean.FALSE;
        }
        if (type == char.class) {
            return Character.valueOf(' ');
        }
        if (type == double.class) {
            return Double.valueOf(0);
        }
        if (type == float.class) {
            return Float.valueOf(0);
        }
        if (type == long.class) {
            return Long.valueOf(0);
        }
        return Integer.valueOf(0);
    }

    private void fillFields(Class<?> type, Object instance) {
        Field[] fields = type.getDeclaredFields();
        for (int i = 0; i < fields.length; i++) {
            Field f = fields[i];
            if (Modifier.isStatic(f.getModifiers()) || Modifier.isFinal(f.getModifiers())) {
                continue;
            }
            String setter = "set" + Character.toUpperCase(f.getName().charAt(0)) + f.getName().substring(1);
            Object value = build(genericFieldType(f), type.getSimpleName() + "#" + f.getName());
            if (value == null) {
                continue;
            }
            try {
                Method m = type.getMethod(setter, f.getType());
                m.setAccessible(true);
                m.invoke(instance, value);
            } catch (NoSuchMethodException e) {
                try {
                    f.setAccessible(true);
                    f.set(instance, value);
                } catch (Throwable ignored) {
                    // Field cannot be populated; the sentinel stays partially filled.
                }
            } catch (Throwable ignored) {
                // Setter rejected the sentinel; keep going.
            }
        }
    }

    private String genericFieldType(Field f) {
        String generic = f.getGenericType().getTypeName();
        int dot = generic.lastIndexOf('.');
        if (generic.indexOf('<') < 0 && dot >= 0) {
            return generic.substring(dot + 1);
        }
        return simplifyTypeName(generic);
    }

    private String simplifyTypeName(String name) {
        StringBuilder sb = new StringBuilder();
        StringBuilder token = new StringBuilder();
        for (int i = 0; i < name.length(); i++) {
            char c = name.charAt(i);
            if (Character.isJavaIdentifierPart(c) || c == '.') {
                token.append(c);
            } else {
                sb.append(lastSegment(token.toString()));
                token.setLength(0);
                sb.append(c);
            }
        }
        sb.append(lastSegment(token.toString()));
        return sb.toString();
    }

    private String lastSegment(String token) {
        int dot = token.lastIndexOf('.');
        if (dot >= 0) {
            return token.substring(dot + 1);
        }
        return token;
    }

    private static String genericOf(String declared) {
        int lt = declared.indexOf('<');
        int gt = declared.lastIndexOf('>');
        if (lt >= 0 && gt > lt) {
            return declared.substring(lt + 1, gt).trim();
        }
        return null;
    }

    private static int topLevelComma(String s) {
        int depth = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '<') {
                depth++;
            } else if (c == '>') {
                depth--;
            } else if (c == ',' && depth == 0) {
                return i;
            }
        }
        return -1;
    }

    public static void unused() {
        if (false) {
            throw new HarnessException("unused");
        }
    }
}

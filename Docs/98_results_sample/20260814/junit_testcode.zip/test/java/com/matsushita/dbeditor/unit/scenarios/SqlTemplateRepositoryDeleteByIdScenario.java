package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SqlTemplateRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SqlTemplateRepository#deleteById.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SqlTemplateRepositoryDeleteByIdScenario {

    @Test
    @DisplayName("UTAPI-007200")
    void case_UTAPI_007200() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007200",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007200", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007200")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::deleteById::4::ARG::1::-::n")
                    .mirror("-", "1:length_null", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007201")
    void case_UTAPI_007201() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007201",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007201", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007201")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::deleteById::4::ARG::1::-::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007202")
    void case_UTAPI_007202() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007202",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007202", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007202")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::deleteById::4::ARG::1::-::n")
                    .mirror("-", "3:length_min", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007203")
    void case_UTAPI_007203() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007203",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007203", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007203")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::deleteById::4::ARG::1::-::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007204")
    void case_UTAPI_007204() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007204",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007204", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007204")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::deleteById::4::ARG::1::-::n")
                    .mirror("-", "5:length_max", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007205")
    void case_UTAPI_007205() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007205",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007205", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007205")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::deleteById::4::ARG::1::-::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007206")
    void case_UTAPI_007206() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007206",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007206", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007206")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::deleteById::4::ARG::1::-::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007207")
    void case_UTAPI_007207() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007207",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007207", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007207")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::deleteById::4::ARG::1::-::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007208")
    void case_UTAPI_007208() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007208",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007208", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007208")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::deleteById::4::ARG::1::-::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007209")
    void case_UTAPI_007209() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007209",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007209", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007209")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::deleteById::4::ARG::1::-::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007210")
    void case_UTAPI_007210() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007210",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007210", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007210")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::deleteById::4::ARG::1::-::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableRecordRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableRecordRepository#findAllCopyRecords.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableRecordRepositoryFindAllCopyRecordsScenario {

    @Test
    @DisplayName("UTAPI-009394")
    void case_UTAPI_009394() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009394",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009394", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009394", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009394", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009394", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009394", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009394", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009394", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009394", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009394", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009394", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009394", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009394", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009394")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009395")
    void case_UTAPI_009395() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009395",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009395", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009395", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009395", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009395", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009395", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009395", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009395", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009395", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009395", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009395", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009395", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009395", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009395")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009396")
    void case_UTAPI_009396() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009396",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009396", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009396", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009396", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009396", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009396", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009396", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009396", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009396", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009396", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009396", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009396", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009396", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009396")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009397")
    void case_UTAPI_009397() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009397",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009397", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009397", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009397", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009397", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009397", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009397", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009397", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009397", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009397", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009397", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009397", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009397", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009397")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009398")
    void case_UTAPI_009398() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009398",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009398", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009398", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009398", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009398", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009398", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009398", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009398", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009398", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009398", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009398", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009398", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009398", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009398")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009399")
    void case_UTAPI_009399() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009399",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009399", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009399", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009399", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009399", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009399", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009399", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009399", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009399", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009399", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009399", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009399", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009399", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009399")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009400")
    void case_UTAPI_009400() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009400",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009400", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009400", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009400", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009400", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009400", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009400", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009400", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009400", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009400", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009400", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009400", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009400", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009400")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009401")
    void case_UTAPI_009401() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009401",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009401", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009401", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009401", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009401", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009401", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009401", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009401", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009401", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009401", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009401", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009401", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009401", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009401")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009402")
    void case_UTAPI_009402() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009402",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009402", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009402", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009402", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009402", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009402", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009402", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009402", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009402", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009402", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009402", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009402", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009402", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009402")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009403")
    void case_UTAPI_009403() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009403",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009403", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009403", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009403", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009403", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009403", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009403", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009403", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009403", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009403", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009403", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009403", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009403", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009403")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009404")
    void case_UTAPI_009404() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009404",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009404", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009404", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009404", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009404", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009404", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009404", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009404", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009404", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009404", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009404", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009404", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009404", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009404")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009405")
    void case_UTAPI_009405() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009405",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009405", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009405", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009405", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009405", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009405", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009405", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009405", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009405", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009405", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009405", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009405", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009405", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009405")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009406")
    void case_UTAPI_009406() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009406",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009406", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009406", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009406", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009406", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009406", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009406", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009406", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009406", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009406", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009406", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009406", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009406", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009406")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009407")
    void case_UTAPI_009407() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009407",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009407", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009407", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009407", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009407", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009407", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009407", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009407", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009407", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009407", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009407", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009407", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009407", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009407")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009408")
    void case_UTAPI_009408() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009408",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009408", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009408", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009408", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009408", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009408", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009408", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009408", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009408", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009408", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009408", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009408", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009408", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009408")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009409")
    void case_UTAPI_009409() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009409",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009409", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009409", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009409", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009409", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009409", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009409", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009409", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009409", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009409", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009409", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009409", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009409", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009409")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009410")
    void case_UTAPI_009410() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009410",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009410", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009410", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009410", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009410", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009410", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009410", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009410", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009410", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009410", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009410", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009410", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009410", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009410")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009411")
    void case_UTAPI_009411() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009411",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009411", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009411", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009411", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009411", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009411", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009411", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009411", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009411", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009411", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009411", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009411", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009411", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009411")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009412")
    void case_UTAPI_009412() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009412",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009412", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009412", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009412", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009412", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009412", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009412", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009412", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009412", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009412", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009412", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009412", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009412", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009412")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009413")
    void case_UTAPI_009413() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009413",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009413", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009413", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009413", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009413", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009413", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009413", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009413", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009413", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009413", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009413", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009413", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009413", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009413")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009414")
    void case_UTAPI_009414() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009414",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009414", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009414", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009414", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009414", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009414", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009414", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009414", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009414", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009414", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009414", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009414", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009414", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009414")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009415")
    void case_UTAPI_009415() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009415",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009415", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009415", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009415", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009415", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009415", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009415", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009415", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009415", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009415", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009415", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009415", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009415", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009415")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009416")
    void case_UTAPI_009416() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009416",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009416", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009416", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009416", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009416", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009416", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009416", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009416", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009416", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009416", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009416", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009416", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009416", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009416")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009417")
    void case_UTAPI_009417() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009417",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009417", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009417", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009417", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009417", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009417", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009417", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009417", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009417", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009417", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009417", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009417", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009417", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009417")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009418")
    void case_UTAPI_009418() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009418",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009418", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009418", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009418", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009418", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009418", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009418", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009418", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009418", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009418", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009418", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009418", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009418", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009418")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009419")
    void case_UTAPI_009419() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009419",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009419", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009419", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009419", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009419", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009419", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009419", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009419", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009419", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009419", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009419", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009419", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009419", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009419")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009420")
    void case_UTAPI_009420() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009420",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009420", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009420", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009420", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009420", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009420", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009420", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009420", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009420", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009420", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009420", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009420", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009420", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009420")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009421")
    void case_UTAPI_009421() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009421",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009421", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009421", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009421", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009421", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009421", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009421", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009421", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009421", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009421", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009421", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009421", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009421", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009421")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009422")
    void case_UTAPI_009422() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009422",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009422", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009422", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009422", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009422", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009422", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009422", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009422", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009422", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009422", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009422", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009422", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009422", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009422")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009423")
    void case_UTAPI_009423() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009423",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009423", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009423", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009423", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009423", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009423", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009423", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009423", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009423", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009423", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009423", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009423", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009423", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009423")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009424")
    void case_UTAPI_009424() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009424",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009424", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009424", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009424", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009424", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009424", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009424", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009424", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009424", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009424", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009424", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009424", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009424", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009424")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009425")
    void case_UTAPI_009425() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009425",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009425", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009425", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009425", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009425", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009425", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009425", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009425", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009425", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009425", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009425", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009425", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009425", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009425")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009426")
    void case_UTAPI_009426() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009426",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009426", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009426", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009426", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009426", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009426", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009426", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009426", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009426", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009426", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009426", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009426", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009426", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009426")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009427")
    void case_UTAPI_009427() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009427",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009427", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009427", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009427", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009427", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009427", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009427", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009427", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009427", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009427", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009427", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009427", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009427", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009427")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009428")
    void case_UTAPI_009428() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009428",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009428", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009428", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009428", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009428", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009428", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009428", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009428", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009428", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009428", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009428", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009428", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009428", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009428")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009429")
    void case_UTAPI_009429() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009429",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009429", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009429", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009429", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009429", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009429", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009429", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009429", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009429", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009429", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009429", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009429", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009429", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009429")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009430")
    void case_UTAPI_009430() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009430",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009430", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009430", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009430", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009430", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009430", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009430", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009430", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009430", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009430", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009430", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009430", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009430", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009430")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009431")
    void case_UTAPI_009431() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009431",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009431", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009431", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009431", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009431", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009431", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009431", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009431", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009431", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009431", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009431", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009431", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009431", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009431")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009432")
    void case_UTAPI_009432() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009432",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009432", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009432", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009432", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009432", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009432", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009432", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009432", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009432", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009432", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009432", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009432", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009432", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009432")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009433")
    void case_UTAPI_009433() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009433",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009433", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009433", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009433", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009433", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009433", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009433", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009433", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009433", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009433", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009433", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009433", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009433", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009433")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009434")
    void case_UTAPI_009434() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009434",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009434", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009434", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009434", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009434", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009434", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009434", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009434", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009434", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009434", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009434", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009434", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009434", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009434")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009435")
    void case_UTAPI_009435() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009435",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009435", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009435", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009435", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009435", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009435", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009435", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009435", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009435", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009435", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009435", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009435", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009435", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009435")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009436")
    void case_UTAPI_009436() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009436",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009436", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009436", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009436", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009436", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009436", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009436", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009436", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009436", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009436", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009436", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009436", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009436", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009436")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009437")
    void case_UTAPI_009437() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009437",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009437", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009437", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009437", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009437", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009437", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009437", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009437", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009437", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009437", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009437", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009437", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009437", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009437")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009438")
    void case_UTAPI_009438() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009438",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009438", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009438", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009438", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009438", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009438", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009438", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009438", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009438", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009438", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009438", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009438", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009438", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009438")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009439")
    void case_UTAPI_009439() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009439",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009439", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009439", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009439", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009439", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009439", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009439", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009439", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009439", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009439", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009439", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009439", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009439", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009439")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009440")
    void case_UTAPI_009440() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009440",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009440", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009440", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009440", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009440", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009440", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009440", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009440", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009440", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009440", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009440", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009440", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009440", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009440")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009441")
    void case_UTAPI_009441() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009441",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009441", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009441", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009441", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009441", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009441", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009441", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009441", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009441", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009441", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009441", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009441", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009441", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009441")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009442")
    void case_UTAPI_009442() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009442",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009442", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009442", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009442", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009442", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009442", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009442", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009442", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009442", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009442", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009442", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009442", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009442", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009442")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009443")
    void case_UTAPI_009443() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009443",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009443", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009443", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009443", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009443", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009443", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009443", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009443", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009443", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009443", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009443", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009443", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009443", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009443")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009444")
    void case_UTAPI_009444() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009444",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009444", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009444", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009444", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009444", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009444", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009444", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009444", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009444", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009444", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009444", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009444", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009444", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009444")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009445")
    void case_UTAPI_009445() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009445",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009445", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009445", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009445", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009445", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009445", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009445", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009445", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009445", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009445", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009445", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009445", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009445", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009445")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009446")
    void case_UTAPI_009446() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009446",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009446", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009446", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009446", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009446", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009446", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009446", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009446", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009446", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009446", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009446", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009446", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009446", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009446")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009447")
    void case_UTAPI_009447() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009447",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009447", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009447", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009447", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009447", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009447", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009447", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009447", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009447", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009447", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009447", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009447", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009447", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009447")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009448")
    void case_UTAPI_009448() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009448",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009448", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009448", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009448", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009448", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009448", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009448", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009448", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009448", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009448", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009448", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009448", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009448", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009448")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009449")
    void case_UTAPI_009449() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009449",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009449", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009449", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009449", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009449", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009449", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009449", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009449", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009449", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009449", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009449", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009449", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009449", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009449")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009450")
    void case_UTAPI_009450() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009450",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009450", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009450", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009450", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009450", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009450", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009450", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009450", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009450", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009450", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009450", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009450", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009450", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009450")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009451")
    void case_UTAPI_009451() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009451",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009451", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009451", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009451", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009451", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009451", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009451", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009451", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009451", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009451", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009451", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009451", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009451", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009451")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009452")
    void case_UTAPI_009452() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009452",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009452", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009452", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009452", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009452", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009452", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009452", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009452", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009452", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009452", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009452", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009452", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009452", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009452")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009453")
    void case_UTAPI_009453() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009453",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009453", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009453", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009453", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009453", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009453", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009453", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009453", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009453", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009453", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009453", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009453", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009453", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009453")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009454")
    void case_UTAPI_009454() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009454",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009454", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009454", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009454", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009454", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009454", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009454", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009454", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009454", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009454", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009454", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009454", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009454", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009454")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009455")
    void case_UTAPI_009455() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009455",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009455", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009455", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009455", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009455", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009455", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009455", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009455", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009455", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009455", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009455", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009455", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009455", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009455")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009456")
    void case_UTAPI_009456() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009456",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009456", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009456", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009456", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009456", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009456", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009456", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009456", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009456", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009456", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009456", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009456", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009456", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009456")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009457")
    void case_UTAPI_009457() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009457",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009457", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009457", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009457", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009457", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009457", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009457", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009457", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009457", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009457", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009457", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009457", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009457", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009457")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009458")
    void case_UTAPI_009458() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009458",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009458", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009458", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009458", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009458", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009458", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009458", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009458", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009458", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009458", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009458", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009458", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009458", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009458")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009459")
    void case_UTAPI_009459() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009459",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009459", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009459", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009459", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009459", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009459", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009459", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009459", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009459", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009459", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009459", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009459", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009459", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009459")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009460")
    void case_UTAPI_009460() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009460",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009460", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009460", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009460", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009460", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009460", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009460", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009460", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009460", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009460", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009460", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009460", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009460", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009460")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009461")
    void case_UTAPI_009461() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009461",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009461", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009461", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009461", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009461", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009461", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009461", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009461", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009461", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009461", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009461", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009461", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009461", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009461")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009462")
    void case_UTAPI_009462() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009462",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009462", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009462", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009462", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009462", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009462", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009462", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009462", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009462", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009462", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009462", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009462", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009462", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009462")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009463")
    void case_UTAPI_009463() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009463",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009463", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009463", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009463", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009463", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009463", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009463", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009463", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009463", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009463", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009463", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009463", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009463", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009463")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009464")
    void case_UTAPI_009464() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009464",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009464", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009464", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009464", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009464", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009464", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009464", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009464", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009464", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009464", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009464", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009464", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009464", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009464")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009465")
    void case_UTAPI_009465() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009465",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009465", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009465", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009465", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009465", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009465", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009465", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009465", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009465", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009465", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009465", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009465", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009465", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009465")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009466")
    void case_UTAPI_009466() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009466",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009466", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009466", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009466", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009466", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009466", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009466", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009466", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009466", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009466", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009466", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009466", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009466", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009466")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009467")
    void case_UTAPI_009467() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009467",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009467", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009467", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009467", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009467", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009467", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009467", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009467", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009467", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009467", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009467", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009467", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009467", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009467")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009468")
    void case_UTAPI_009468() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009468",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009468", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009468", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009468", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009468", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009468", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009468", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009468", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009468", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009468", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009468", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009468", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009468", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009468")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009469")
    void case_UTAPI_009469() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009469",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009469", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009469", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009469", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009469", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009469", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009469", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009469", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009469", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009469", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009469", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009469", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009469", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009469")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009470")
    void case_UTAPI_009470() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009470",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009470", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009470", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009470", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009470", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009470", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009470", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009470", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009470", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009470", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009470", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009470", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009470", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009470")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009471")
    void case_UTAPI_009471() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009471",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009471", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009471", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009471", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009471", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009471", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009471", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009471", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009471", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009471", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009471", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009471", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009471", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009471")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009472")
    void case_UTAPI_009472() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009472",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009472", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009472", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009472", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009472", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009472", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009472", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009472", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009472", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009472", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009472", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009472", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009472", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009472")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009473")
    void case_UTAPI_009473() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009473",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009473", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009473", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009473", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009473", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009473", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009473", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009473", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009473", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009473", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009473", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009473", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009473", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009473")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009474")
    void case_UTAPI_009474() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009474",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009474", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009474", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009474", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009474", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009474", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009474", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009474", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009474", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009474", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009474", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009474", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009474", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009474")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009475")
    void case_UTAPI_009475() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009475",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009475", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009475", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009475", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009475", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009475", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009475", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009475", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009475", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009475", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009475", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009475", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009475", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009475")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009476")
    void case_UTAPI_009476() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009476",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009476", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009476", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009476", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009476", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009476", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009476", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009476", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009476", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009476", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009476", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009476", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009476", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009476")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009477")
    void case_UTAPI_009477() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009477",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009477", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009477", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009477", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009477", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009477", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009477", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009477", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009477", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009477", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009477", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009477", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009477", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009477")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009478")
    void case_UTAPI_009478() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009478",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009478", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009478", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009478", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009478", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009478", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009478", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009478", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009478", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009478", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009478", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009478", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009478", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009478")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009479")
    void case_UTAPI_009479() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009479",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009479", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009479", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009479", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009479", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009479", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009479", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009479", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009479", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009479", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009479", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009479", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009479", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009479")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009480")
    void case_UTAPI_009480() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009480",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009480", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009480", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009480", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009480", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009480", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009480", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009480", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009480", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009480", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009480", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009480", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009480", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009480")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009481")
    void case_UTAPI_009481() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009481",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009481", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009481", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009481", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009481", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009481", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009481", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009481", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009481", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009481", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009481", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009481", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009481", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009481")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009482")
    void case_UTAPI_009482() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009482",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009482", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009482", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009482", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009482", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009482", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009482", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009482", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009482", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009482", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009482", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009482", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009482", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009482")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009483")
    void case_UTAPI_009483() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009483",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009483", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009483", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009483", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009483", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009483", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009483", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009483", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009483", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009483", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009483", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009483", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009483", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009483")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009484")
    void case_UTAPI_009484() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009484",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009484", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009484", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009484", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009484", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009484", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009484", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009484", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009484", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009484", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009484", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009484", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009484", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009484")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009485")
    void case_UTAPI_009485() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009485",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009485", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009485", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009485", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009485", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009485", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009485", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009485", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009485", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009485", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009485", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009485", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009485", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009485")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009486")
    void case_UTAPI_009486() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009486",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009486", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009486", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009486", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009486", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009486", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009486", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009486", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009486", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009486", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009486", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009486", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009486", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009486")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009487")
    void case_UTAPI_009487() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009487",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009487", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009487", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009487", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009487", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009487", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009487", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009487", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009487", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009487", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009487", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009487", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009487", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009487")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009488")
    void case_UTAPI_009488() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009488",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009488", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009488", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009488", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009488", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009488", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009488", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009488", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009488", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009488", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009488", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009488", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009488", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009488")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009489")
    void case_UTAPI_009489() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009489",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009489", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009489", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009489", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009489", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009489", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009489", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009489", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009489", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009489", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009489", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009489", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009489", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009489")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009490")
    void case_UTAPI_009490() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009490",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009490", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009490", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009490", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009490", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009490", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009490", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009490", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009490", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009490", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009490", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009490", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009490", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009490")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009491")
    void case_UTAPI_009491() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009491",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009491", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009491", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009491", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009491", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009491", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009491", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009491", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009491", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009491", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009491", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009491", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009491", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009491")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009492")
    void case_UTAPI_009492() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009492",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009492", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009492", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009492", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009492", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009492", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009492", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009492", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009492", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009492", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009492", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009492", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009492", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009492")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009493")
    void case_UTAPI_009493() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009493",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009493", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009493", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009493", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009493", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009493", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009493", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009493", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009493", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009493", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009493", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009493", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009493", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009493")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009494")
    void case_UTAPI_009494() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009494",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009494", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009494", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009494", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009494", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009494", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009494", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009494", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009494", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009494", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009494", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009494", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009494", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009494")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009495")
    void case_UTAPI_009495() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009495",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009495", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009495", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009495", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009495", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009495", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009495", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009495", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009495", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009495", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009495", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009495", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009495", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009495")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009496")
    void case_UTAPI_009496() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009496",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009496", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009496", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009496", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009496", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009496", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009496", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009496", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009496", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009496", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009496", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009496", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009496", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009496")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009497")
    void case_UTAPI_009497() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009497",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009497", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009497", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009497", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009497", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009497", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009497", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009497", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009497", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009497", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009497", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009497", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009497", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009497")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009498")
    void case_UTAPI_009498() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009498",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009498", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009498", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009498", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009498", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009498", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009498", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009498", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009498", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009498", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009498", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009498", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009498", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009498")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009499")
    void case_UTAPI_009499() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009499",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009499", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009499", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009499", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009499", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009499", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009499", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009499", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009499", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009499", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009499", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009499", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009499", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009499")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009500")
    void case_UTAPI_009500() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009500",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009500", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009500", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009500", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009500", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009500", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009500", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009500", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009500", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009500", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009500", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009500", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009500", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009500")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009501")
    void case_UTAPI_009501() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009501",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009501", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009501", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009501", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009501", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009501", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009501", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009501", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009501", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009501", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009501", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009501", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009501", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009501")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009502")
    void case_UTAPI_009502() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009502",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009502", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009502", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009502", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009502", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009502", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009502", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009502", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009502", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009502", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009502", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009502", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009502", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009502")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009503")
    void case_UTAPI_009503() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009503",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009503", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009503", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009503", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009503", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009503", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009503", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009503", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009503", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009503", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009503", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009503", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009503", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009503")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009504")
    void case_UTAPI_009504() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009504",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009504", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009504", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009504", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009504", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009504", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009504", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009504", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009504", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009504", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009504", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009504", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009504", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009504")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009505")
    void case_UTAPI_009505() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009505",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009505", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009505", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009505", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009505", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009505", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009505", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009505", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009505", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009505", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009505", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009505", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009505", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009505")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009506")
    void case_UTAPI_009506() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009506",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009506", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009506", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009506", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009506", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009506", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009506", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009506", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009506", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009506", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009506", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009506", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009506", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009506")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009507")
    void case_UTAPI_009507() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009507",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009507", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009507", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009507", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009507", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009507", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009507", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009507", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009507", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009507", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009507", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009507", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009507", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009507")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009508")
    void case_UTAPI_009508() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009508",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009508", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009508", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009508", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009508", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009508", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009508", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009508", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009508", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009508", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009508", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009508", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009508", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009508")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009509")
    void case_UTAPI_009509() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009509",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009509", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009509", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009509", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009509", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009509", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009509", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009509", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009509", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009509", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009509", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009509", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009509", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009509")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009510")
    void case_UTAPI_009510() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009510",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009510", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009510", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009510", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009510", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009510", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009510", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009510", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009510", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009510", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009510", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009510", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009510", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009510")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009511")
    void case_UTAPI_009511() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009511",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009511", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009511", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009511", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009511", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009511", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009511", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009511", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009511", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009511", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009511", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009511", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009511", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009511")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009512")
    void case_UTAPI_009512() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009512",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009512", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009512", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009512", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009512", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009512", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009512", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009512", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009512", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009512", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009512", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009512", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009512", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009512")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009513")
    void case_UTAPI_009513() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009513",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009513", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009513", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009513", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009513", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009513", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009513", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009513", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009513", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009513", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009513", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009513", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009513", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009513")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009514")
    void case_UTAPI_009514() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009514",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009514", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009514", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009514", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009514", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009514", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009514", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009514", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009514", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009514", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009514", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009514", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009514", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009514")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009515")
    void case_UTAPI_009515() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009515",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009515", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009515", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009515", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009515", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009515", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009515", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009515", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009515", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009515", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009515", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009515", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009515", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009515")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009516")
    void case_UTAPI_009516() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009516",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009516", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009516", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009516", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009516", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009516", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009516", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009516", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009516", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009516", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009516", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009516", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009516", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009516")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009517")
    void case_UTAPI_009517() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009517",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009517", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009517", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009517", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009517", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009517", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009517", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009517", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009517", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009517", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009517", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009517", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009517", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009517")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009518")
    void case_UTAPI_009518() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009518",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009518", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009518", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009518", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009518", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009518", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009518", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009518", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009518", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009518", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009518", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009518", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009518", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009518")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009519")
    void case_UTAPI_009519() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009519",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009519", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009519", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009519", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009519", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009519", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009519", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009519", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009519", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009519", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009519", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009519", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009519", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009519")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009520")
    void case_UTAPI_009520() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009520",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009520", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009520", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009520", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009520", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009520", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009520", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009520", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009520", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009520", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009520", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009520", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009520", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009520")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009521")
    void case_UTAPI_009521() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009521",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009521", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009521", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009521", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009521", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009521", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009521", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009521", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009521", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009521", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009521", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009521", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009521", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009521")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009522")
    void case_UTAPI_009522() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009522",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009522", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009522", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009522", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009522", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009522", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009522", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009522", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009522", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009522", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009522", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009522", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009522", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009522")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009523")
    void case_UTAPI_009523() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009523",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009523", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009523", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009523", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009523", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009523", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009523", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009523", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009523", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009523", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009523", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009523", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009523", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009523")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009524")
    void case_UTAPI_009524() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009524",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009524", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009524", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009524", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009524", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009524", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009524", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009524", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009524", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009524", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009524", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009524", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009524", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009524")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009525")
    void case_UTAPI_009525() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009525",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009525", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009525", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009525", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009525", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009525", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009525", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009525", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009525", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009525", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009525", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009525", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009525", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009525")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009526")
    void case_UTAPI_009526() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009526",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009526", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009526", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009526", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009526", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009526", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009526", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009526", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009526", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009526", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009526", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009526", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009526", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009526")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009527")
    void case_UTAPI_009527() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009527",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009527", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009527", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009527", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009527", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009527", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009527", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009527", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009527", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009527", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009527", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009527", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009527", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009527")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009528")
    void case_UTAPI_009528() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009528",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009528", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009528", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009528", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009528", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009528", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009528", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009528", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009528", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009528", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009528", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009528", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009528", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009528")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009529")
    void case_UTAPI_009529() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009529",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009529", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009529", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009529", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009529", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009529", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009529", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009529", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009529", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009529", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009529", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009529", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009529", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009529")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009530")
    void case_UTAPI_009530() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009530",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009530", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009530", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009530", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009530", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009530", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009530", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009530", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009530", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009530", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009530", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009530", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009530", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009530")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009531")
    void case_UTAPI_009531() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009531",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009531", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009531", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009531", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009531", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009531", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009531", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009531", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009531", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009531", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009531", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009531", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009531", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009531")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009532")
    void case_UTAPI_009532() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009532",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009532", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009532", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009532", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009532", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009532", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009532", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009532", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009532", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009532", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009532", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009532", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009532", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009532")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009533")
    void case_UTAPI_009533() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009533",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009533", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009533", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009533", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009533", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009533", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009533", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009533", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009533", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009533", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009533", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009533", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009533", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009533")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009534")
    void case_UTAPI_009534() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009534",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009534", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009534", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009534", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009534", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009534", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009534", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009534", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009534", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009534", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009534", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009534", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009534", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009534")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009535")
    void case_UTAPI_009535() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009535",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009535", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009535", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009535", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009535", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009535", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009535", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009535", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009535", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009535", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009535", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009535", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009535", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009535")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009536")
    void case_UTAPI_009536() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009536",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009536", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009536", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009536", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009536", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009536", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009536", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009536", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009536", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009536", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009536", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009536", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009536", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009536")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009537")
    void case_UTAPI_009537() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009537",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009537", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009537", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009537", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009537", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009537", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009537", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009537", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009537", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009537", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009537", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009537", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009537", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009537")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009538")
    void case_UTAPI_009538() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009538",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009538", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009538", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009538", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009538", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009538", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009538", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009538", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009538", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009538", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009538", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009538", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009538", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009538")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009539")
    void case_UTAPI_009539() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009539",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009539", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009539", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009539", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009539", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009539", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009539", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009539", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009539", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009539", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009539", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009539", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009539", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009539")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009540")
    void case_UTAPI_009540() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009540",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009540", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009540", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009540", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009540", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009540", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009540", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009540", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009540", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009540", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009540", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009540", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009540", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009540")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009541")
    void case_UTAPI_009541() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009541",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009541", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009541", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009541", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009541", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009541", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009541", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009541", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009541", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009541", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009541", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009541", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009541", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009541")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009542")
    void case_UTAPI_009542() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009542",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009542", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009542", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009542", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009542", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009542", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009542", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009542", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009542", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009542", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009542", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009542", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009542", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009542")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009543")
    void case_UTAPI_009543() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009543",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009543", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009543", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009543", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009543", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009543", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009543", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009543", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009543", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009543", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009543", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009543", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009543", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009543")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009544")
    void case_UTAPI_009544() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009544",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009544", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009544", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009544", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009544", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009544", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009544", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009544", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009544", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009544", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009544", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009544", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009544", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009544")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009545")
    void case_UTAPI_009545() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009545",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009545", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009545", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009545", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009545", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009545", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009545", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009545", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009545", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009545", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009545", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009545", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009545", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009545")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009546")
    void case_UTAPI_009546() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009546",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009546", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009546", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009546", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009546", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009546", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009546", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009546", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009546", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009546", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009546", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009546", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009546", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009546")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009547")
    void case_UTAPI_009547() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009547",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009547", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009547", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009547", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009547", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009547", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009547", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009547", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009547", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009547", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009547", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009547", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009547", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009547")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009548")
    void case_UTAPI_009548() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009548",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009548", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009548", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009548", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009548", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009548", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009548", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009548", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009548", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009548", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009548", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009548", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009548", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009548")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009549")
    void case_UTAPI_009549() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009549",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009549", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009549", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009549", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009549", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009549", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009549", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009549", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009549", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009549", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009549", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009549", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009549", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009549")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009550")
    void case_UTAPI_009550() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009550",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009550", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009550", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009550", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009550", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009550", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009550", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009550", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009550", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009550", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009550", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009550", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009550", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009550")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009551")
    void case_UTAPI_009551() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009551",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009551", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009551", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009551", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009551", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009551", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009551", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009551", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009551", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009551", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009551", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009551", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009551", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009551")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009552")
    void case_UTAPI_009552() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009552",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009552", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009552", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009552", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009552", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009552", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009552", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009552", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009552", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009552", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009552", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009552", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009552", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009552")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009553")
    void case_UTAPI_009553() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009553",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009553", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009553", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009553", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009553", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009553", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009553", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009553", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009553", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009553", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009553", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009553", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009553", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009553")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009554")
    void case_UTAPI_009554() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009554",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009554", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009554", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009554", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009554", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009554", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009554", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009554", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009554", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009554", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009554", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009554", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009554", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009554")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009555")
    void case_UTAPI_009555() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009555",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009555", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009555", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009555", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009555", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009555", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009555", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009555", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009555", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009555", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009555", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009555", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009555", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009555")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009556")
    void case_UTAPI_009556() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009556",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009556", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009556", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009556", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009556", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009556", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009556", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009556", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009556", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009556", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009556", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009556", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009556", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009556")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009557")
    void case_UTAPI_009557() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009557",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009557", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009557", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009557", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009557", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009557", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009557", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009557", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009557", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009557", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009557", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009557", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009557", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009557")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009558")
    void case_UTAPI_009558() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009558",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009558", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009558", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009558", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009558", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009558", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009558", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009558", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009558", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009558", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009558", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009558", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009558", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009558")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009559")
    void case_UTAPI_009559() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009559",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009559", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009559", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009559", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009559", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009559", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009559", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009559", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009559", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009559", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009559", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009559", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009559", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009559")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009560")
    void case_UTAPI_009560() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009560",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009560", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009560", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009560", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009560", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009560", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009560", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009560", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009560", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009560", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009560", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009560", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009560", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009560")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009561")
    void case_UTAPI_009561() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009561",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009561", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009561", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009561", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009561", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009561", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009561", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009561", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009561", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009561", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009561", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009561", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009561", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009561")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009562")
    void case_UTAPI_009562() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009562",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009562", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009562", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009562", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009562", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009562", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009562", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009562", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009562", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009562", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009562", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009562", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009562", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009562")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009563")
    void case_UTAPI_009563() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009563",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009563", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009563", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009563", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009563", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009563", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009563", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009563", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009563", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009563", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009563", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009563", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009563", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009563")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009564")
    void case_UTAPI_009564() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009564",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009564", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009564", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009564", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009564", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009564", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009564", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009564", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009564", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009564", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009564", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009564", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009564", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009564")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009565")
    void case_UTAPI_009565() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009565",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009565", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009565", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009565", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009565", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009565", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009565", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009565", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009565", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009565", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009565", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009565", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009565", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009565")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009566")
    void case_UTAPI_009566() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009566",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009566", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009566", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009566", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009566", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009566", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009566", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009566", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009566", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009566", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009566", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009566", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009566", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009566")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009567")
    void case_UTAPI_009567() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009567",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009567", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009567", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009567", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009567", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009567", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009567", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009567", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009567", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009567", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009567", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009567", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009567", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009567")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009568")
    void case_UTAPI_009568() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009568",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009568", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009568", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009568", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009568", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009568", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009568", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009568", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009568", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009568", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009568", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009568", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009568", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009568")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009569")
    void case_UTAPI_009569() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009569",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009569", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009569", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009569", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009569", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009569", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009569", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009569", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009569", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009569", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009569", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009569", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009569", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009569")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009570")
    void case_UTAPI_009570() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009570",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009570", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009570", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009570", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009570", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009570", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009570", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009570", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009570", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009570", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009570", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009570", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009570", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009570")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009571")
    void case_UTAPI_009571() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009571",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009571", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009571", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009571", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009571", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009571", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009571", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009571", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009571", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009571", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009571", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009571", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009571", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009571")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009572")
    void case_UTAPI_009572() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009572",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009572", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009572", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009572", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009572", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009572", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009572", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009572", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009572", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009572", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009572", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009572", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009572", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009572")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009573")
    void case_UTAPI_009573() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009573",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009573", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009573", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009573", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009573", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009573", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009573", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009573", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009573", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009573", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009573", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009573", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009573", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009573")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009574")
    void case_UTAPI_009574() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009574",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009574", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009574", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009574", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009574", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009574", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009574", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009574", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009574", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009574", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009574", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009574", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009574", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009574")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009575")
    void case_UTAPI_009575() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009575",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009575", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009575", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009575", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009575", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009575", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009575", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009575", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009575", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009575", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009575", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009575", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009575", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009575")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009576")
    void case_UTAPI_009576() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009576",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "findAllCopyRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009576", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009576", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009576", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009576", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009576", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009576", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009576", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009576", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009576", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009576", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009576", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009576", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009576")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::findAllCopyRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

}

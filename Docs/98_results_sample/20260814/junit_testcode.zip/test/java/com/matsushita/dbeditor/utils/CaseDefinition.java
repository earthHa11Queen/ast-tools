package com.matsushita.dbeditor.utils;

import java.util.Collections;
import java.util.List;

/**
 * Everything the executor needs for one validated CaseNo.
 */
public final class CaseDefinition {

    private final String caseNo;
    private final String sutClassName;
    private final String methodName;
    private final String returnType;
    private final List<ParamSpec> params;
    private final List<DataRef> dataRefs;
    private final OraclePlan plan;

    public CaseDefinition(String caseNo, String sutClassName, String methodName, String returnType,
            ParamSpec[] params, DataRef[] dataRefs, OraclePlan plan) {
        this.caseNo = caseNo;
        this.sutClassName = sutClassName;
        this.methodName = methodName;
        this.returnType = returnType;
        this.params = Collections.unmodifiableList(java.util.Arrays.asList(params));
        this.dataRefs = Collections.unmodifiableList(java.util.Arrays.asList(dataRefs));
        this.plan = plan;
    }

    public String caseNo() {
        return caseNo;
    }

    public String sutClassName() {
        return sutClassName;
    }

    public String methodName() {
        return methodName;
    }

    public String returnType() {
        return returnType;
    }

    public List<ParamSpec> params() {
        return params;
    }

    public List<DataRef> dataRefs() {
        return dataRefs;
    }

    public OraclePlan plan() {
        return plan;
    }

    public String[] declaredTypes() {
        String[] types = new String[params.size()];
        for (int i = 0; i < types.length; i++) {
            types[i] = params.get(i).declaredType();
        }
        return types;
    }
}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.MemoControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for MemoController#downloadMemo.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class MemoControllerDownloadMemoScenario {

    @Test
    @DisplayName("UTAPI-000804")
    void case_UTAPI_000804() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000804",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000804", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000804", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000804")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000805")
    void case_UTAPI_000805() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000805",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000805", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000805", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000805")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000806")
    void case_UTAPI_000806() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000806",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000806", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000806", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000806")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000807")
    void case_UTAPI_000807() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000807",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000807", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000807", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000807")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000808")
    void case_UTAPI_000808() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000808",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000808", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000808", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000808")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000809")
    void case_UTAPI_000809() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000809",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000809", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000809", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000809")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000810")
    void case_UTAPI_000810() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000810",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000810", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000810", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000810")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000811")
    void case_UTAPI_000811() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000811",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000811", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000811", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000811")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000812")
    void case_UTAPI_000812() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000812",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000812", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000812", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000812")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000813")
    void case_UTAPI_000813() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000813",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000813", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000813", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000813")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000814")
    void case_UTAPI_000814() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000814",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000814", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000814", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000814")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000815")
    void case_UTAPI_000815() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000815",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000815", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000815", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000815")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000816")
    void case_UTAPI_000816() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000816",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000816", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000816", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000816")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000817")
    void case_UTAPI_000817() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000817",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000817", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000817", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000817")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000818")
    void case_UTAPI_000818() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000818",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000818", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000818", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000818")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000819")
    void case_UTAPI_000819() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000819",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000819", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000819", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000819")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000820")
    void case_UTAPI_000820() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000820",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000820", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000820", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000820")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000821")
    void case_UTAPI_000821() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000821",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000821", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000821", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000821")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000822")
    void case_UTAPI_000822() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000822",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000822", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000822", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000822")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::2::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000823")
    void case_UTAPI_000823() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000823",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000823", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000823", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000823")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::2::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000824")
    void case_UTAPI_000824() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000824",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000824", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000824", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000824")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::2::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000825")
    void case_UTAPI_000825() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000825",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000825", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000825", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000825")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::2::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000826")
    void case_UTAPI_000826() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000826",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000826", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000826", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000826")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000827")
    void case_UTAPI_000827() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000827",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000827", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000827", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000827")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000828")
    void case_UTAPI_000828() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000828",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000828", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000828", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000828")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000829")
    void case_UTAPI_000829() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000829",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000829", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000829", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000829")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000830")
    void case_UTAPI_000830() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000830",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000830", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000830", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000830")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000831")
    void case_UTAPI_000831() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000831",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000831", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000831", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000831")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000832")
    void case_UTAPI_000832() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000832",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000832", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000832", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000832")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000833")
    void case_UTAPI_000833() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000833",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000833", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000833", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000833")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000834")
    void case_UTAPI_000834() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000834",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000834", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000834", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000834")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000835")
    void case_UTAPI_000835() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000835",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "downloadMemo",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000835", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000835", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000835")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::downloadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.downloadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.downloadMemo", "memoUseCase", "downloadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.downloadMemo must carry the value generated for connectionId", "memoUseCase", "downloadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.downloadMemo must carry the value generated for tableName", "memoUseCase", "downloadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

}

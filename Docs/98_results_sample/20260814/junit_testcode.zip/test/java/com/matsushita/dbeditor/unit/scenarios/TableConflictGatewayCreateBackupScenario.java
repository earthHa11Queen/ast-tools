package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableConflictGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableConflictGateway#createBackup.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableConflictGatewayCreateBackupScenario {

    @Test
    @DisplayName("UTAPI-003493")
    void case_UTAPI_003493() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003493",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003493", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003493", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003493", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003493", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003493", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003493", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003493", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003493", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003493", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003493", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003493", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003493", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003493")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003494")
    void case_UTAPI_003494() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003494",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003494", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003494", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003494", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003494", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003494", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003494", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003494", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003494", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003494", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003494", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003494", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003494", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003494")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003495")
    void case_UTAPI_003495() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003495",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003495", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003495", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003495", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003495", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003495", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003495", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003495", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003495", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003495", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003495", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003495", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003495", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003495")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003496")
    void case_UTAPI_003496() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003496",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003496", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003496", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003496", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003496", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003496", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003496", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003496", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003496", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003496", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003496", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003496", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003496", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003496")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003497")
    void case_UTAPI_003497() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003497",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003497", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003497", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003497", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003497", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003497", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003497", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003497", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003497", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003497", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003497", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003497", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003497", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003497")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003498")
    void case_UTAPI_003498() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003498",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003498", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003498", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003498", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003498", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003498", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003498", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003498", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003498", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003498", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003498", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003498", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003498", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003498")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003499")
    void case_UTAPI_003499() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003499",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003499", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003499", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003499", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003499", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003499", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003499", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003499", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003499", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003499", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003499", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003499", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003499", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003499")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003500")
    void case_UTAPI_003500() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003500",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003500", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003500", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003500", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003500", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003500", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003500", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003500", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003500", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003500", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003500", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003500", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003500", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003500")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003501")
    void case_UTAPI_003501() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003501",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003501", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003501", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003501", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003501", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003501", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003501", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003501", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003501", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003501", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003501", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003501", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003501", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003501")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003502")
    void case_UTAPI_003502() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003502",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003502", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003502", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003502", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003502", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003502", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003502", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003502", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003502", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003502", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003502", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003502", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003502", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003502")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003503")
    void case_UTAPI_003503() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003503",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003503", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003503", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003503", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003503", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003503", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003503", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003503", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003503", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003503", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003503", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003503", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003503", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003503")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003504")
    void case_UTAPI_003504() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003504",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003504", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003504", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003504", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003504", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003504", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003504", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003504", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003504", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003504", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003504", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003504", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003504", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003504")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003505")
    void case_UTAPI_003505() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003505",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003505", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003505", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003505", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003505", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003505", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003505", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003505", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003505", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003505", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003505", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003505", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003505", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003505")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003506")
    void case_UTAPI_003506() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003506",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003506", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003506", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003506", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003506", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003506", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003506", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003506", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003506", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003506", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003506", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003506", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003506", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003506")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003507")
    void case_UTAPI_003507() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003507",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003507", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003507", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003507", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003507", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003507", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003507", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003507", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003507", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003507", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003507", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003507", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003507", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003507")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003508")
    void case_UTAPI_003508() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003508",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003508", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003508", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003508", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003508", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003508", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003508", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003508", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003508", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003508", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003508", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003508", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003508", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003508")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003509")
    void case_UTAPI_003509() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003509",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003509", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003509", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003509", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003509", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003509", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003509", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003509", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003509", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003509", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003509", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003509", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003509", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003509")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003510")
    void case_UTAPI_003510() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003510",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003510", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003510", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003510", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003510", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003510", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003510", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003510", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003510", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003510", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003510", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003510", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003510", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003510")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003511")
    void case_UTAPI_003511() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003511",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003511", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003511", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003511", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003511", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003511", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003511", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003511", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003511", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003511", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003511", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003511", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003511", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003511")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003512")
    void case_UTAPI_003512() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003512",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003512", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003512", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003512", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003512", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003512", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003512", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003512", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003512", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003512", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003512", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003512", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003512", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003512")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003513")
    void case_UTAPI_003513() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003513",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003513", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003513", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003513", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003513", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003513", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003513", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003513", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003513", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003513", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003513", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003513", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003513", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003513")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003514")
    void case_UTAPI_003514() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003514",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003514", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003514", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003514", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003514", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003514", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003514", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003514", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003514", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003514", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003514", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003514", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003514", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003514")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003515")
    void case_UTAPI_003515() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003515",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003515", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003515", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003515", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003515", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003515", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003515", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003515", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003515", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003515", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003515", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003515", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003515", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003515")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003516")
    void case_UTAPI_003516() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003516",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003516", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003516", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003516", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003516", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003516", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003516", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003516", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003516", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003516", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003516", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003516", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003516", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003516")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003517")
    void case_UTAPI_003517() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003517",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003517", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003517", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003517", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003517", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003517", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003517", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003517", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003517", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003517", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003517", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003517", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003517", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003517")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003518")
    void case_UTAPI_003518() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003518",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003518", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003518", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003518", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003518", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003518", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003518", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003518", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003518", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003518", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003518", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003518", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003518", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003518")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003519")
    void case_UTAPI_003519() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003519",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003519", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003519", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003519", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003519", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003519", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003519", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003519", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003519", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003519", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003519", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003519", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003519", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003519")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003520")
    void case_UTAPI_003520() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003520",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003520", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003520", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003520", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003520", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003520", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003520", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003520", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003520", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003520", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003520", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003520", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003520", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003520")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003521")
    void case_UTAPI_003521() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003521",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003521", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003521", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003521", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003521", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003521", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003521", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003521", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003521", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003521", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003521", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003521", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003521", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003521")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003522")
    void case_UTAPI_003522() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003522",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003522", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003522", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003522", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003522", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003522", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003522", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003522", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003522", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003522", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003522", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003522", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003522", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003522")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003523")
    void case_UTAPI_003523() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003523",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003523", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003523", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003523", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003523", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003523", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003523", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003523", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003523", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003523", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003523", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003523", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003523", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003523")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003524")
    void case_UTAPI_003524() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003524",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003524", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003524", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003524", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003524", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003524", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003524", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003524", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003524", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003524", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003524", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003524", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003524", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003524")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003525")
    void case_UTAPI_003525() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003525",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003525", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003525", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003525", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003525", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003525", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003525", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003525", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003525", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003525", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003525", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003525", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003525", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003525")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003526")
    void case_UTAPI_003526() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003526",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003526", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003526", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003526", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003526", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003526", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003526", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003526", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003526", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003526", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003526", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003526", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003526", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003526")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003527")
    void case_UTAPI_003527() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003527",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003527", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003527", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003527", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003527", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003527", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003527", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003527", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003527", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003527", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003527", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003527", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003527", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003527")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003528")
    void case_UTAPI_003528() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003528",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003528", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003528", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003528", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003528", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003528", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003528", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003528", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003528", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003528", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003528", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003528", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003528", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003528")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003529")
    void case_UTAPI_003529() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003529",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003529", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003529", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003529", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003529", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003529", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003529", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003529", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003529", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003529", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003529", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003529", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003529", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003529")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003530")
    void case_UTAPI_003530() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003530",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003530", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003530", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003530", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003530", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003530", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003530", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003530", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003530", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003530", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003530", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003530", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003530", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003530")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003531")
    void case_UTAPI_003531() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003531",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003531", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003531", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003531", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003531", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003531", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003531", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003531", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003531", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003531", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003531", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003531", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003531", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003531")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003532")
    void case_UTAPI_003532() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003532",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003532", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003532", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003532", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003532", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003532", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003532", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003532", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003532", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003532", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003532", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003532", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003532", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003532")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003533")
    void case_UTAPI_003533() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003533",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003533", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003533", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003533", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003533", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003533", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003533", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003533", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003533", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003533", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003533", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003533", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003533", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003533")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003534")
    void case_UTAPI_003534() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003534",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003534", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003534", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003534", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003534", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003534", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003534", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003534", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003534", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003534", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003534", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003534", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003534", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003534")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003535")
    void case_UTAPI_003535() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003535",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003535", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003535", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003535", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003535", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003535", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003535", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003535", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003535", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003535", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003535", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003535", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003535", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003535")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003536")
    void case_UTAPI_003536() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003536",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003536", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003536", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003536", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003536", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003536", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003536", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003536", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003536", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003536", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003536", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003536", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003536", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003536")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003537")
    void case_UTAPI_003537() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003537",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003537", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003537", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003537", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003537", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003537", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003537", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003537", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003537", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003537", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003537", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003537", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003537", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003537")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003538")
    void case_UTAPI_003538() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003538",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003538", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003538", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003538", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003538", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003538", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003538", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003538", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003538", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003538", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003538", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003538", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003538", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003538")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003539")
    void case_UTAPI_003539() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003539",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003539", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003539", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003539", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003539", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003539", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003539", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003539", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003539", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003539", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003539", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003539", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003539", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003539")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003540")
    void case_UTAPI_003540() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003540",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003540", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003540", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003540", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003540", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003540", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003540", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003540", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003540", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003540", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003540", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003540", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003540", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003540")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003541")
    void case_UTAPI_003541() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003541",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003541", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003541", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003541", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003541", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003541", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003541", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003541", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003541", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003541", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003541", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003541", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003541", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003541")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003542")
    void case_UTAPI_003542() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003542",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003542", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003542", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003542", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003542", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003542", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003542", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003542", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003542", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003542", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003542", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003542", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003542", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003542")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003543")
    void case_UTAPI_003543() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003543",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003543", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003543", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003543", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003543", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003543", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003543", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003543", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003543", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003543", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003543", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003543", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003543", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003543")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003544")
    void case_UTAPI_003544() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003544",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003544", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003544", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003544", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003544", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003544", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003544", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003544", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003544", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003544", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003544", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003544", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003544", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003544")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003545")
    void case_UTAPI_003545() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003545",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003545", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003545", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003545", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003545", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003545", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003545", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003545", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003545", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003545", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003545", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003545", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003545", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003545")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003546")
    void case_UTAPI_003546() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003546",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003546", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003546", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003546", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003546", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003546", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003546", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003546", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003546", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003546", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003546", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003546", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003546", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003546")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003547")
    void case_UTAPI_003547() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003547",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003547", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003547", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003547", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003547", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003547", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003547", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003547", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003547", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003547", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003547", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003547", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003547", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003547")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003548")
    void case_UTAPI_003548() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003548",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003548", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003548", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003548", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003548", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003548", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003548", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003548", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003548", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003548", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003548", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003548", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003548", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003548")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003549")
    void case_UTAPI_003549() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003549",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003549", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003549", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003549", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003549", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003549", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003549", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003549", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003549", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003549", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003549", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003549", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003549", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003549")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003550")
    void case_UTAPI_003550() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003550",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003550", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003550", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003550", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003550", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003550", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003550", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003550", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003550", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003550", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003550", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003550", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003550", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003550")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003551")
    void case_UTAPI_003551() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003551",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003551", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003551", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003551", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003551", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003551", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003551", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003551", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003551", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003551", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003551", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003551", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003551", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003551")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003552")
    void case_UTAPI_003552() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003552",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003552", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003552", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003552", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003552", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003552", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003552", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003552", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003552", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003552", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003552", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003552", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003552", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003552")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003553")
    void case_UTAPI_003553() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003553",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003553", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003553", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003553", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003553", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003553", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003553", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003553", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003553", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003553", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003553", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003553", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003553", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003553")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003554")
    void case_UTAPI_003554() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003554",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003554", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003554", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003554", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003554", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003554", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003554", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003554", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003554", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003554", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003554", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003554", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003554", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003554")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003555")
    void case_UTAPI_003555() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003555",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003555", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003555", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003555", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003555", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003555", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003555", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003555", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003555", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003555", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003555", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003555", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003555", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003555")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003556")
    void case_UTAPI_003556() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003556",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003556", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003556", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003556", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003556", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003556", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003556", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003556", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003556", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003556", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003556", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003556", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003556", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003556")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003557")
    void case_UTAPI_003557() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003557",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003557", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003557", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003557", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003557", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003557", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003557", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003557", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003557", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003557", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003557", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003557", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003557", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003557")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003558")
    void case_UTAPI_003558() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003558",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003558", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003558", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003558", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003558", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003558", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003558", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003558", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003558", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003558", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003558", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003558", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003558", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003558")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003559")
    void case_UTAPI_003559() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003559",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003559", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003559", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003559", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003559", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003559", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003559", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003559", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003559", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003559", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003559", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003559", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003559", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003559")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003560")
    void case_UTAPI_003560() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003560",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003560", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003560", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003560", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003560", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003560", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003560", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003560", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003560", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003560", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003560", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003560", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003560", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003560")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003561")
    void case_UTAPI_003561() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003561",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003561", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003561", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003561", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003561", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003561", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003561", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003561", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003561", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003561", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003561", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003561", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003561", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003561")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003562")
    void case_UTAPI_003562() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003562",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003562", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003562", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003562", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003562", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003562", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003562", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003562", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003562", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003562", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003562", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003562", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003562", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003562")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003563")
    void case_UTAPI_003563() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003563",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003563", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003563", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003563", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003563", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003563", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003563", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003563", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003563", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003563", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003563", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003563", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003563", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003563")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003564")
    void case_UTAPI_003564() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003564",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003564", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003564", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003564", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003564", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003564", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003564", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003564", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003564", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003564", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003564", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003564", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003564", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003564")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003565")
    void case_UTAPI_003565() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003565",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003565", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003565", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003565", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003565", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003565", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003565", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003565", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003565", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003565", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003565", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003565", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003565", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003565")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003566")
    void case_UTAPI_003566() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003566",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003566", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003566", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003566", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003566", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003566", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003566", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003566", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003566", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003566", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003566", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003566", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003566", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003566")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003567")
    void case_UTAPI_003567() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003567",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003567", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003567", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003567", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003567", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003567", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003567", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003567", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003567", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003567", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003567", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003567", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003567", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003567")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003568")
    void case_UTAPI_003568() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003568",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003568", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003568", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003568", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003568", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003568", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003568", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003568", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003568", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003568", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003568", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003568", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003568", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003568")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003569")
    void case_UTAPI_003569() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003569",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003569", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003569", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003569", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003569", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003569", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003569", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003569", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003569", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003569", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003569", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003569", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003569", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003569")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003570")
    void case_UTAPI_003570() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003570",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003570", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003570", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003570", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003570", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003570", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003570", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003570", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003570", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003570", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003570", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003570", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003570", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003570")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003571")
    void case_UTAPI_003571() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003571",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003571", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003571", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003571", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003571", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003571", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003571", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003571", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003571", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003571", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003571", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003571", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003571", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003571")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003572")
    void case_UTAPI_003572() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003572",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003572", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003572", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003572", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003572", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003572", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003572", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003572", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003572", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003572", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003572", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003572", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003572", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003572")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003573")
    void case_UTAPI_003573() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003573",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003573", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003573", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003573", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003573", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003573", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003573", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003573", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003573", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003573", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003573", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003573", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003573", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003573")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003574")
    void case_UTAPI_003574() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003574",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003574", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003574", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003574", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003574", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003574", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003574", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003574", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003574", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003574", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003574", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003574", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003574", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003574")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003575")
    void case_UTAPI_003575() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003575",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003575", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003575", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003575", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003575", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003575", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003575", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003575", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003575", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003575", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003575", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003575", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003575", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003575")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003576")
    void case_UTAPI_003576() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003576",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003576", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003576", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003576", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003576", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003576", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003576", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003576", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003576", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003576", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003576", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003576", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003576", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003576")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003577")
    void case_UTAPI_003577() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003577",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003577", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003577", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003577", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003577", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003577", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003577", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003577", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003577", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003577", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003577", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003577", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003577", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003577")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003578")
    void case_UTAPI_003578() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003578",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003578", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003578", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003578", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003578", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003578", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003578", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003578", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003578", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003578", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003578", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003578", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003578", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003578")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003579")
    void case_UTAPI_003579() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003579",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003579", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003579", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003579", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003579", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003579", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003579", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003579", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003579", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003579", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003579", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003579", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003579", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003579")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003580")
    void case_UTAPI_003580() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003580",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003580", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003580", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003580", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003580", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003580", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003580", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003580", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003580", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003580", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003580", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003580", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003580", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003580")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003581")
    void case_UTAPI_003581() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003581",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003581", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003581", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003581", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003581", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003581", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003581", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003581", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003581", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003581", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003581", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003581", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003581", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003581")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003582")
    void case_UTAPI_003582() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003582",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003582", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003582", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003582", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003582", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003582", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003582", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003582", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003582", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003582", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003582", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003582", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003582", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003582")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003583")
    void case_UTAPI_003583() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003583",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003583", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003583", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003583", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003583", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003583", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003583", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003583", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003583", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003583", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003583", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003583", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003583", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003583")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003584")
    void case_UTAPI_003584() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003584",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003584", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003584", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003584", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003584", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003584", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003584", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003584", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003584", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003584", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003584", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003584", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003584", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003584")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003585")
    void case_UTAPI_003585() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003585",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003585", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003585", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003585", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003585", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003585", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003585", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003585", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003585", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003585", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003585", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003585", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003585", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003585")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003586")
    void case_UTAPI_003586() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003586",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003586", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003586", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003586", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003586", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003586", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003586", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003586", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003586", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003586", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003586", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003586", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003586", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003586")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003587")
    void case_UTAPI_003587() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003587",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003587", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003587", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003587", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003587", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003587", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003587", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003587", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003587", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003587", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003587", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003587", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003587", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003587")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003588")
    void case_UTAPI_003588() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003588",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003588", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003588", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003588", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003588", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003588", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003588", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003588", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003588", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003588", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003588", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003588", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003588", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003588")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003589")
    void case_UTAPI_003589() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003589",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003589", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003589", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003589", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003589", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003589", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003589", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003589", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003589", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003589", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003589", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003589", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003589", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003589")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003590")
    void case_UTAPI_003590() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003590",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003590", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003590", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003590", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003590", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003590", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003590", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003590", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003590", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003590", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003590", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003590", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003590", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003590")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003591")
    void case_UTAPI_003591() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003591",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003591", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003591", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003591", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003591", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003591", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003591", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003591", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003591", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003591", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003591", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003591", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003591", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003591")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003592")
    void case_UTAPI_003592() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003592",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003592", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003592", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003592", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003592", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003592", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003592", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003592", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003592", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003592", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003592", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003592", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003592", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003592")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003593")
    void case_UTAPI_003593() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003593",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003593", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003593", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003593", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003593", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003593", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003593", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003593", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003593", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003593", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003593", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003593", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003593", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003593")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003594")
    void case_UTAPI_003594() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003594",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003594", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003594", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003594", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003594", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003594", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003594", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003594", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003594", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003594", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003594", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003594", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003594", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003594")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003595")
    void case_UTAPI_003595() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003595",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003595", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003595", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003595", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003595", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003595", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003595", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003595", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003595", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003595", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003595", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003595", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003595", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003595")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003596")
    void case_UTAPI_003596() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003596",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003596", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003596", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003596", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003596", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003596", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003596", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003596", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003596", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003596", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003596", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003596", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003596", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003596")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003597")
    void case_UTAPI_003597() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003597",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003597", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003597", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003597", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003597", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003597", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003597", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003597", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003597", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003597", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003597", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003597", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003597", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003597")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003598")
    void case_UTAPI_003598() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003598",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003598", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003598", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003598", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003598", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003598", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003598", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003598", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003598", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003598", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003598", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003598", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003598", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003598")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003599")
    void case_UTAPI_003599() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003599",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003599", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003599", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003599", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003599", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003599", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003599", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003599", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003599", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003599", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003599", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003599", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003599", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003599")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003600")
    void case_UTAPI_003600() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003600",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003600", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003600", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003600", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003600", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003600", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003600", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003600", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003600", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003600", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003600", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003600", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003600", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003600")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003601")
    void case_UTAPI_003601() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003601",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003601", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003601", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003601", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003601", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003601", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003601", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003601", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003601", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003601", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003601", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003601", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003601", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003601")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003602")
    void case_UTAPI_003602() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003602",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003602", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003602", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003602", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003602", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003602", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003602", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003602", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003602", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003602", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003602", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003602", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003602", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003602")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003603")
    void case_UTAPI_003603() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003603",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003603", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003603", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003603", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003603", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003603", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003603", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003603", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003603", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003603", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003603", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003603", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003603", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003603")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003604")
    void case_UTAPI_003604() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003604",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003604", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003604", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003604", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003604", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003604", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003604", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003604", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003604", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003604", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003604", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003604", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003604", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003604")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003605")
    void case_UTAPI_003605() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003605",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003605", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003605", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003605", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003605", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003605", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003605", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003605", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003605", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003605", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003605", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003605", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003605", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003605")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003606")
    void case_UTAPI_003606() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003606",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003606", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003606", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003606", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003606", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003606", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003606", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003606", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003606", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003606", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003606", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003606", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003606", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003606")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003607")
    void case_UTAPI_003607() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003607",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003607", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003607", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003607", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003607", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003607", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003607", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003607", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003607", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003607", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003607", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003607", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003607", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003607")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003608")
    void case_UTAPI_003608() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003608",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003608", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003608", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003608", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003608", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003608", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003608", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003608", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003608", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003608", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003608", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003608", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003608", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003608")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003609")
    void case_UTAPI_003609() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003609",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003609", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003609", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003609", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003609", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003609", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003609", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003609", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003609", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003609", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003609", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003609", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003609", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003609")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003610")
    void case_UTAPI_003610() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003610",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003610", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003610", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003610", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003610", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003610", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003610", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003610", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003610", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003610", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003610", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003610", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003610", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003610")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003611")
    void case_UTAPI_003611() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003611",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003611", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003611", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003611", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003611", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003611", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003611", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003611", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003611", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003611", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003611", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003611", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003611", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003611")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003612")
    void case_UTAPI_003612() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003612",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003612", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003612", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003612", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003612", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003612", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003612", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003612", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003612", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003612", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003612", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003612", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003612", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003612")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003613")
    void case_UTAPI_003613() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003613",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003613", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003613", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003613", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003613", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003613", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003613", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003613", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003613", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003613", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003613", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003613", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003613", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003613")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003614")
    void case_UTAPI_003614() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003614",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003614", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003614", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003614", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003614", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003614", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003614", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003614", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003614", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003614", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003614", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003614", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003614", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003614")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003615")
    void case_UTAPI_003615() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003615",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003615", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003615", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003615", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003615", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003615", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003615", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003615", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003615", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003615", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003615", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003615", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003615", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003615")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003616")
    void case_UTAPI_003616() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003616",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003616", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003616", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003616", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003616", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003616", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003616", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003616", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003616", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003616", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003616", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003616", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003616", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003616")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003617")
    void case_UTAPI_003617() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003617",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003617", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003617", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003617", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003617", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003617", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003617", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003617", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003617", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003617", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003617", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003617", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003617", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003617")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003618")
    void case_UTAPI_003618() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003618",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003618", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003618", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003618", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003618", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003618", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003618", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003618", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003618", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003618", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003618", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003618", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003618", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003618")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003619")
    void case_UTAPI_003619() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003619",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003619", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003619", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003619", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003619", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003619", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003619", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003619", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003619", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003619", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003619", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003619", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003619", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003619")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003620")
    void case_UTAPI_003620() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003620",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003620", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003620", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003620", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003620", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003620", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003620", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003620", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003620", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003620", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003620", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003620", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003620", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003620")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003621")
    void case_UTAPI_003621() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003621",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003621", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003621", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003621", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003621", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003621", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003621", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003621", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003621", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003621", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003621", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003621", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003621", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003621")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003622")
    void case_UTAPI_003622() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003622",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003622", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003622", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003622", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003622", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003622", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003622", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003622", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003622", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003622", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003622", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003622", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003622", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003622")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003623")
    void case_UTAPI_003623() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003623",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003623", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003623", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003623", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003623", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003623", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003623", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003623", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003623", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003623", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003623", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003623", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003623", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003623")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003624")
    void case_UTAPI_003624() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003624",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003624", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003624", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003624", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003624", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003624", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003624", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003624", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003624", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003624", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003624", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003624", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003624", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003624")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003625")
    void case_UTAPI_003625() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003625",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003625", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003625", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003625", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003625", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003625", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003625", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003625", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003625", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003625", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003625", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003625", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003625", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003625")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003626")
    void case_UTAPI_003626() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003626",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003626", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003626", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003626", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003626", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003626", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003626", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003626", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003626", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003626", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003626", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003626", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003626", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003626")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003627")
    void case_UTAPI_003627() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003627",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003627", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003627", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003627", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003627", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003627", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003627", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003627", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003627", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003627", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003627", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003627", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003627", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003627")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003628")
    void case_UTAPI_003628() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003628",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003628", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003628", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003628", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003628", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003628", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003628", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003628", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003628", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003628", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003628", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003628", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003628", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003628")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003629")
    void case_UTAPI_003629() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003629",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003629", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003629", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003629", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003629", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003629", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003629", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003629", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003629", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003629", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003629", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003629", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003629", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003629")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003630")
    void case_UTAPI_003630() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003630",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003630", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003630", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003630", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003630", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003630", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003630", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003630", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003630", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003630", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003630", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003630", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003630", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003630")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003631")
    void case_UTAPI_003631() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003631",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003631", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003631", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003631", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003631", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003631", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003631", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003631", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003631", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003631", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003631", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003631", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003631", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003631")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003632")
    void case_UTAPI_003632() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003632",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003632", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003632", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003632", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003632", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003632", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003632", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003632", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003632", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003632", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003632", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003632", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003632", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003632")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003633")
    void case_UTAPI_003633() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003633",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003633", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003633", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003633", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003633", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003633", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003633", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003633", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003633", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003633", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003633", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003633", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003633", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003633")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003634")
    void case_UTAPI_003634() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003634",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003634", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003634", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003634", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003634", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003634", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003634", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003634", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003634", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003634", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003634", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003634", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003634", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003634")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003635")
    void case_UTAPI_003635() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003635",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003635", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003635", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003635", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003635", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003635", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003635", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003635", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003635", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003635", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003635", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003635", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003635", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003635")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003636")
    void case_UTAPI_003636() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003636",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003636", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003636", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003636", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003636", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003636", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003636", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003636", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003636", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003636", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003636", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003636", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003636", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003636")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003637")
    void case_UTAPI_003637() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003637",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003637", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003637", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003637", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003637", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003637", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003637", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003637", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003637", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003637", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003637", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003637", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003637", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003637")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003638")
    void case_UTAPI_003638() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003638",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003638", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003638", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003638", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003638", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003638", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003638", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003638", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003638", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003638", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003638", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003638", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003638", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003638")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003639")
    void case_UTAPI_003639() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003639",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003639", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003639", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003639", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003639", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003639", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003639", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003639", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003639", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003639", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003639", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003639", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003639", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003639")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003640")
    void case_UTAPI_003640() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003640",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003640", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003640", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003640", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003640", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003640", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003640", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003640", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003640", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003640", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003640", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003640", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003640", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003640")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003641")
    void case_UTAPI_003641() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003641",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003641", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003641", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003641", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003641", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003641", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003641", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003641", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003641", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003641", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003641", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003641", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003641", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003641")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003642")
    void case_UTAPI_003642() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003642",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003642", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003642", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003642", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003642", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003642", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003642", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003642", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003642", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003642", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003642", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003642", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003642", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003642")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003643")
    void case_UTAPI_003643() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003643",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003643", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003643", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003643", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003643", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003643", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003643", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003643", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003643", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003643", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003643", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003643", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003643", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003643")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003644")
    void case_UTAPI_003644() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003644",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003644", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003644", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003644", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003644", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003644", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003644", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003644", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003644", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003644", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003644", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003644", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003644", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003644")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003645")
    void case_UTAPI_003645() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003645",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003645", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003645", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003645", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003645", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003645", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003645", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003645", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003645", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003645", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003645", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003645", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003645", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003645")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003646")
    void case_UTAPI_003646() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003646",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003646", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003646", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003646", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003646", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003646", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003646", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003646", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003646", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003646", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003646", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003646", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003646", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003646")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003647")
    void case_UTAPI_003647() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003647",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003647", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003647", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003647", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003647", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003647", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003647", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003647", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003647", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003647", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003647", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003647", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003647", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003647")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003648")
    void case_UTAPI_003648() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003648",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003648", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003648", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003648", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003648", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003648", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003648", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003648", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003648", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003648", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003648", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003648", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003648", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003648")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003649")
    void case_UTAPI_003649() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003649",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003649", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003649", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003649", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003649", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003649", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003649", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003649", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003649", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003649", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003649", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003649", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003649", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003649")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003650")
    void case_UTAPI_003650() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003650",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003650", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003650", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003650", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003650", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003650", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003650", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003650", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003650", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003650", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003650", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003650", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003650", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003650")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003651")
    void case_UTAPI_003651() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003651",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003651", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003651", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003651", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003651", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003651", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003651", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003651", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003651", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003651", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003651", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003651", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003651", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003651")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003652")
    void case_UTAPI_003652() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003652",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003652", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003652", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003652", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003652", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003652", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003652", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003652", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003652", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003652", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003652", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003652", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003652", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003652")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003653")
    void case_UTAPI_003653() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003653",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003653", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003653", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003653", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003653", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003653", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003653", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003653", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003653", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003653", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003653", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003653", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003653", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003653")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003654")
    void case_UTAPI_003654() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003654",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003654", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003654", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003654", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003654", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003654", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003654", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003654", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003654", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003654", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003654", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003654", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003654", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003654")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003655")
    void case_UTAPI_003655() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003655",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003655", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003655", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003655", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003655", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003655", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003655", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003655", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003655", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003655", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003655", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003655", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003655", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003655")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003656")
    void case_UTAPI_003656() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003656",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003656", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003656", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003656", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003656", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003656", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003656", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003656", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003656", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003656", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003656", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003656", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003656", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003656")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003657")
    void case_UTAPI_003657() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003657",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003657", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003657", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003657", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003657", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003657", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003657", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003657", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003657", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003657", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003657", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003657", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003657", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003657")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003658")
    void case_UTAPI_003658() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003658",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003658", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003658", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003658", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003658", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003658", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003658", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003658", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003658", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003658", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003658", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003658", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003658", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003658")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003659")
    void case_UTAPI_003659() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003659",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003659", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003659", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003659", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003659", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003659", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003659", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003659", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003659", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003659", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003659", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003659", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003659", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003659")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003660")
    void case_UTAPI_003660() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003660",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003660", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003660", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003660", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003660", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003660", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003660", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003660", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003660", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003660", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003660", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003660", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003660", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003660")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003661")
    void case_UTAPI_003661() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003661",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003661", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003661", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003661", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003661", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003661", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003661", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003661", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003661", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003661", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003661", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003661", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003661", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003661")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003662")
    void case_UTAPI_003662() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003662",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003662", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003662", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003662", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003662", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003662", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003662", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003662", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003662", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003662", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003662", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003662", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003662", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003662")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003663")
    void case_UTAPI_003663() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003663",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003663", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003663", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003663", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003663", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003663", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003663", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003663", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003663", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003663", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003663", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003663", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003663", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003663")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003664")
    void case_UTAPI_003664() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003664",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003664", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003664", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003664", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003664", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003664", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003664", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003664", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003664", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003664", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003664", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003664", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003664", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003664")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003665")
    void case_UTAPI_003665() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003665",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003665", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003665", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003665", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003665", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003665", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003665", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003665", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003665", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003665", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003665", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003665", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003665", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003665")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003666")
    void case_UTAPI_003666() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003666",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003666", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003666", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003666", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003666", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003666", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003666", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003666", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003666", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003666", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003666", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003666", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003666", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003666")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003667")
    void case_UTAPI_003667() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003667",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003667", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003667", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003667", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003667", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003667", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003667", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003667", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003667", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003667", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003667", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003667", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003667", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003667")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003668")
    void case_UTAPI_003668() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003668",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003668", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003668", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003668", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003668", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003668", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003668", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003668", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003668", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003668", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003668", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003668", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003668", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003668")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003669")
    void case_UTAPI_003669() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003669",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003669", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003669", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003669", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003669", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003669", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003669", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003669", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003669", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003669", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003669", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003669", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003669", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003669")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003670")
    void case_UTAPI_003670() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003670",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003670", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003670", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003670", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003670", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003670", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003670", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003670", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003670", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003670", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003670", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003670", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003670", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003670")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003671")
    void case_UTAPI_003671() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003671",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003671", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003671", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003671", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003671", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003671", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003671", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003671", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003671", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003671", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003671", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003671", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003671", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003671")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003672")
    void case_UTAPI_003672() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003672",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003672", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003672", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003672", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003672", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003672", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003672", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003672", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003672", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003672", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003672", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003672", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003672", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003672")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003673")
    void case_UTAPI_003673() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003673",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003673", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003673", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003673", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003673", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003673", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003673", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003673", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003673", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003673", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003673", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003673", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003673", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003673")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003674")
    void case_UTAPI_003674() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003674",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003674", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003674", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003674", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003674", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003674", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003674", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003674", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003674", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003674", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003674", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003674", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003674", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003674")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003675")
    void case_UTAPI_003675() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003675",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003675", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003675", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003675", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003675", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003675", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003675", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003675", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003675", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003675", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003675", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003675", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003675", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003675")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

}

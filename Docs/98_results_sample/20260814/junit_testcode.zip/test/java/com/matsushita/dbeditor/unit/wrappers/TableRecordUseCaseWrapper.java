package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for TableRecordUseCase.
 */
public final class TableRecordUseCaseWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.usecase.table.TableRecordUseCase";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.usecase.table.TableRecordUseCase";
    private static final String[] DEP_NAMES = new String[] {"connectionSettingRepository", "tableRecordRepository"};
    private static final String[] DEP_TYPES = new String[] {"ConnectionSettingRepository", "TableRecordRepository"};
    private static final String[] TYPES_createCopy = new String[] {"Integer", "String", "String"};
    private static final String[] TYPES_dropStaleTable = new String[] {"Integer", "String", "String"};
    private static final String[] TYPES_getAllRecords = new String[] {"Integer", "String", "String"};
    private static final String[] TYPES_getConnection = new String[] {"Integer"};
    private static final String[] TYPES_getCopyRecords = new String[] {"Integer", "String", "String"};
    private static final String[] TYPES_getStaleTables = new String[] {"Integer", "String"};
    private static final String[] TYPES_updateCopyRecords = new String[] {"Integer", "String", "String", "List<Map<String, Object>>"};

    public TableRecordUseCaseWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, false);
    }

    /** void createCopy(connectionId, schemaName, tableName) */
    public ExecutionResult createCopy(Object[] args) {
        return invoke("createCopy", TYPES_createCopy, args);
    }

    /** void dropStaleTable(connectionId, schemaName, tableName) */
    public ExecutionResult dropStaleTable(Object[] args) {
        return invoke("dropStaleTable", TYPES_dropStaleTable, args);
    }

    /** List<Map<String,Object>> getAllRecords(connectionId, schemaName, tableName) */
    public ExecutionResult getAllRecords(Object[] args) {
        return invoke("getAllRecords", TYPES_getAllRecords, args);
    }

    /** ConnectionSetting getConnection(connectionId) */
    public ExecutionResult getConnection(Object[] args) {
        return invoke("getConnection", TYPES_getConnection, args);
    }

    /** List<Map<String,Object>> getCopyRecords(connectionId, schemaName, tableName) */
    public ExecutionResult getCopyRecords(Object[] args) {
        return invoke("getCopyRecords", TYPES_getCopyRecords, args);
    }

    /** List<String> getStaleTables(connectionId, schemaName) */
    public ExecutionResult getStaleTables(Object[] args) {
        return invoke("getStaleTables", TYPES_getStaleTables, args);
    }

    /** void updateCopyRecords(connectionId, schemaName, tableName, records) */
    public ExecutionResult updateCopyRecords(Object[] args) {
        return invoke("updateCopyRecords", TYPES_updateCopyRecords, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("createCopy".equals(operation)) {
            return createCopy(args);
        } else if ("dropStaleTable".equals(operation)) {
            return dropStaleTable(args);
        } else if ("getAllRecords".equals(operation)) {
            return getAllRecords(args);
        } else if ("getConnection".equals(operation)) {
            return getConnection(args);
        } else if ("getCopyRecords".equals(operation)) {
            return getCopyRecords(args);
        } else if ("getStaleTables".equals(operation)) {
            return getStaleTables(args);
        } else if ("updateCopyRecords".equals(operation)) {
            return updateCopyRecords(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.MemoUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for MemoUseCase#downloadMemo.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class MemoUseCaseDownloadMemoScenario {

    @Test
    @DisplayName("UTAPI-012577")
    void case_UTAPI_012577() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012577",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012577", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012577", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012577")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012578")
    void case_UTAPI_012578() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012578",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012578", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012578", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012578")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012579")
    void case_UTAPI_012579() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012579",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012579", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012579", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012579")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012580")
    void case_UTAPI_012580() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012580",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012580", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012580", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012580")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012581")
    void case_UTAPI_012581() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012581",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012581", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012581", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012581")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012582")
    void case_UTAPI_012582() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012582",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012582", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012582", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012582")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012583")
    void case_UTAPI_012583() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012583",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012583", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012583", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012583")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012584")
    void case_UTAPI_012584() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012584",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012584", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012584", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012584")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012585")
    void case_UTAPI_012585() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012585",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012585", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012585", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012585")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012586")
    void case_UTAPI_012586() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012586",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012586", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012586", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012586")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012587")
    void case_UTAPI_012587() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012587",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012587", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012587", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012587")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012588")
    void case_UTAPI_012588() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012588",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012588", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012588", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012588")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012589")
    void case_UTAPI_012589() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012589",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012589", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012589", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012589")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012590")
    void case_UTAPI_012590() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012590",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012590", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012590", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012590")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012591")
    void case_UTAPI_012591() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012591",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012591", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012591", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012591")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012592")
    void case_UTAPI_012592() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012592",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012592", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012592", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012592")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012593")
    void case_UTAPI_012593() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012593",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012593", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012593", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012593")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012594")
    void case_UTAPI_012594() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012594",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012594", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012594", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012594")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012595")
    void case_UTAPI_012595() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012595",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012595", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012595", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012595")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::2::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012596")
    void case_UTAPI_012596() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012596",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012596", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012596", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012596")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::2::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012597")
    void case_UTAPI_012597() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012597",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012597", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012597", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012597")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::2::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012598")
    void case_UTAPI_012598() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012598",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012598", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012598", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012598")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::2::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012599")
    void case_UTAPI_012599() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012599",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012599", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012599", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012599")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012600")
    void case_UTAPI_012600() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012600",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012600", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012600", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012600")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012601")
    void case_UTAPI_012601() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012601",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012601", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012601", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012601")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012602")
    void case_UTAPI_012602() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012602",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012602", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012602", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012602")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012603")
    void case_UTAPI_012603() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012603",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012603", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012603", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012603")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012604")
    void case_UTAPI_012604() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012604",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012604", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012604", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012604")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012605")
    void case_UTAPI_012605() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012605",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012605", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012605", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012605")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012606")
    void case_UTAPI_012606() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012606",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012606", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012606", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012606")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012607")
    void case_UTAPI_012607() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012607",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012607", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012607", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012607")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012608")
    void case_UTAPI_012608() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012608",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "downloadMemo",
                "String",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012608", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012608", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012608")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::downloadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

}
